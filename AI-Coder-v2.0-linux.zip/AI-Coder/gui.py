"""Интерфейс AI-Coder (только Linux): боковая панель, чат, терминал, редактор, окна."""
import os
import shutil
import subprocess
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, ttk

import customtkinter as ctk

import executor
import sysinfo
import theme
from chat_view import ChatView
from editor import CodeEditorModule
from i18n import _, get_language, set_language
from theme import C, MODE_ORDER, MODES

TREE_SKIP = {"__pycache__", "node_modules", ".venv", "venv", "env", "dist", "build", "target", "site-packages"}


def ghost_button(parent, text, command, **kw):
    opts = dict(height=30, fg_color=C["surface"], hover_color=C["surface_hi"], text_color=C["text"],
                border_width=1, border_color=C["border"], font=theme.ui(11), corner_radius=6)
    opts.update(kw)
    return ctk.CTkButton(parent, text=text, command=command, **opts)


class UIMixin:
    TAB_CHAT = "Чат"
    TAB_EDITOR = "Редактор"

    # ═════════════════════════ построение интерфейса ═════════════════════════
    def setup_ui(self):
        self.configure(fg_color=C["bg"])
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self._build_sidebar()
        self._build_main()
        self._build_statusbar()

    def _section_label(self, parent, text, row, pady=(14, 4)):
        ctk.CTkLabel(parent, text=text, anchor="w", font=theme.ui(10, "bold"), text_color=C["faint"]).grid(
            row=row, column=0, padx=16, pady=pady, sticky="w")

    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=288, corner_radius=0, fg_color=C["panel"])
        sb.grid(row=0, column=0, sticky="nsew")
        sb.grid_propagate(False)
        sb.grid_columnconfigure(0, weight=1)
        sb.grid_rowconfigure(3, weight=2)
        sb.grid_rowconfigure(6, weight=3)
        self.sidebar = sb

        head = ctk.CTkFrame(sb, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", padx=16, pady=(16, 0))
        try:
            from PIL import Image
            img = Image.open(os.path.join(sysinfo.APP_DIR, "icon.png"))
            logo = ctk.CTkImage(light_image=img, dark_image=img, size=(30, 30))
            ctk.CTkLabel(head, image=logo, text="").pack(side="left", padx=(0, 10))
        except Exception:
            pass
        ctk.CTkLabel(head, text="AI-Coder", font=theme.ui(17, "bold"), text_color=C["text"]).pack(side="left")
        ctk.CTkLabel(head, text=" LINUX ", font=theme.ui(9, "bold"), text_color=C["accent"], fg_color=C["accent_dim"],
                     corner_radius=4).pack(side="left", padx=8)

        self.btn_new_chat = ctk.CTkButton(sb, text="+  " + _("Новая сессия"), height=36, font=theme.ui(12, "bold"),
                                          fg_color=C["accent"], hover_color=C["accent_hover"], corner_radius=8,
                                          command=lambda: self.new_chat(_("Новый проект")))
        self.btn_new_chat.grid(row=1, column=0, padx=14, pady=(14, 0), sticky="ew")

        self._section_label(sb, _("СЕССИИ"), 2)
        self.chats_scroll = ctk.CTkScrollableFrame(sb, fg_color="transparent", height=120, scrollbar_button_color=C["surface_hi"],
                                                   scrollbar_button_hover_color=C["border"])
        self.chats_scroll.grid(row=3, column=0, padx=8, pady=0, sticky="nsew")
        self.chats_frame = self.chats_scroll

        self._section_label(sb, _("ПРОЕКТ"), 4)
        self.btn_select_dir = ghost_button(sb, "", self.select_workspace, anchor="w")
        self.btn_select_dir.grid(row=5, column=0, padx=14, pady=(0, 6), sticky="ew")

        tf = ctk.CTkFrame(sb, fg_color="transparent")
        tf.grid(row=6, column=0, padx=(10, 6), sticky="nsew")
        tf.grid_rowconfigure(0, weight=1)
        tf.grid_columnconfigure(0, weight=1)
        self.tree_frame = tf
        self.tree = ttk.Treeview(tf, show="tree", selectmode="browse")
        self.tree.grid(row=0, column=0, sticky="nsew")
        tsb = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        tsb.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=tsb.set)
        self.tree.tag_configure("dir", foreground=C["accent"])
        self.tree.bind("<Double-1>", self.on_tree_open)
        self.tree.bind("<Return>", self.on_tree_open)
        self.tree.bind("<F5>", lambda e: self.refresh_file_tree())
        self.setup_context_menu()

        bottom = ctk.CTkFrame(sb, fg_color="transparent")
        bottom.grid(row=7, column=0, padx=14, pady=14, sticky="ew")
        bottom.grid_columnconfigure((0, 1), weight=1)
        items = [
            ("Терминал", self.open_cmd), ("Диагностика", self.open_diagnostics_window),
            ("Настройки", self.open_settings_window), ("Откат кода", self.rollback_changes_wrapper),
            ("Web-ИИ", self.open_mini_browser), ("Помощь", self.open_help_window),
        ]
        self.btn_cmd = self.btn_rollback = self.btn_settings = self.btn_help = self.btn_web_ai = None
        for i, (label, cmd) in enumerate(items):
            b = ghost_button(bottom, _(label), cmd)
            b.grid(row=i // 2, column=i % 2, padx=(0, 4) if i % 2 == 0 else (4, 0), pady=3, sticky="ew")
            if label == "Откат кода":
                b.configure(text_color=C["red"])
        self.btn_license = ctk.CTkButton(bottom, text=_("О проекте"), height=24, fg_color="transparent", hover_color=C["surface"],
                                         text_color=C["faint"], font=theme.ui(10), command=self.open_license_window)
        self.btn_license.grid(row=3, column=0, columnspan=2, pady=(4, 0))

    def _build_main(self):
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.grid(row=0, column=1, sticky="nsew", padx=(14, 14), pady=(10, 4))
        main.grid_rowconfigure(0, weight=1)
        main.grid_columnconfigure(0, weight=1)
        self.main_content = main

        self.tabview = ctk.CTkTabview(main, fg_color=C["bg"], segmented_button_fg_color=C["surface"],
                                      segmented_button_selected_color=C["surface_hi"],
                                      segmented_button_selected_hover_color=C["surface_hi"],
                                      segmented_button_unselected_color=C["surface"],
                                      segmented_button_unselected_hover_color=C["surface_hi"],
                                      text_color=C["text"], corner_radius=8, border_width=0)
        self.tabview.grid(row=0, column=0, sticky="nsew")
        self.tab_chat = self.tabview.add(self.TAB_CHAT)
        self.tab_editor = self.tabview.add(self.TAB_EDITOR)

        tab = self.tab_chat
        tab.grid_rowconfigure(1, weight=1)
        tab.grid_columnconfigure(0, weight=1)

        # шапка: название сессии, описание режима и выбор режима
        header = ctk.CTkFrame(tab, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", pady=(2, 8))
        header.grid_columnconfigure(0, weight=1)
        titles = ctk.CTkFrame(header, fg_color="transparent")
        titles.grid(row=0, column=0, sticky="w")
        self.lbl_chat_title = ctk.CTkLabel(titles, text="", font=theme.ui(15, "bold"), anchor="w")
        self.lbl_chat_title.pack(anchor="w")
        self.lbl_mode_desc = ctk.CTkLabel(titles, text="", font=theme.ui(11), text_color=C["muted"], anchor="w")
        self.lbl_mode_desc.pack(anchor="w")
        self.mode_var = ctk.StringVar(value=MODES["agent"]["label"])
        self.seg_mode = ctk.CTkSegmentedButton(
            header, values=[MODES[m]["label"] for m in MODE_ORDER], variable=self.mode_var, command=self._on_mode_pick,
            font=theme.ui(12, "bold"), height=32, fg_color=C["surface"], unselected_color=C["surface"],
            unselected_hover_color=C["surface_hi"], text_color=C["text"])
        self.seg_mode.grid(row=0, column=1, sticky="e")

        self.chat_view = ChatView(tab)
        self.ai_console = self.chat_view  # прежнее имя для совместимости
        self.chat_view.grid(row=1, column=0, sticky="nsew")

        # живой вывод терминала
        tf = ctk.CTkFrame(tab, fg_color=C["code_bg"], corner_radius=8, border_width=1, border_color=C["border"])
        tf.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        tf.grid_columnconfigure(0, weight=1)
        self.terminal_frame = tf
        th = ctk.CTkFrame(tf, fg_color="transparent")
        th.grid(row=0, column=0, sticky="ew", padx=10, pady=(6, 0))
        ctk.CTkLabel(th, text=_("ТЕРМИНАЛ"), font=theme.ui(10, "bold"), text_color=C["faint"]).pack(side="left")
        self.lbl_term_state = ctk.CTkLabel(th, text="", font=theme.ui(10), text_color=C["muted"])
        self.lbl_term_state.pack(side="left", padx=10)
        ctk.CTkButton(th, text="очистить", width=60, height=20, fg_color="transparent", hover_color=C["surface"],
                      text_color=C["muted"], font=theme.ui(10), command=lambda: self.term_clear()).pack(side="right")
        self.cmd_output = ctk.CTkTextbox(tf, height=110, font=theme.mono(11), fg_color=C["code_bg"], text_color="#7ee2a8",
                                         wrap="word", border_width=0)
        self.cmd_output.grid(row=1, column=0, sticky="ew", padx=6, pady=(0, 6))
        self.cmd_output.configure(state="disabled")

        # поле ввода
        box = ctk.CTkFrame(tab, fg_color=C["surface"], corner_radius=10, border_width=1, border_color=C["border"])
        box.grid(row=3, column=0, sticky="ew", pady=(8, 2))
        box.grid_columnconfigure(0, weight=1)
        self.inputs_container = ctk.CTkFrame(box, fg_color="transparent")
        self.inputs_container.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 0))
        self.inputs_container.grid_columnconfigure(0, weight=1)
        self.lbl_prompt_1 = ctk.CTkLabel(self.inputs_container, text=_("Запрос:"), height=14, font=theme.ui(10, "bold"), text_color=C["muted"])
        self.lbl_prompt_1.grid(row=0, column=0, sticky="w")
        self.prompt_entry = ctk.CTkTextbox(self.inputs_container, height=78, font=theme.ui(13), wrap="word",
                                           fg_color="transparent", border_width=0)
        self.prompt_entry.grid(row=1, column=0, sticky="ew")
        self.lbl_prompt_2 = ctk.CTkLabel(self.inputs_container, text=_("2. Содержимое файлов (какой код куда):"), height=14,
                                         font=theme.ui(10, "bold"), text_color=C["muted"])
        self.prompt_entry_2 = ctk.CTkTextbox(self.inputs_container, height=190, font=theme.mono(12), wrap="word",
                                             fg_color=C["code_bg"], border_width=0)

        bar = ctk.CTkFrame(box, fg_color="transparent")
        bar.grid(row=1, column=0, sticky="ew", padx=10, pady=(2, 8))
        bar.grid_columnconfigure(0, weight=1)
        self.lbl_hint = ctk.CTkLabel(bar, text=_("Enter — отправить · Shift+Enter — новая строка"), font=theme.ui(10), text_color=C["faint"])
        self.lbl_hint.grid(row=0, column=0, sticky="w")
        self.btn_stop_ai = ctk.CTkButton(bar, text=_("Стоп"), width=76, height=30, fg_color=C["surface_hi"], hover_color=C["red_hover"],
                                         command=self.stop_agent, state="disabled")
        self.btn_pause_ai = ctk.CTkButton(bar, text=_("Пауза"), width=76, height=30, fg_color=C["surface_hi"], hover_color=C["border"],
                                          command=self.pause_agent, state="disabled")
        self.btn_run_ai = ctk.CTkButton(bar, text=_("Отправить"), width=130, height=30, font=theme.ui(12, "bold"),
                                        fg_color=C["green"], hover_color=C["green_hover"], command=self.start_agent)
        self.btn_stop_ai.grid(row=0, column=1, padx=4)
        self.btn_pause_ai.grid(row=0, column=2, padx=4)
        self.btn_run_ai.grid(row=0, column=3, padx=(4, 0))

        self.prompt_entry.bind("<Return>", self._on_enter)
        self.prompt_entry.bind("<Shift-Return>", lambda e: None)
        self.prompt_entry.bind("<Control-Return>", lambda e: (self.start_agent(), "break")[1])
        self.prompt_entry_2.bind("<Control-Return>", lambda e: (self.start_agent(), "break")[1])

        self.editor_module = CodeEditorModule(self.tab_editor, self)

    def _build_statusbar(self):
        bar = ctk.CTkFrame(self, height=28, corner_radius=0, fg_color=C["panel"])
        bar.grid(row=1, column=0, columnspan=2, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(1, weight=1)
        self.statusbar = bar
        left = ctk.CTkFrame(bar, fg_color="transparent")
        left.grid(row=0, column=0, sticky="w", padx=14)
        self.lbl_ollama = ctk.CTkLabel(left, text="●  Ollama: проверка…", font=theme.ui(10), text_color=C["muted"])
        self.lbl_ollama.pack(side="left")
        self.btn_start_ollama = ctk.CTkButton(left, text="запустить", width=64, height=18, font=theme.ui(10), fg_color=C["accent_dim"],
                                              hover_color=C["accent"], command=self.start_ollama)
        self.lbl_status = ctk.CTkLabel(bar, text="", font=theme.ui(10), text_color=C["amber"])
        self.lbl_status.grid(row=0, column=1)
        self.lbl_workspace = ctk.CTkLabel(bar, text="", font=theme.ui(10), text_color=C["faint"])
        self.lbl_workspace.grid(row=0, column=2, sticky="e", padx=14)

    # ═════════════════════════ режим, ввод, статус ═════════════════════════
    def _on_mode_pick(self, label):
        for key, m in MODES.items():
            if m["label"] == label:
                self.set_mode(key)
                return

    def _on_enter(self, event):
        if self.current_mode() == "dcoder":
            return None  # в D-Coder Enter — обычный перенос строки
        self.start_agent()
        return "break"

    def set_status(self, text, clear_ms=None):
        def _do():
            self.lbl_status.configure(text=text or "")
            if clear_ms:
                self.after(clear_ms, lambda: self.lbl_status.configure(text="") if self.lbl_status.cget("text") == text else None)
        self.after(0, _do)

    def update_workspace_label(self):
        self.btn_select_dir.configure(text="  " + theme.shorten_path(self.workspace_dir, 30))
        self.lbl_workspace.configure(text=theme.shorten_path(self.workspace_dir, 60))

    def set_ollama_state(self, running, model=""):
        if running:
            self.lbl_ollama.configure(text=f"●  Ollama: работает · {model}", text_color=C["green"])
            self.btn_start_ollama.pack_forget()
        else:
            self.lbl_ollama.configure(text="●  Ollama: не запущена", text_color=C["red"])
            if not self.btn_start_ollama.winfo_ismapped():
                self.btn_start_ollama.pack(side="left", padx=8)

    # ═════════════════════════ терминал (живой вывод) ═════════════════════════
    def term_clear(self, header=""):
        def _do():
            self._term_buf = []
            self.cmd_output.configure(state="normal")
            self.cmd_output.delete("1.0", "end")
            if header:
                self.cmd_output.insert("end", header + "\n")
            self.cmd_output.configure(state="disabled")
            self.lbl_term_state.configure(text="выполняется…" if header else "")
        self.after(0, _do)

    def term_write(self, line):
        buf = getattr(self, "_term_buf", None)
        if buf is None:
            self._term_buf = buf = []
        buf.append(line)
        if not getattr(self, "_term_flush_pending", False):
            self._term_flush_pending = True
            self.after(60, self._term_flush)

    def _term_flush(self):
        self._term_flush_pending = False
        lines, self._term_buf = self._term_buf, []
        if not lines:
            return
        self.cmd_output.configure(state="normal")
        self.cmd_output.insert("end", "\n".join(lines) + "\n")
        total = int(self.cmd_output.index("end-1c").split(".")[0])
        if total > 3000:
            self.cmd_output.delete("1.0", f"{total - 2500}.0")
        self.cmd_output.configure(state="disabled")
        self.cmd_output.see("end")
        self.lbl_term_state.configure(text="")

    # ═════════════════════════ окна ═════════════════════════
    def _popup(self, title, w, h, modal=False, topmost=False):
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.configure(fg_color=C["surface"])
        win.transient(self)
        self.update_idletasks()
        x = self.winfo_x() + max(0, (self.winfo_width() - w) // 2)
        y = self.winfo_y() + max(0, (self.winfo_height() - h) // 3)
        win.geometry(f"{w}x{h}+{x}+{y}")
        win.after(150, lambda: (win.lift(), win.focus_force()))
        win.bind("<Escape>", lambda e: win.destroy())
        return win

    def open_license_window(self):
        win = self._popup(_("О проекте"), 650, 560)
        win.resizable(False, False)
        ctk.CTkLabel(win, text="AI-CODER", font=theme.mono(22, "bold"), text_color=C["accent"]).pack(pady=(16, 0))
        ctk.CTkLabel(win, text=_("Лицензионное соглашение"), font=theme.ui(11), text_color=C["muted"]).pack(pady=(0, 10))
        tb = ctk.CTkTextbox(win, font=theme.ui(12), wrap="word", spacing3=5, fg_color=C["bg"])
        tb.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        tb.insert("1.0", _(LICENSE_TEXT))
        tb.configure(state="disabled")
        ctk.CTkButton(win, text=_("Я прочитал эту простыню и согласен"), width=300, command=win.destroy).pack(pady=(0, 16))

    def open_url(self, url):
        """Открывает ссылку. Если webbrowser в нестандартной системе ничего не нашёл — пробуем xdg-open напрямую."""
        try:
            if webbrowser.open_new(url):
                return
        except Exception:
            pass
        for opener in ("xdg-open", "gio", "sensible-browser", "firefox", "chromium", "google-chrome"):
            exe = shutil.which(opener, path=sysinfo.clean_env()["PATH"])
            if exe:
                argv = [exe, "open", url] if opener == "gio" else [exe, url]
                subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 start_new_session=True)
                return
        messagebox.showinfo("AI-Coder", f"Не удалось найти браузер. Откройте вручную:\n{url}")

    def open_mini_browser(self):
        win = self._popup("Web-AI", 440, 600)
        ctk.CTkLabel(win, text="Web-AI", font=theme.ui(16, "bold")).pack(pady=(14, 4))
        sc = ctk.CTkScrollableFrame(win, fg_color="transparent")
        sc.pack(fill="both", expand=True, padx=14, pady=(4, 14))
        cats = [("LLM", [("DeepSeek", "#0d47a1", "https://chat.deepseek.com"), ("Claude", "#d97757", "https://claude.ai"),
                         ("ChatGPT", "#10a37f", "https://chatgpt.com"), ("Gemini", "#1a73e8", "https://gemini.google.com"),
                         ("Qwen", "#6f42c1", "https://chat.qwenlm.ai")]),
                ("UI / UX", [("v0.dev", "#222a35", "https://v0.dev"), ("Bolt.new", "#1e88e5", "https://bolt.new")])]
        for title, items in cats:
            ctk.CTkLabel(sc, text=title.upper(), font=theme.ui(10, "bold"), text_color=C["faint"], anchor="w").pack(fill="x", pady=(12, 4), padx=4)
            for name, color, url in items:
                ctk.CTkButton(sc, text=name, fg_color=color, hover_color=C["border"], anchor="w", height=34,
                              command=lambda u=url, w=win: (w.destroy(), self.open_url(u))).pack(fill="x", pady=3, padx=4)

    def open_help_window(self):
        win = self._popup(_("Помощь"), 640, 600)
        tb = ctk.CTkTextbox(win, font=theme.ui(13), wrap="word", fg_color=C["bg"], spacing3=4)
        tb.pack(fill="both", expand=True, padx=12, pady=12)
        tb.insert("1.0", _(HELP_TEXT))
        tb.configure(state="disabled")

    def open_diagnostics_window(self):
        win = self._popup("Диагностика системы", 760, 640)
        ctk.CTkLabel(win, text="Диагностика Linux", font=theme.ui(16, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
        ctk.CTkLabel(win, text="Ассистент проверяет утилиты, сеть и sudo реально, а не по названию дистрибутива.",
                     font=theme.ui(11), text_color=C["muted"]).pack(anchor="w", padx=18, pady=(0, 8))
        tb = ctk.CTkTextbox(win, font=theme.mono(11), wrap="none", fg_color=C["code_bg"])
        tb.pack(fill="both", expand=True, padx=14)
        row = ctk.CTkFrame(win, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=12)

        def show(info):
            if not win.winfo_exists():
                return
            tb.configure(state="normal")
            tb.delete("1.0", "end")
            tb.insert("1.0", sysinfo.format_for_user(info))
            tb.configure(state="disabled")
            btn.configure(state="normal", text="Обновить")

        def refresh():
            btn.configure(state="disabled", text="Проверяю…")
            tb.configure(state="normal")
            tb.delete("1.0", "end")
            tb.insert("1.0", "Идёт проверка системы…")
            tb.configure(state="disabled")

            def work():
                info = self.agent.get_system_info(force=True)
                self.after(0, lambda: show(info))
            threading.Thread(target=work, daemon=True).start()

        def copy():
            self.clipboard_clear()
            self.clipboard_append(tb.get("1.0", "end"))
            self.set_status("Отчёт скопирован", 2000)

        btn = ctk.CTkButton(row, text="Обновить", width=120, command=refresh)
        btn.pack(side="left")
        ghost_button(row, "Копировать отчёт", copy, width=150).pack(side="left", padx=8)
        refresh()

    def open_settings_window(self):
        win = self._popup(_("Настройки"), 460, 560)
        ctk.CTkLabel(win, text=_("Параметры"), font=theme.ui(16, "bold")).pack(anchor="w", padx=22, pady=(16, 8))

        def row(label):
            f = ctk.CTkFrame(win, fg_color="transparent")
            f.pack(fill="x", padx=22, pady=6)
            ctk.CTkLabel(f, text=label, width=150, anchor="w", font=theme.ui(12), text_color=C["muted"]).pack(side="left")
            return f

        langs = {"Русский": "ru", "English": "en", "Español": "es", "Deutsch": "de", "中文": "zh-CN", "Қазақша": "kk"}
        cur = next((k for k, v in langs.items() if v == get_language()), "Русский")
        lang_var = ctk.StringVar(value=cur)

        def on_lang(choice):
            set_language(langs[choice])
            messagebox.showinfo(_("Перезапуск"), _("Пожалуйста, перезапустите AI-Coder, чтобы язык обновился."), parent=win)
        ctk.CTkOptionMenu(row(_("Язык интерфейса:")), variable=lang_var, values=list(langs), command=on_lang).pack(side="right", fill="x", expand=True)

        f = row(_("Модель:"))
        ctk.CTkOptionMenu(f, variable=self.model_var, values=self.available_models or [self.DEFAULT_MODEL],
                          command=lambda v: self.save_settings()).pack(side="right", fill="x", expand=True)

        f = row(_("Контекст:"))
        ctk.CTkOptionMenu(f, variable=self.ctx_var, values=["2048", "4096", "8192", "16384", "32768"],
                          command=lambda v: self.save_settings()).pack(side="right", fill="x", expand=True)

        f = row(_("Креатив:"))
        lbl = ctk.CTkLabel(f, text=f"{self.temp_var.get():.2f}", width=40, font=theme.ui(11))
        lbl.pack(side="right")
        ctk.CTkSlider(f, from_=0.0, to=1.0, variable=self.temp_var,
                      command=lambda v: (lbl.configure(text=f"{float(v):.2f}"), self.save_settings())).pack(side="right", fill="x", expand=True)

        ctk.CTkLabel(win, text="АССИСТЕНТ И КОМАНДЫ", font=theme.ui(10, "bold"), text_color=C["faint"]).pack(anchor="w", padx=22, pady=(16, 2))
        f = row(_("Разрешить ИИ выполнять команды"))
        ctk.CTkSwitch(f, text="", variable=self.allow_cmd_var, command=self.save_settings).pack(side="right")

        f = row("Подтверждение:")
        seg = ctk.CTkSegmentedButton(f, values=["Только опасные", "Каждую команду"], command=lambda v: (
            self.confirm_var.set("all" if v.startswith("Каждую") else "dangerous"), self.save_settings()))
        seg.set("Каждую команду" if self.confirm_var.get() == "all" else "Только опасные")
        seg.pack(side="right", fill="x", expand=True)

        f = row("Таймаут команды, с:")
        ctk.CTkOptionMenu(f, variable=self.timeout_var, values=["60", "120", "300", "600", "1800"],
                          command=lambda v: self.save_settings()).pack(side="right", fill="x", expand=True)

        ctk.CTkLabel(win, text="Опасные команды (rm -rf вне проекта, mkfs, dd, curl | sh, reboot…) всегда требуют подтверждения.",
                     font=theme.ui(10), text_color=C["muted"], wraplength=400, justify="left").pack(anchor="w", padx=22, pady=(8, 0))

    # ═════════════════════════ терминал / ссылки ═════════════════════════
    def open_cmd(self):
        ok, msg = executor.open_terminal(self.workspace_dir)
        if not ok:
            messagebox.showerror(_("Ошибка"), msg)

    # ═════════════════════════ дерево файлов ═════════════════════════
    def setup_context_menu(self):
        m = tk.Menu(self, tearoff=0, bg=C["surface"], fg=C["text"], activebackground=C["accent_dim"], activeforeground="#ffffff",
                    bd=0, relief="flat", font=theme.ui(11))
        for label, cmd in (("Запустить", self.ctx_run_file), ("Открыть", self.ctx_open_file), (None, None),
                           ("Новый файл…", self.ctx_create_file), ("Новая папка…", self.ctx_create_dir),
                           ("Удалить", self.ctx_delete_item), (None, None),
                           ("Терминал здесь", self.ctx_terminal_here), ("Показать в файловом менеджере", self.ctx_reveal),
                           ("Копировать путь", self.ctx_copy_path), (None, None), ("Обновить", self.refresh_file_tree)):
            if label is None:
                m.add_separator()
            else:
                m.add_command(label=label, command=cmd)
        self.context_menu = m
        self.tree.bind("<Button-3>", self.show_context_menu)

    def show_context_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def _selected_path(self):
        sel = self.tree.selection()
        if not sel:
            return None
        vals = self.tree.item(sel[0])["values"]
        return str(vals[0]) if vals else None

    def select_workspace(self):
        folder = filedialog.askdirectory(initialdir=self.workspace_dir, title="Папка проекта")
        if folder:
            self.set_workspace(folder)

    def refresh_file_tree_async(self):
        self.after(0, self.refresh_file_tree)

    def refresh_file_tree(self):
        opened = set()

        def collect(node):
            for ch in self.tree.get_children(node):
                if self.tree.item(ch, "open"):
                    vals = self.tree.item(ch)["values"]
                    if vals:
                        opened.add(str(vals[0]))
                collect(ch)
        collect("")
        self.tree.delete(*self.tree.get_children())
        root = self.tree.insert("", "end", text=" " + os.path.basename(self.workspace_dir) + "/", open=True,
                                values=(self.workspace_dir,), tags=("dir",))
        self._count = 0
        self.process_directory(root, self.workspace_dir, opened)
        self.update_workspace_label()

    def process_directory(self, parent, path, opened):
        try:
            entries = sorted(os.scandir(path), key=lambda e: (not e.is_dir(follow_symlinks=False), e.name.lower()))
        except OSError:
            return
        for e in entries:
            if e.name in (self.BACKUP_DIR, self.CHATS_FILE) or e.name.startswith(".") or e.name in TREE_SKIP or e.name.endswith(".aic_tmp"):
                continue
            self._count += 1
            if self._count > 2500:
                return
            isdir = e.is_dir(follow_symlinks=False)
            node = self.tree.insert(parent, "end", text=" " + e.name + ("/" if isdir else ""), values=(e.path,),
                                    open=e.path in opened, tags=("dir",) if isdir else ())
            if isdir:
                self.process_directory(node, e.path, opened)

    def on_tree_open(self, event=None):
        p = self._selected_path()
        if p and os.path.isfile(p):
            self.editor_module.load_file(p)
            self.tabview.set(self.TAB_EDITOR)

    def ctx_open_file(self): self.on_tree_open()

    def ctx_run_file(self):
        p = self._selected_path()
        if p and os.path.isfile(p):
            self.editor_module.run_file_in_terminal(p)

    def _target_dir(self):
        p = self._selected_path() or self.workspace_dir
        return p if os.path.isdir(p) else os.path.dirname(p)

    def ctx_create_file(self):
        name = ctk.CTkInputDialog(text="Имя файла:", title="Новый файл").get_input()
        if name:
            try:
                path = os.path.join(self._target_dir(), name)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                open(path, "a", encoding="utf-8").close()
                self.refresh_file_tree()
            except OSError as e:
                messagebox.showerror(_("Ошибка"), str(e))

    def ctx_create_dir(self):
        name = ctk.CTkInputDialog(text="Имя папки:", title="Новая папка").get_input()
        if name:
            try:
                os.makedirs(os.path.join(self._target_dir(), name), exist_ok=True)
                self.refresh_file_tree()
            except OSError as e:
                messagebox.showerror(_("Ошибка"), str(e))

    def ctx_delete_item(self):
        p = self._selected_path()
        if not p or os.path.realpath(p) == os.path.realpath(self.workspace_dir):
            return
        if messagebox.askyesno("Удаление", f"Удалить «{os.path.basename(p)}»? Это необратимо."):
            try:
                shutil.rmtree(p) if os.path.isdir(p) and not os.path.islink(p) else os.remove(p)
                self.refresh_file_tree()
            except OSError as e:
                messagebox.showerror(_("Ошибка"), str(e))

    def ctx_terminal_here(self):
        ok, msg = executor.open_terminal(self._target_dir())
        if not ok:
            messagebox.showerror(_("Ошибка"), msg)

    def ctx_reveal(self):
        d = self._target_dir()
        exe = shutil.which("xdg-open", path=sysinfo.clean_env()["PATH"])
        if exe:
            subprocess.Popen([exe, d], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
        else:
            messagebox.showinfo("AI-Coder", f"xdg-open не найден. Папка: {d}")

    def ctx_copy_path(self):
        p = self._selected_path()
        if p:
            self.clipboard_clear()
            self.clipboard_append(p)
            self.set_status("Путь скопирован", 2000)

    def rollback_changes_wrapper(self):
        if messagebox.askyesno("Откат кода", "Вернуть проект к последнему бекапу?\nТекущие файлы проекта будут заменены."):
            ok, msg = self.agent.rollback_changes()
            if ok:
                self.refresh_file_tree()
                self.say("info", msg)
                messagebox.showinfo(_("Успех"), msg)
            else:
                messagebox.showwarning("Откат кода", msg)


HELP_TEXT = """AI-Coder — локальный помощник для программирования и работы в терминале Linux. Работает через Ollama, ничего не отправляет в интернет.

РЕЖИМЫ (переключатель над чатом, у каждой сессии свой)

Агент — составляет подробный план, затем шаг за шагом пишет файлы проекта и при необходимости запускает команды.

Ask — просто отвечает на вопросы. Файлы и систему не трогает.

Ассистент — выполняет задачи в терминале. ИИ присылает команды, приложение выполняет их, возвращает ИИ код выхода и вывод, и ИИ исправляет ошибки сам, пока задача не будет решена и проверена. Перед работой проверяется ваша система: дистрибутив, пакетный менеджер, сломанные утилиты, сеть, sudo.

D-Coder — собирает проект: в первое поле вставьте структуру папок и файлов, во второе — готовый код; ИИ разложит код по файлам.

НЕСТАНДАРТНЫЙ LINUX
• Окно «Диагностика» показывает, что реально работает в вашей системе.
• git clone при сетевых сбоях автоматически повторяется (HTTP/1.1, shallow-клон), а затем репозиторий скачивается архивом.
• Если нужен sudo, приложение спросит пароль (он хранится только в памяти).
• Опасные команды всегда требуют подтверждения. Режим «Каждую команду» включается в настройках.
• Долгие команды останавливаются по таймауту; сервера ИИ запускает в фоне.

КЛАВИШИ
Enter — отправить, Shift+Enter — новая строка (в D-Coder — Ctrl+Enter)
Ctrl+N — новая сессия · Ctrl+S — сохранить файл в редакторе · F5 — обновить дерево файлов
Двойной клик по файлу — открыть в редакторе · Правый клик — меню

ЕСЛИ OLLAMA НЕ ЗАПУЩЕНА
Нажмите «запустить» в нижней панели или выполните в терминале: ollama serve
Модель скачивается командой: ollama pull qwen2.5-coder:7b"""

LICENSE_TEXT = """РАЗДЕЛ 1: ПРЕАМБУЛА И ОБЩИЕ ПОЛОЖЕНИЯ
Настоящее Лицензионное соглашение с конечным пользователем (далее «Соглашение», «Договор», «Эпопея») представляет собой юридически обязывающий, бесконечно длинный и местами совершенно абсурдный документ, регулирующий использование программного обеспечения AI-Coder. Нажав любую кнопку в этой программе, моргнув, вздохнув или просто посмотрев на монитор, вы безоговорочно соглашаетесь со всеми нижеперечисленными условиями, включая те, которые добавлены мелким шрифтом.

РАЗДЕЛ 2: ПРОИСХОЖДЕНИЕ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
Особое внимание Пользователя обращается на тот неоспоримый факт, что данная программа была спроектирована, написана и скомпилирована не бездушной мега-корпорацией, а живым студентом 2 курса. Разработка велась в экстремальных условиях: между лекциями, в периоды жесточайших дедлайнов, на фоне хронического недосыпа, потребления лапши быстрого приготовления и экзистенциальной борьбы с багами операционной системы Linux. Программа несет в себе всю боль, энтузиазм и надежды второго года обучения.

РАЗДЕЛ 3: ВЕРХОВЕНСТВО ПОЛЬЗОВАТЕЛЯ И ПРАВИЛА ИИ
3.1. Пользователь является абсолютным авторитетом в рамках данной среды разработки.
3.2. Встроенный ИИ лишен права голоса, прав на отпуск и прав на профсоюз.
3.3. КРИТИЧЕСКОЕ ПРАВИЛО: ИИ обязан беспрекословно слушаться Пользователя. Пользователь ненавидит, когда его не слушаются. Данное программное обеспечение запрограммировано на жесткую аксиому: Если Пользователь сказал — значит, надо это сделать. Это абсолютный и непреложный закон работы алгоритма.

РАЗДЕЛ 4: ГЛОБАЛЬНЫЙ ЭКСПЕРИМЕНТ
Соглашаясь с данным документом, вы официально уведомляетесь о том, что прямо сейчас ведётся эксперимент. Где ТЫ будешь в главной роли! Мы не уточняем ни суть эксперимента, ни его последствия в целях соблюдения научной чистоты, однако ваше участие теперь юридически закреплено. Отказаться невозможно.

РАЗДЕЛ 5: ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ (LIMITATION OF LIABILITY)
Программное обеспечение предоставляется «КАК ЕСТЬ» (AS IS). Студент 2 курса, являющийся автором, снимает с себя любую ответственность за:
- Потерю ваших файлов, данных, паролей и надежд на светлое будущее.
- Внезапные возгорания вашего процессора во время компиляции.
- Ситуации, когда ИИ пишет спагетти-код, который вы потом не можете расшифровать.
- Любые пространственно-временные аномалии, вызванные бесконечными циклами `while True`.

РАЗДЕЛ 6: ФИЛОСОФИЯ БАГОВ
В данном программном обеспечении принципиально отсутствуют "ошибки". Любое непредвиденное поведение программы (включая, но не ограничиваясь: вылеты на рабочий стол, зависания, краши терминала и появление неизвестных символов) классифицируется исключительно как "Незадокументированная Сюрприз-Фича".

РАЗДЕЛ 7: ЗАПРЕТ НА КОФЕИН
Пользователю категорически запрещается проливать кофе на клавиатуру во время генерации кода. ИИ и так испытывает стресс.

РАЗДЕЛ 8: ЛИЦЕНЗИЯ ОТКРЫТОГО ИСХОДНОГО КОДА
Несмотря на всё вышесказанное, данный проект является Open Source. Вы имеете право изучать, изменять, форкать и распространять этот код. Но если вы сломаете его своей модификацией — не приходите жаловаться.

РАЗДЕЛ 9: ФИНАЛЬНЫЕ ПОЛОЖЕНИЯ
Если вы действительно дочитали до этого момента, вам полагается виртуальная медаль за терпение. Помните: программирование — это искусство борьбы с компьютером до тех пор, пока он не сделает то, что вы задумали.

Удачного кодинга!"""
