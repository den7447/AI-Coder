#!/usr/bin/env python3
"""AI-Coder — локальный ИИ-помощник для программирования и терминала Linux (Ollama + CustomTkinter)."""
import json
import os
import platform
import subprocess
import sys
import threading
import time
import traceback
import uuid

APP_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(APP_DIR)
sys.path.insert(0, APP_DIR)

if not sys.platform.startswith("linux"):
    sys.exit("AI-Coder поддерживает только Linux.")


# ───────────── проверка зависимостей (до импорта GUI) ─────────────
def check_dependencies():
    """tkinter ставится только системным пакетом; customtkinter/requests/Pillow — через pip."""
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("\n[AI-Coder] Не найден tkinter — это системный пакет, pip его не ставит.\n"
              "Установите для вашего дистрибутива:\n"
              "  Debian/Ubuntu/Mint:  sudo apt install python3-tk\n"
              "  Fedora/RHEL:         sudo dnf install python3-tkinter\n"
              "  Arch/Manjaro:        sudo pacman -S tk\n"
              "  openSUSE:            sudo zypper install python3-tk\n"
              "  Alpine:              sudo apk add py3-tkinter\n")
        sys.exit(1)

    need = {"customtkinter": "customtkinter", "requests": "requests", "PIL": "pillow"}
    missing = []
    for mod, pip_name in need.items():
        try:
            __import__(mod)
        except ImportError:
            missing.append(pip_name)
    if not missing or os.environ.get("AI_CODER_INSTALL_LOOP_PREVENT") == "1":
        return
    print(f"\n[AI-Coder] Не хватает библиотек: {', '.join(missing)}. Устанавливаю…")
    base = [sys.executable, "-m", "pip", "install", "--user", *missing]
    for extra in ([], ["--break-system-packages"]):  # второй вариант — для дистрибутивов с PEP 668
        try:
            subprocess.check_call(base + extra)
            os.environ["AI_CODER_INSTALL_LOOP_PREVENT"] = "1"
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except (subprocess.CalledProcessError, OSError):
            continue
    print("\n[AI-Coder] Автоустановка не удалась. Запустите ./run.sh (создаст изолированное окружение) или:\n"
          f"  python3 -m venv --system-site-packages .venv && .venv/bin/pip install {' '.join(missing)}\n")
    sys.exit(1)


check_dependencies()

import tkinter as tk  # noqa: E402
from tkinter import messagebox  # noqa: E402

import customtkinter as ctk  # noqa: E402

import sysinfo  # noqa: E402
import theme  # noqa: E402
from agent import AIAgent  # noqa: E402
from backup_manager import BackupManager  # noqa: E402
from dialogs import ConfirmDialog, PasswordDialog  # noqa: E402
from gui import UIMixin  # noqa: E402
from llm import LLMError  # noqa: E402
from theme import C, MODES, MODE_ORDER  # noqa: E402

DEFAULT_MODEL = "qwen2.5-coder:7b"
CHATS_FILE = "chats.json"
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
BACKUP_DIR = ".ai_backup"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

WELCOME = {
    "agent": ["Опишите, что нужно создать — агент составит план и напишет файлы проекта.",
              "Например:  «Сделай телеграм-бота на Python с командой /start»"],
    "query": ["Задайте вопрос по коду или Linux — ответ без изменений в проекте.",
              "Например:  «Чем отличается venv от virtualenv?»"],
    "assistant": ["Опишите задачу для терминала — ассистент выполнит её по шагам и проверит результат.",
                  "Например:  «Склонируй репозиторий … и установи зависимости»",
                  "Перед стартом проверяется ваша система (дистрибутив, сеть, sudo, сломанные утилиты)."],
    "dcoder": ["Вставьте структуру проекта и готовый код — D-Coder разложит всё по файлам.",
               "Отправка: Ctrl+Enter"],
}


class LoadingSplash(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("AI-Coder")
        self.geometry("460x240")
        self.resizable(False, False)
        self.configure(fg_color=C["panel"])
        try:
            self.attributes("-topmost", True)
            self.overrideredirect(True)  # на некоторых оконных менеджерах не поддерживается — не критично
        except tk.TclError:
            pass
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 460) // 2
        y = (self.winfo_screenheight() - 240) // 2
        self.geometry(f"460x240+{x}+{y}")
        frame = ctk.CTkFrame(self, fg_color=C["panel"], border_width=1, border_color=C["border"], corner_radius=10)
        frame.pack(fill="both", expand=True, padx=2, pady=2)
        ctk.CTkLabel(frame, text="AI-CODER", font=theme.mono(30, "bold"), text_color=C["accent"]).pack(pady=(44, 2))
        ctk.CTkLabel(frame, text="Локальная среда разработки для Linux", font=theme.ui(12), text_color=C["muted"]).pack()
        self.label_status = ctk.CTkLabel(frame, text="Запуск…", font=theme.ui(11), text_color=C["muted"])
        self.label_status.pack(pady=(26, 6))
        self.progress_bar = ctk.CTkProgressBar(frame, width=300, height=4, mode="indeterminate", progress_color=C["accent"],
                                               fg_color=C["surface"])
        self.progress_bar.pack()

    def update_status(self, text):
        if self.winfo_exists():
            self.label_status.configure(text=text)


class AdvancedAICoder(ctk.CTk, UIMixin):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title("AI-Coder")
        self.geometry("1440x900")
        self.minsize(1040, 660)
        theme.init_fonts(self)
        theme.apply_ttk_style(self)

        try:
            self.iconphoto(True, tk.PhotoImage(file=os.path.join(APP_DIR, "icon.png")))
        except Exception:
            pass

        self.DEFAULT_MODEL = DEFAULT_MODEL
        self.CHATS_FILE = CHATS_FILE
        self.BACKUP_DIR = BACKUP_DIR
        self.chats_path = os.path.join(APP_DIR, CHATS_FILE)

        self.current_open_file = None
        self.cancel_flag = False
        self.pause_flag = False
        self.task_running = False
        self.thinking_anim_active = False
        self.thinking_dot_count = 1
        self.chats = {}
        self.current_chat_id = None
        self.available_models = [DEFAULT_MODEL]
        self._save_pending = False
        self._stream = None
        self._stream_buf = []
        self._stream_flush_pending = False
        self._stream_lock = threading.Lock()

        self.model_var = ctk.StringVar(value=DEFAULT_MODEL)
        self.ctx_var = ctk.StringVar(value="8192")
        self.temp_var = ctk.DoubleVar(value=0.2)
        self.allow_cmd_var = ctk.BooleanVar(value=True)
        self.confirm_var = ctk.StringVar(value="dangerous")
        self.timeout_var = ctk.StringVar(value="300")
        self.workspace_dir = os.path.join(APP_DIR, "Project-AI")
        self.load_settings()
        os.makedirs(self.workspace_dir, exist_ok=True)

        self.backup_manager = BackupManager(self.workspace_dir, BACKUP_DIR)
        self.load_chats()
        self.agent = AIAgent(self)
        self.setup_ui()
        self.refresh_file_tree()
        self.load_chat_list_ui()
        self.bind("<Control-n>", lambda e: self.new_chat("Новый проект"))
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        if not self.chats:
            self.new_chat("Новый проект")
        else:
            self.switch_chat(list(self.chats.keys())[0])

        try:
            self.splash = LoadingSplash(self)
            self.splash.progress_bar.start()
        except Exception:
            self.splash = None
        threading.Thread(target=self._startup_workflow, daemon=True).start()

    # ───────────── настройки ─────────────
    def load_settings(self):
        try:
            with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                s = json.load(f)
        except (OSError, ValueError):
            return
        self.model_var.set(s.get("model", DEFAULT_MODEL))
        self.ctx_var.set(str(s.get("ctx", "8192")))
        self.temp_var.set(float(s.get("temp", 0.2)))
        self.allow_cmd_var.set(bool(s.get("allow_cmd", True)))
        self.confirm_var.set(s.get("confirm", "dangerous"))
        self.timeout_var.set(str(s.get("timeout", "300")))
        ws = s.get("workspace")
        if ws and os.path.isdir(ws):
            self.workspace_dir = ws

    def save_settings(self):
        data = {"model": self.model_var.get(), "ctx": self.ctx_var.get(), "temp": round(float(self.temp_var.get()), 2),
                "allow_cmd": bool(self.allow_cmd_var.get()), "confirm": self.confirm_var.get(),
                "timeout": self.timeout_var.get(), "workspace": self.workspace_dir}
        try:
            tmp = SETTINGS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, SETTINGS_FILE)
        except OSError:
            pass

    def confirm_mode(self):
        return "all" if self.confirm_var.get() == "all" else "dangerous"

    def cmd_timeout(self):
        try:
            return max(10, int(self.timeout_var.get()))
        except ValueError:
            return 300

    def set_workspace(self, folder):
        self.workspace_dir = folder
        self.backup_manager.workspace_dir = folder
        self.agent._runners.clear()
        self.agent._info = None
        self.save_settings()
        self.refresh_file_tree()
        self.say("system", f"Рабочая папка: {folder}")

    # ───────────── запуск ─────────────
    def _startup_workflow(self):
        self.after(0, lambda: self.splash and self.splash.update_status("Поиск моделей Ollama…"))
        self._load_local_models()
        self.after(0, lambda: self.splash and self.splash.update_status("Проверка системы…"))
        try:
            self.agent.get_system_info()
        except Exception:
            traceback.print_exc()
        self.after(0, self._finish_startup)
        threading.Thread(target=self._ollama_watch, daemon=True).start()

    def _load_local_models(self):
        try:
            models = self.agent.llm.list_models()
        except Exception:
            return
        if models:
            self.available_models = models
            if self.model_var.get() not in models:
                self.model_var.set(DEFAULT_MODEL if DEFAULT_MODEL in models else models[0])
        else:
            self.available_models = ["Нет загруженных моделей"]

    def _ollama_watch(self):
        while True:
            running = self.agent.llm.is_running()
            if running and self.available_models in (["Нет загруженных моделей"], [DEFAULT_MODEL]):
                self._load_local_models()
            try:
                self.after(0, lambda r=running: self.set_ollama_state(r, self.model_var.get()))
            except Exception:
                return
            time.sleep(5)

    def start_ollama(self):
        self.set_status("Запускаю Ollama…")

        def work():
            ok, msg = self.agent.llm.start_server()
            self.set_status(msg, 6000)
            if ok:
                self._load_local_models()
        threading.Thread(target=work, daemon=True).start()

    def _finish_startup(self):
        if self.splash:
            try:
                self.splash.progress_bar.stop()
                self.splash.destroy()
            except Exception:
                pass
        self.deiconify()
        self.lift()
        self.update_workspace_label()
        if getattr(self, "is_first_run", False):
            self.after(500, self.open_license_window)
            self.is_first_run = False

    def on_close(self):
        self.cancel_flag = True
        self._flush_chats()
        self.save_settings()
        self.destroy()

    # ───────────── чаты ─────────────
    def load_chats(self):
        self.is_first_run = not os.path.exists(self.chats_path)
        try:
            with open(self.chats_path, "r", encoding="utf-8") as f:
                self.chats = json.load(f)
        except (OSError, ValueError):
            self.chats = {}
        for chat in self.chats.values():  # миграция старого формата: сообщения были просто строками
            chat["messages"] = [m if isinstance(m, dict) else {"k": "system", "t": str(m)} for m in chat.get("messages", [])]
            chat.setdefault("history", [])
            chat.setdefault("state", {})
            chat.setdefault("mode", "agent")

    def save_chats(self):
        """Потокобезопасно: запись откладывается и выполняется в главном потоке."""
        self.after(0, self._queue_save)

    def _queue_save(self):
        if not self._save_pending:
            self._save_pending = True
            self.after(400, self._flush_chats)

    def _flush_chats(self):
        self._save_pending = False
        try:
            tmp = self.chats_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.chats, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.chats_path)
        except (OSError, TypeError, ValueError) as e:
            print(f"Ошибка сохранения чатов: {e}")

    def load_chat_list_ui(self):
        for w in self.chats_frame.winfo_children():
            w.destroy()
        for cid, chat in list(self.chats.items()):
            row = ctk.CTkFrame(self.chats_frame, fg_color="transparent")
            row.pack(fill="x", pady=1)
            row.grid_columnconfigure(0, weight=1)
            active = cid == self.current_chat_id
            mode_color = MODES.get(chat.get("mode", "agent"), MODES["agent"])["color"]
            title = chat["title"] if len(chat["title"]) <= 26 else chat["title"][:25] + "…"
            ctk.CTkButton(row, text="●  " + title, anchor="w", height=32, font=theme.ui(12),
                          fg_color=C["surface_hi"] if active else "transparent",
                          hover_color=C["surface_hi"], text_color=C["text"] if active else C["muted"],
                          command=lambda i=cid: self.switch_chat(i)).grid(row=0, column=0, sticky="ew")
            ctk.CTkButton(row, text="×", width=26, height=26, font=theme.ui(14), fg_color="transparent",
                          hover_color=C["red_hover"], text_color=C["faint"],
                          command=lambda i=cid: self.delete_chat(i)).grid(row=0, column=1, padx=(2, 2))

    def delete_chat(self, cid):
        if cid not in self.chats:
            return
        title = self.chats[cid].get("title", "")
        if not messagebox.askyesno("Удаление сессии", f"Удалить сессию «{title}» безвозвратно?"):
            return
        del self.chats[cid]
        self.save_chats()
        try:
            os.remove(os.path.join(self.workspace_dir, BACKUP_DIR, "chat_logs", f"{cid}.log"))
        except OSError:
            pass
        if self.current_chat_id == cid:
            if self.chats:
                self.switch_chat(list(self.chats.keys())[0])
            else:
                self.current_chat_id = None
                self.new_chat("Новый проект")
        else:
            self.load_chat_list_ui()

    def new_chat(self, title):
        cid = str(uuid.uuid4())[:8]
        self.chats[cid] = {"title": title, "mode": "agent", "messages": [], "history": [], "state": {}}
        self.save_chats()
        self.switch_chat(cid)

    def switch_chat(self, cid):
        if cid not in self.chats:
            return
        self.current_chat_id = cid
        self.load_chat_list_ui()
        self.update_mode_ui()
        self._render_current_chat()

    def _render_current_chat(self):
        chat = self.chats[self.current_chat_id]
        mode = chat.get("mode", "agent")
        w = WELCOME[mode]
        self.chat_view.load(chat["messages"], welcome=(MODES[mode]["label"], w[0], w[1:]))

    def current_mode(self):
        return self.chats.get(self.current_chat_id, {}).get("mode", "agent")

    def set_mode(self, mode):
        if self.current_chat_id not in self.chats:
            return
        self.chats[self.current_chat_id]["mode"] = mode
        self.save_chats()
        self.update_mode_ui()
        self.load_chat_list_ui()
        if not self.chats[self.current_chat_id]["messages"]:
            self._render_current_chat()

    def update_mode_ui(self):
        chat = self.chats.get(self.current_chat_id)
        if not chat:
            return
        mode = chat.get("mode", "agent")
        m = MODES[mode]
        self.mode_var.set(m["label"])
        self.seg_mode.configure(selected_color=m["color"], selected_hover_color=m["hover"])
        self.lbl_mode_desc.configure(text=m["desc"])
        self.lbl_chat_title.configure(text=chat["title"])
        self.chat_view.set_mode_color(m["color"])
        self.lbl_prompt_2.grid_remove()
        self.prompt_entry_2.grid_remove()
        self.lbl_prompt_1.configure(text="Запрос:")
        self.lbl_hint.configure(text="Enter — отправить · Shift+Enter — новая строка")
        if mode in ("assistant", "agent"):
            self.terminal_frame.grid()
        else:
            self.terminal_frame.grid_remove()
        if mode == "dcoder":
            self.lbl_prompt_1.configure(text="1. Структура проекта (папки и файлы):")
            self.lbl_prompt_2.grid(row=2, column=0, sticky="w", pady=(6, 2))
            self.prompt_entry_2.grid(row=3, column=0, sticky="ew")
            self.lbl_hint.configure(text="Ctrl+Enter — отправить")

    # ───────────── вывод в чат (потокобезопасно) ─────────────
    def say(self, kind, text, chat_id=None):
        def _do():
            cid = chat_id or self.current_chat_id
            if not cid or cid not in self.chats or not str(text).strip():
                return
            self.chats[cid]["messages"].append({"k": kind, "t": str(text)})
            self.save_chats()
            if cid == self.current_chat_id:
                self.chat_view.add(kind, str(text))
        self.after(0, _do)

    def stream_begin(self, cid, kind):
        def _do():
            self._stream = {"cid": cid, "kind": kind, "text": []}
            if cid == self.current_chat_id:
                self.chat_view.begin_stream(kind)
        self.after(0, _do)

    def stream_token(self, cid, tok):
        with self._stream_lock:
            self._stream_buf.append((cid, tok))
            schedule = not self._stream_flush_pending
            self._stream_flush_pending = True
        if schedule:
            self.after(40, self._stream_flush)

    def _stream_flush(self):
        with self._stream_lock:
            items, self._stream_buf = self._stream_buf, []
            self._stream_flush_pending = False
        st = self._stream
        if not st:
            return
        chunk = "".join(t for c, t in items if c == st["cid"])
        if chunk:
            st["text"].append(chunk)
            if st["cid"] == self.current_chat_id:
                self.chat_view.stream(chunk)

    def stream_end(self, cid):
        def _do():
            self._stream_flush()
            st, self._stream = self._stream, None
            if not st:
                return
            text = "".join(st["text"])
            if text.strip():
                self.chats[st["cid"]]["messages"].append({"k": st["kind"], "t": text})
                self.save_chats()
            if st["cid"] == self.current_chat_id:
                self.chat_view.end_stream(text)
        self.after(0, _do)

    # ───────────── диалоги из рабочего потока ─────────────
    def _ask_in_ui(self, factory, default):
        """Показывает диалог в главном потоке и ждёт ответа в рабочем. Отмена задачи закрывает диалог."""
        ev = threading.Event()
        box = {"r": default}

        def done(v):
            box["r"] = v
            ev.set()
        self.after(0, lambda: box.__setitem__("dlg", factory(done)))
        while not ev.wait(0.2):
            if self.cancel_flag:
                dlg = box.get("dlg")
                if dlg is not None:
                    self.after(0, lambda: dlg.close(default))
                return default
        return box["r"]

    def ask_confirm(self, title, message, command, danger=False):
        return bool(self._ask_in_ui(lambda done: ConfirmDialog(self, title, message, command, danger, done), False))

    def ask_sudo_password(self, retry=False):
        return self._ask_in_ui(lambda done: PasswordDialog(self, retry, done), None)

    # ───────────── управление задачей ─────────────
    def stop_agent(self):
        if not self.task_running:
            return
        self.cancel_flag = True
        self.pause_flag = False
        self.say("warn", "Остановлено пользователем.")
        if self.current_chat_id in self.chats:
            self.chats[self.current_chat_id]["state"] = {}
            self.save_chats()
        self.btn_stop_ai.configure(state="disabled")
        self.btn_pause_ai.configure(state="disabled")

    def pause_agent(self):
        self.pause_flag = True
        self.say("info", "Пауза: остановлюсь после текущего шага.")
        self.btn_pause_ai.configure(state="disabled")

    def start_agent(self):
        if self.task_running:
            self.set_status("Задача ещё выполняется — дождитесь окончания или нажмите «Стоп»", 3000)
            return
        task = self.prompt_entry.get("1.0", "end").strip()
        mode = self.current_mode()
        cid = self.current_chat_id
        task2 = None
        if mode == "dcoder":
            task2 = self.prompt_entry_2.get("1.0", "end").strip()
            if not task and not task2:
                return
        elif not task and not self.chats.get(cid, {}).get("state"):
            return

        self.cancel_flag = False
        self.pause_flag = False
        self.task_running = True

        chat = self.chats[cid]
        if chat["title"] in ("Новый чат", "Новый проект") and (task or task2):
            src = task or task2
            chat["title"] = src[:28] + "…" if len(src) > 28 else src
            self.load_chat_list_ui()
            self.lbl_chat_title.configure(text=chat["title"])
            self.save_chats()

        self.prompt_entry.delete("1.0", "end")
        self.prompt_entry_2.delete("1.0", "end")
        self.btn_run_ai.configure(state="disabled")
        self.btn_stop_ai.configure(state="normal")
        self.btn_pause_ai.configure(state="normal")
        self.start_thinking_animation()

        if mode == "dcoder":
            self.say("user", f"Структура проекта:\n{task}\n\n(содержимое файлов передано: {len(task2 or '')} символов)", cid)
        elif task:
            self.say("user", task, cid)
        threading.Thread(target=self._run_task, args=(task, task2, cid, mode), daemon=True).start()

    def _run_task(self, task, task2, chat_id, mode):
        try:
            if mode == "query":
                self.agent.run_query_mode(task, chat_id)
            elif mode == "assistant":
                self.agent.run_assistant_mode(task, chat_id)
            elif mode == "dcoder":
                self.agent.run_dcoder_mode(task, task2, chat_id)
            else:
                self.agent.run_multi_step_pipeline(task, chat_id)
        except LLMError as e:
            self.say("err", str(e), chat_id)
        except Exception as e:
            traceback.print_exc()
            self.say("err", f"Внутренняя ошибка: {type(e).__name__}: {e}", chat_id)
        finally:
            self.after(0, self.stop_thinking_animation)

    def start_thinking_animation(self):
        self.thinking_anim_active = True
        self.thinking_dot_count = 1
        self._animate_thinking()

    def _animate_thinking(self):
        if not self.thinking_anim_active:
            return
        self.btn_run_ai.configure(text="Обработка" + "." * self.thinking_dot_count)
        self.thinking_dot_count = self.thinking_dot_count % 3 + 1
        self.after(400, self._animate_thinking)

    def stop_thinking_animation(self):
        self.thinking_anim_active = False
        self.task_running = False
        self.cancel_flag = False
        self.btn_run_ai.configure(state="normal", text="Отправить")
        self.btn_stop_ai.configure(state="disabled")
        self.btn_pause_ai.configure(state="disabled")
        self.set_status("")


if __name__ == "__main__":
    app = AdvancedAICoder()
    app.mainloop()
