import json
import os
import threading

# Пытаемся импортировать автопереводчик. Если его еще нет, программа не упадет.
try:
    from deep_translator import GoogleTranslator
except ImportError:
    GoogleTranslator = None

APP_DIR = os.path.dirname(os.path.abspath(__file__))
LANG_FILE = os.path.join(APP_DIR, "settings_lang.json")
CACHE_FILE = os.path.join(APP_DIR, "lang_cache.json")

# Вшитый словарь для Английского (чтобы работал оффлайн и без задержек)
EN_DICT = {
    "+  Новая сессия": "+  New session", "СЕССИИ": "SESSIONS", "ПРОЕКТ": "PROJECT",
    "Терминал": "Terminal", "Диагностика": "Diagnostics", "Настройки": "Settings", "Откат кода": "Rollback",
    "Web-ИИ": "Web-AI", "Помощь": "Help", "О проекте": "About", "ТЕРМИНАЛ": "TERMINAL",
    "Запрос:": "Prompt:", "2. Содержимое файлов (какой код куда):": "2. File contents (where code goes):",
    "Enter — отправить · Shift+Enter — новая строка": "Enter — send · Shift+Enter — new line",
    "Отправить": "Send", "Стоп": "Stop", "Пауза": "Pause", "Новый проект": "New project",
    "▶ Запустить проект": "▶ Run project", "Сохранить  Ctrl+S": "Save  Ctrl+S", "Файл не выбран": "No file selected",
    "Параметры": "Preferences", "Модель:": "Model:", "Контекст:": "Context:", "Креатив:": "Creativity:",
    "Разрешить ИИ выполнять команды": "Allow AI to run commands", "Язык интерфейса:": "UI language:",
    "Лицензионное соглашение": "License agreement", "Я прочитал эту простыню и согласен": "I have read this and agree",
    "Перезапуск": "Restart required",
    "Пожалуйста, перезапустите AI-Coder, чтобы язык обновился.": "Please restart AI-Coder to apply the language change.",
    "Ошибка": "Error", "Успех": "Success", "Внимание": "Attention", "Помощь ": "Help",
}

class AutoTranslator:
    def __init__(self):
        self.lang = "ru"
        self.cache = {"en": EN_DICT}
        self.load_settings()
        self.load_cache()

    def load_settings(self):
        if os.path.exists(LANG_FILE):
            try:
                with open(LANG_FILE, "r", encoding="utf-8") as f:
                    self.lang = json.load(f).get("lang", "ru")
            except Exception: pass

    def load_cache(self):
        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    for k, v in loaded.items():
                        if k not in self.cache:
                            self.cache[k] = v
                        else:
                            self.cache[k].update(v)
            except Exception: pass

    def save_cache(self):
        try:
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, ensure_ascii=False, indent=4)
        except Exception: pass

    def set_lang(self, lang_code):
        self.lang = lang_code
        try:
            with open(LANG_FILE, "w", encoding="utf-8") as f:
                json.dump({"lang": lang_code}, f, ensure_ascii=False)
        except Exception: pass

    def __call__(self, text):
        if not text or not isinstance(text, str):
            return text

        if self.lang == "ru":
            return text

        if self.lang not in self.cache:
            self.cache[self.lang] = {}

        if text in self.cache[self.lang]:
            return self.cache[self.lang][text]

        # Автопереводчик для новых языков
        if GoogleTranslator:
            try:
                translated = GoogleTranslator(source='ru', target=self.lang).translate(text)
                self.cache[self.lang][text] = translated
                threading.Thread(target=self.save_cache, daemon=True).start()
                return translated
            except Exception:
                return text

        return text

_translator = AutoTranslator()

# Функция _() будет оборачивать все тексты в программе
def _(text):
    return _translator(text)

def set_language(lang_code):
    _translator.set_lang(lang_code)

def get_language():
    return _translator.lang
