"""Модальные диалоги: подтверждение команды и ввод пароля sudo."""
import customtkinter as ctk

import theme
from theme import C


class _BaseDialog(ctk.CTkToplevel):
    def __init__(self, parent, title, width, height, on_done):
        super().__init__(parent)
        self._on_done = on_done
        self._finished = False
        self.title(title)
        self.configure(fg_color=C["surface"])
        self.resizable(False, False)
        self.transient(parent)
        self.update_idletasks()
        x = parent.winfo_x() + max(0, (parent.winfo_width() - width) // 2)
        y = parent.winfo_y() + max(0, (parent.winfo_height() - height) // 3)
        self.geometry(f"{width}x{height}+{x}+{y}")
        self.protocol("WM_DELETE_WINDOW", lambda: self.close(self._cancel_value()))
        self.bind("<Escape>", lambda e: self.close(self._cancel_value()))
        self.after(120, self._grab)

    def _cancel_value(self):
        return False

    def _grab(self):
        try:
            self.lift()
            self.focus_force()
            self.grab_set()  # на части оконных менеджеров окно ещё не «видимо» — тогда просто без захвата
        except Exception:
            pass

    def close(self, value):
        if self._finished:
            return
        self._finished = True
        try:
            self.grab_release()
        except Exception:
            pass
        try:
            self.destroy()
        finally:
            self._on_done(value)


class ConfirmDialog(_BaseDialog):
    def __init__(self, parent, title, message, command, danger, on_done):
        super().__init__(parent, title, 620, 380, on_done)
        accent = C["red"] if danger else C["accent"]
        ctk.CTkLabel(self, text=title, font=theme.ui(16, "bold"), text_color=accent, anchor="w").pack(fill="x", padx=22, pady=(18, 2))
        ctk.CTkLabel(self, text=message, font=theme.ui(12), text_color=C["text"], anchor="w", justify="left",
                     wraplength=570).pack(fill="x", padx=22, pady=(0, 10))
        box = ctk.CTkTextbox(self, font=theme.mono(11), fg_color=C["code_bg"], text_color="#c9d1d9",
                             border_width=1, border_color=C["border"], height=170)
        box.pack(fill="both", expand=True, padx=22)
        box.insert("1.0", command)
        box.configure(state="disabled")
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=22, pady=16)
        ctk.CTkButton(row, text="Отмена", width=120, fg_color=C["surface_hi"], hover_color=C["border"],
                      command=lambda: self.close(False)).pack(side="right", padx=(8, 0))
        ctk.CTkButton(row, text="Выполнить", width=140, fg_color=C["red"] if danger else C["green"],
                      hover_color=C["red_hover"] if danger else C["green_hover"],
                      command=lambda: self.close(True)).pack(side="right")


class PasswordDialog(_BaseDialog):
    def __init__(self, parent, retry, on_done):
        super().__init__(parent, "Пароль sudo", 420, 210, on_done)
        ctk.CTkLabel(self, text="Нужен пароль sudo", font=theme.ui(16, "bold"), anchor="w").pack(fill="x", padx=22, pady=(18, 2))
        text = "Неверный пароль, попробуйте ещё раз." if retry else "Ассистенту нужны права администратора. Пароль хранится только в памяти до закрытия приложения."
        ctk.CTkLabel(self, text=text, font=theme.ui(11), text_color=C["red"] if retry else C["muted"], anchor="w",
                     justify="left", wraplength=380).pack(fill="x", padx=22, pady=(0, 10))
        self.entry = ctk.CTkEntry(self, show="•", height=34, font=theme.ui(13))
        self.entry.pack(fill="x", padx=22)
        self.entry.bind("<Return>", lambda e: self.close(self.entry.get() or None))
        self.after(200, self.entry.focus_set)
        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=22, pady=16)
        ctk.CTkButton(row, text="Отмена", width=100, fg_color=C["surface_hi"], hover_color=C["border"],
                      command=lambda: self.close(None)).pack(side="right", padx=(8, 0))
        ctk.CTkButton(row, text="OK", width=100, command=lambda: self.close(self.entry.get() or None)).pack(side="right")

    def _cancel_value(self):
        return None
