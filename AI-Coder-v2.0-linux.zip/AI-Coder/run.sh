#!/usr/bin/env bash
# Запуск AI-Coder. Сам подготавливает окружение и подсказывает, чего не хватает в системе.
cd "$(dirname "$(readlink -f "$0")")" || exit 1
PY="${PYTHON:-python3}"

if ! command -v "$PY" >/dev/null 2>&1; then
  echo "[AI-Coder] Не найден python3. Установите его пакетным менеджером вашего дистрибутива." >&2
  exit 1
fi
if ! "$PY" -c "import tkinter" >/dev/null 2>&1; then
  echo "[AI-Coder] Нет tkinter (системный пакет). Установите:" >&2
  echo "  Debian/Ubuntu/Mint: sudo apt install python3-tk" >&2
  echo "  Fedora/RHEL:        sudo dnf install python3-tkinter" >&2
  echo "  Arch/Manjaro:       sudo pacman -S tk" >&2
  echo "  openSUSE:           sudo zypper install python3-tk" >&2
  echo "  Alpine:             sudo apk add py3-tkinter" >&2
  exit 1
fi

have_deps() { "$1" -c "import customtkinter, requests, PIL" >/dev/null 2>&1; }

if have_deps "$PY"; then
  exec "$PY" main.py "$@"
fi

# Зависимостей нет — ставим в изолированное окружение (работает и с PEP 668).
# --system-site-packages нужен, чтобы видеть системный tkinter.
if [ ! -x .venv/bin/python ]; then
  echo "[AI-Coder] Создаю окружение .venv …"
  "$PY" -m venv --system-site-packages .venv 2>/dev/null || {
    echo "[AI-Coder] Не удалось создать venv (нужен пакет python3-venv). Пробую pip --user …" >&2
    "$PY" -m pip install --user -r requirements.txt 2>/dev/null || \
    "$PY" -m pip install --user --break-system-packages -r requirements.txt || exit 1
    exec "$PY" main.py "$@"
  }
fi
if ! have_deps .venv/bin/python; then
  echo "[AI-Coder] Устанавливаю зависимости (нужна сеть; при сбоях повторяю) …"
  for i in 1 2 3; do
    .venv/bin/python -m pip install -q -r requirements.txt && break
    echo "[AI-Coder] Попытка $i не удалась, жду 3 с …" >&2; sleep 3
  done
fi
have_deps .venv/bin/python || { echo "[AI-Coder] Не удалось установить зависимости. Проверьте сеть/прокси и запустите ещё раз." >&2; exit 1; }
exec .venv/bin/python main.py "$@"
