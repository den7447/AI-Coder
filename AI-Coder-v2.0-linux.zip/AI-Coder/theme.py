"""Единая тема оформления AI-Coder: палитра, шрифты Linux, стили ttk.

Шрифты подбираются из реально установленных в системе (Consolas в Linux нет —
из-за этого в оригинале везде был «некрасивый» запасной шрифт).
Эмодзи в интерфейсе не используются: цветные эмодзи на некоторых сборках Tk/X11
вызывают падения (BadLength) и «квадратики», поэтому вместо них простые символы.
"""
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

C = {
    "bg": "#0f1218",
    "panel": "#0b0e13",
    "surface": "#161b24",
    "surface_hi": "#1e2531",
    "border": "#262d3a",
    "text": "#dfe5ee",
    "muted": "#8a94a6",
    "faint": "#586174",
    "accent": "#5b9cf6",
    "accent_hover": "#4688e6",
    "accent_dim": "#223a5e",
    "green": "#3ecf8e",
    "green_hover": "#35b87e",
    "amber": "#e5b567",
    "red": "#f0615b",
    "red_hover": "#d94e48",
    "violet": "#9b7bf2",
    "teal": "#4cc2c4",
    "code_bg": "#0a0d12",
    "user_bg": "#17263d",
    "ok_bg": "#10241c",
    "err_bg": "#2a1517",
    "warn_bg": "#2a2313",
    # подсветка синтаксиса
    "syn_kw": "#c678dd", "syn_str": "#98c379", "syn_com": "#5c6370", "syn_num": "#d19a66",
    "syn_func": "#61afef", "syn_cls": "#e5c07b", "syn_deco": "#56b6c2", "syn_var": "#e06c75",
}

MODES = {
    "agent": {"label": "Агент", "color": "#4a8df0", "hover": "#3a7ae0",
              "desc": "Планирует задачу, пишет файлы проекта и запускает команды"},
    "query": {"label": "Ask", "color": "#d19a3c", "hover": "#b9852e",
              "desc": "Отвечает на вопросы. Ничего не меняет и не запускает"},
    "assistant": {"label": "Ассистент", "color": "#8b6cf0", "hover": "#775ad8",
                  "desc": "Выполняет задачи в терминале Linux и проверяет результат каждой команды"},
    "dcoder": {"label": "D-Coder", "color": "#2fa876", "hover": "#268f63",
               "desc": "Собирает проект по заданной структуре и готовому коду"},
}
MODE_ORDER = ["agent", "query", "assistant", "dcoder"]

_UI_CANDIDATES = ["Inter", "Noto Sans", "Ubuntu", "Cantarell", "Open Sans", "Roboto", "Source Sans 3",
                  "DejaVu Sans", "Liberation Sans", "FreeSans", "Helvetica", "Arial"]
_MONO_CANDIDATES = ["JetBrains Mono", "Fira Code", "Source Code Pro", "Hack", "Ubuntu Mono", "Cascadia Code",
                    "Noto Sans Mono", "DejaVu Sans Mono", "Liberation Mono", "FreeMono", "Courier 10 Pitch", "Courier"]

UI_FAMILY = "TkDefaultFont"
MONO_FAMILY = "TkFixedFont"


def init_fonts(root):
    """Выбирает лучшие из установленных шрифтов. Вызывать после создания корневого окна."""
    global UI_FAMILY, MONO_FAMILY
    try:
        have = {f.lower(): f for f in tkfont.families(root)}
    except tk.TclError:
        have = {}
    for cand in _UI_CANDIDATES:
        if cand.lower() in have:
            UI_FAMILY = have[cand.lower()]
            break
    for cand in _MONO_CANDIDATES:
        if cand.lower() in have:
            MONO_FAMILY = have[cand.lower()]
            break
    return UI_FAMILY, MONO_FAMILY


def ui(size=12, weight="normal"):
    return (UI_FAMILY, size, weight)


def mono(size=12, weight="normal"):
    return (MONO_FAMILY, size, weight)


def apply_ttk_style(root):
    """Тёмный Treeview/Scrollbar (по умолчанию ttk в Linux белый и выбивается из интерфейса)."""
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass
    style.configure("Treeview", background=C["panel"], fieldbackground=C["panel"], foreground=C["text"],
                    borderwidth=0, rowheight=25, font=ui(11), relief="flat")
    style.configure("Treeview.Heading", background=C["panel"], foreground=C["muted"], relief="flat")
    style.map("Treeview", background=[("selected", C["accent_dim"])], foreground=[("selected", "#ffffff")])
    style.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
    style.configure("Vertical.TScrollbar", background=C["surface_hi"], troughcolor=C["panel"], bordercolor=C["panel"],
                    arrowcolor=C["muted"], lightcolor=C["surface_hi"], darkcolor=C["surface_hi"], gripcount=0)
    style.map("Vertical.TScrollbar", background=[("active", C["border"])])
    style.configure("Horizontal.TScrollbar", background=C["surface_hi"], troughcolor=C["panel"], bordercolor=C["panel"],
                    arrowcolor=C["muted"], lightcolor=C["surface_hi"], darkcolor=C["surface_hi"], gripcount=0)


def shorten_path(path, limit=38):
    import os
    home = os.path.expanduser("~")
    if path.startswith(home):
        path = "~" + path[len(home):]
    if len(path) <= limit:
        return path
    return "…" + path[-(limit - 1):]
