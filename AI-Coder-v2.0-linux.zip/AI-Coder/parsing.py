"""Разбор ответов модели: файлы и shell-команды."""
import re

SHELL_LANGS = {"bash", "sh", "shell", "console", "zsh", "terminal", "shellscript", "fish"}
CODEISH = re.compile(r"^\s*(\{|\[|<|import |from \w+ import|def |class |#include|function |const |let |var |public |package |@)")


# ───────────────────────── разбор ответов модели ─────────────────────────
def parse_file_blocks(text):
    """Блоки ```file: путь ... ``` → [(путь, содержимое, закрыт_ли_блок)]."""
    blocks = []
    lines = text.split("\n")
    i = 0
    start_re = re.compile(r"^\s*```\s*(?:file|filepath|path)\s*:\s*(.+?)\s*$", re.I)
    while i < len(lines):
        m = start_re.match(lines[i])
        if not m:
            i += 1
            continue
        path = m.group(1).strip().strip("`\"'")
        i += 1
        body = []
        closed = False
        while i < len(lines):
            if lines[i].strip() == "```":
                closed = True
                i += 1
                break
            body.append(lines[i])
            i += 1
        blocks.append((path, "\n".join(body), closed))
    return blocks


def parse_shell_blocks(text, accept_untagged=True):
    """Достаёт из ответа только shell-блоки. Блоки python/json/file: никогда не исполняются."""
    blocks = []
    for m in re.finditer(r"^[ \t]*```([\w+.-]*)[^\n]*\n(.*?)^[ \t]*```[ \t]*$", text, re.M | re.S):
        lang, body = m.group(1).lower(), m.group(2)
        if lang in SHELL_LANGS:
            pass
        elif lang == "" and accept_untagged:
            first = next((l for l in body.split("\n") if l.strip()), "")
            if CODEISH.match(first):
                continue
        else:
            continue
        body = body.strip("\n")
        if body.strip():
            blocks.append(body)
    return blocks


def strip_code_blocks(text):
    return re.sub(r"```.*?```", "", text, flags=re.S).strip()
