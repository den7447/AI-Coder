#!/usr/bin/env bash
# Добавляет AI-Coder в меню приложений (~/.local/share/applications).
set -e
DIR="$(dirname "$(readlink -f "$0")")"
chmod +x "$DIR/run.sh"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/ai-coder.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=AI-Coder
Comment=Локальный ИИ-помощник для программирования и терминала (Ollama)
Exec=$DIR/run.sh
Path=$DIR
Icon=$DIR/icon.png
Terminal=false
Categories=Development;Utility;
StartupWMClass=tk
DESK
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
echo "Готово: AI-Coder добавлен в меню приложений. Если ярлыка не видно — перезайдите в сессию."
