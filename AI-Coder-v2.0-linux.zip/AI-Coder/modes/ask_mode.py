import sysinfo

SYSTEM = ("Ты ИИ-консультант по программированию и Linux. Отвечай прямо, точно и по-русски. "
          "Команды давай для Linux. Если не уверен — так и скажи, не выдумывай.\n"
          "Система пользователя: {SYS}")


def run(agent, task, chat_id):
    app = agent.app
    info = agent._info
    sys_line = (f"{info['distro']}, пакетный менеджер {info['pkg']['name'] or 'неизвестен'}" if info
                else "Linux (нестандартный дистрибутив)")
    msgs = [{"role": "system", "content": SYSTEM.replace("{SYS}", sys_line)}]
    msgs += agent.history_messages(chat_id)
    msgs.append({"role": "user", "content": task})
    agent._append_history(chat_id, "user", task)
    response = agent.chat(msgs, chat_id, stream=True)
    if not app.cancel_flag and response.strip():
        agent._append_history(chat_id, "assistant", response)
