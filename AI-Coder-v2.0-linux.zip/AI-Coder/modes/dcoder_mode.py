import os
import re


def _stop(app):
    return app.cancel_flag or app.pause_flag


def run(agent, structure, content, chat_id):
    app = agent.app
    app.say("system", "D-Coder · Этап 1: анализ архитектуры (список файлов)…", chat_id)

    struct_prompt = (
        f"Ты строгий парсер архитектуры.\n"
        f"Твоя задача — прочитать структуру проекта и выписать ВСЕ конечные файлы, которые нужно создать.\n"
        f"Игнорируй папки, выписывай только файлы!\n\n"
        f"--- СТРУКТУРА ---\n{structure}\n\n"
        f"Ответь СТРОГО списком в формате:\n"
        f"FILE: путь/к/файлу.py\n"
        f"Никакого кода файлов и никаких других слов!"
    )

    struct_resp = agent.ask_ollama(struct_prompt)
    if _stop(app):
        return
    app.say("plan", "Распознанные файлы:\n" + struct_resp, chat_id)

    files = re.findall(r"FILE:\s*([^\n]+)", struct_resp, re.IGNORECASE)
    clean_files = []
    for f in files:
        full, rel = agent._safe_path(f.strip().strip("`"))
        if not full or rel.endswith("/"):
            continue
        clean_files.append(rel)

    if not clean_files:
        app.say("err", "Не удалось распознать файлы. Убедитесь, что передана правильная структура проекта.", chat_id)
        return

    for rel in clean_files:
        full, _ = agent._safe_path(rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        if not os.path.exists(full):
            with open(full, "w", encoding="utf-8") as fh:
                fh.write("")

    app.say("ok", f"Этап 1 завершён: создано файлов и папок — {len(clean_files)}.", chat_id)
    app.refresh_file_tree_async()

    app.say("system", "D-Coder · Этап 2: точечное встраивание кода в файлы…", chat_id)
    for i, filepath in enumerate(clean_files, 1):
        if _stop(app):
            break
        app.say("step", f"Поиск и запись {i}/{len(clean_files)} · {filepath}", chat_id)

        code_prompt = (
            f"Ты строгий парсер кода.\n"
            f"Найди в исходных кодах фрагмент, который относится к файлу '{filepath}'.\n"
            f"--- ИСХОДНЫЕ КОДЫ ---\n{content}\n\n"
            f"ВНИМАНИЕ! ТЫ ОБЯЗАН ВЫВЕСТИ КОД ПОЛНОСТЬЮ! Строго запрещено использовать заглушки, обрезать код или писать комментарии в стиле '// остальной код'.\n"
            f"Выведи ТОЛЬКО код для этого файла, обернутый в блок:\n"
            f"```file: {filepath}\nВЕСЬ КОД\n```\n"
            f"Если кода для этого файла в исходниках нет, просто выведи пустой блок. Не пиши пояснений и извинений!"
        )

        code_resp = agent.ask_ollama(code_prompt)
        if _stop(app):
            break
        agent.apply_file_blocks(code_resp, chat_id)

    if not _stop(app):
        agent._append_history(chat_id, "user", "[D-CODER: Процесс сборки запрошен]")
        agent._append_history(chat_id, "assistant", "Все файлы успешно распакованы и собраны.")
        app.say("ok", "D-Coder: проект собран по заданной структуре.", chat_id)
