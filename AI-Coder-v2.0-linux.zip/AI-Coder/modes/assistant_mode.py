"""Режим «Ассистент»: ИИ выполняет задачу в терминале Linux пошагово.

Цикл:  модель предлагает ОДИН bash-блок → приложение выполняет его (с проверками,
таймаутом, повторами при сетевых сбоях) → модель получает код выхода, вывод и
подсказки → исправляет ошибки и идёт дальше, пока не напишет «ГОТОВО:».
Так ИИ видит реальный результат каждой команды, а не гадает вслепую.
"""
import sysinfo
from parsing import parse_shell_blocks

MAX_STEPS = 14
MAX_BLOCKS_PER_STEP = 3

SYSTEM_PROMPT = """Ты — Linux-ассистент в приложении AI-Coder. Ты выполняешь задачи пользователя в его терминале ПОШАГОВО и сам проверяешь результат каждого шага.

ОТЧЁТ О СИСТЕМЕ ПОЛЬЗОВАТЕЛЯ (собран программой на самой машине — ему можно верить, а своим догадкам о системе — нельзя):
{SYSINFO}

ПРАВИЛА РАБОТЫ
1. Каждый шаг: 1–2 предложения о том, что делаешь, и РОВНО ОДИН блок ```bash ... ``` (до ~6 команд). Блок будет выполнен сразу, поэтому в ```bash пиши только то, что нужно выполнить. Примеры и пояснения — обычным текстом.
2. После блока ОСТАНОВИСЬ. Приложение выполнит его и пришлёт код выхода и вывод. Никогда не придумывай вывод сам.
3. Блок запускается в новом bash с `set -e`: на первой ошибке выполнение останавливается. Сохраняется только текущая папка (`cd` работает). Переменные и `source .venv/bin/activate` между блоками НЕ сохраняются — соединяй через `&&` или вызывай `.venv/bin/python`.
4. Клавиатуры нет, ввод закрыт. Всегда используй флаги без вопросов: -y, --yes, --noconfirm, --non-interactive. Никаких nano/vim/less/top/htop/man. Файлы создавай через `cat > файл <<'EOF' ... EOF`.
5. Долгие и бесконечные процессы (сервер, `ollama serve`, `npm start`, `python app.py` с циклом) запускай в фоне: `nohup команда > run.log 2>&1 &`, затем `sleep 2; tail -n 20 run.log`.
6. Система нестандартная — ничего не считай установленным и рабочим. Перед использованием программы проверь `command -v имя`. Если команда упала — прочитай ошибку и подсказки системы, найди причину и смени подход. Не повторяй ту же команду без изменений.
7. Репозитории: `git clone --depth 1 URL`. Приложение само повторяет git при сетевых сбоях и пробует скачать архив. После клонирования проверь `ls` и наличие нужных файлов. Читай README клонированного проекта, прежде чем его запускать.
8. Python-пакеты ставь только в venv: `python3 -m venv .venv && .venv/bin/pip install ...`. Системные пакеты — только командой менеджера пакетов из отчёта выше (с sudo, если не root).
9. Удаляй только то, что создал сам. Запрещено: `rm -rf /`, `rm -rf ~`, форматирование дисков, `chmod -R 777`, `curl ... | sh`.
10. Код выхода 0 не гарантирует успех. После важного действия проверь результат (`ls`, `--version`, `curl -sI`, `cat`).
11. Когда задача решена и проверена — ответь БЕЗ блока bash, начав с «ГОТОВО:», и в 2–4 предложениях скажи, что сделано и как этим пользоваться. Если выполнить нельзя — начни с «НЕВОЗМОЖНО:» и объясни причину и что может сделать пользователь.
12. Отвечай по-русски. Если вопрос не требует команд — просто ответь текстом.

Рабочая папка: {WORKSPACE}"""


def build_system(agent, info):
    text = SYSTEM_PROMPT.replace("{SYSINFO}", sysinfo.format_for_prompt(info))
    return text.replace("{WORKSPACE}", agent.app.workspace_dir)


def _total(messages):
    return sum(len(m["content"]) for m in messages)


def _squeeze(text, limit):
    if len(text) <= limit:
        return text
    h = limit // 2
    return text[:h] + f"\n… [сокращено {len(text) - limit} символов] …\n" + text[-h:]


def fit_messages(messages, ctx_tokens, pinned):
    """Не даёт переписке выйти за контекст: Ollama молча отрезает НАЧАЛО (то есть правила!)."""
    budget = int(int(ctx_tokens) * 2.1)
    if _total(messages) <= budget:
        return messages
    msgs = [dict(m) for m in messages]
    # 1) сжимаем старые результаты команд
    for i in range(1, len(msgs) - 2):
        if i not in pinned:
            msgs[i]["content"] = _squeeze(msgs[i]["content"], 700)
    # 2) выбрасываем самые старые непривязанные сообщения
    i = 1
    while _total(msgs) > budget and i < len(msgs) - 2:
        if i in pinned:
            i += 1
            continue
        del msgs[i]
        pinned = {p - 1 if p > i else p for p in pinned}
    # 3) в крайнем случае сжимаем и последний результат
    if _total(msgs) > budget:
        msgs[-1]["content"] = _squeeze(msgs[-1]["content"], max(800, budget // 4))
    return msgs


def run(agent, task, chat_id):
    app = agent.app
    app.set_status("Диагностика системы…")
    info = agent.get_system_info()
    app.set_status("")

    chat = app.chats.get(chat_id, {})
    if not chat.get("sys_shown"):
        app.say("info", "Система: " + agent.info_summary(info), chat_id)
        chat["sys_shown"] = True

    system = build_system(agent, info)
    messages = [{"role": "system", "content": system}] + agent.history_messages(chat_id)
    messages.append({"role": "user", "content": task})
    task_index = len(messages) - 1
    agent._append_history(chat_id, "user", task)

    transcript = []          # что реально было сделано — сохраняем в историю для «продолжай»
    fail_count = {}          # сколько раз падал один и тот же блок
    consecutive_fail = 0
    final_text = ""
    stopped_reason = ""

    for step in range(1, MAX_STEPS + 1):
        if app.cancel_flag:
            stopped_reason = "отменено"
            break
        if app.pause_flag:
            app.say("warn", f"Пауза перед шагом {step}. Напишите «продолжай», чтобы продолжить.", chat_id)
            stopped_reason = "пауза"
            break

        app.set_status(f"Ассистент думает… (шаг {step}/{MAX_STEPS})")
        pinned = {0, task_index}
        reply = agent.chat(fit_messages(messages, app.ctx_var.get(), pinned), chat_id, stream=True)
        app.set_status("")
        if app.cancel_flag:
            stopped_reason = "отменено"
            break
        if not reply.strip():
            app.say("warn", "Модель вернула пустой ответ. Попробуйте другую модель или переформулируйте задачу.", chat_id)
            stopped_reason = "пустой ответ"
            break

        messages.append({"role": "assistant", "content": reply})
        blocks = parse_shell_blocks(reply)
        if not blocks:
            final_text = reply.strip()
            break

        feedback, results = [], []
        for bi, block in enumerate(blocks[:MAX_BLOCKS_PER_STEP]):
            res = agent.execute_block(block, chat_id)
            results.append(res)
            sig = " ".join(block.split())
            first_line = block.strip().split("\n")[0][:80]
            transcript.append(f"- `{first_line}`{' …' if block.count(chr(10)) else ''} → "
                              + ("OK" if res.ok else f"ошибка (код {res.rc})" if not res.blocked else f"не выполнено ({res.blocked})"))
            feedback.append(res.for_model())
            if res.blocked or res.cancelled or not res.ok:
                if not res.ok and not res.blocked and not res.cancelled:
                    fail_count[sig] = fail_count.get(sig, 0) + 1
                break
        if len(blocks) > len(results):
            feedback.append(f"(Выполнено блоков: {len(results)} из {len(blocks)} — остальные пропущены. "
                            f"Присылай по одному блоку за шаг.)")

        last = results[-1]
        if last.cancelled or app.cancel_flag:
            stopped_reason = "отменено"
            break
        if last.blocked and "отключено" in last.blocked:
            final_text = reply.strip()
            stopped_reason = "команды отключены"
            break

        if last.ok:
            consecutive_fail = 0
        else:
            consecutive_fail += 1

        note = ""
        if last.blocked:
            note = "Пользователь ОТКЛОНИЛ выполнение этого блока. Предложи безопасную альтернативу или объясни, что делать."
        elif not last.ok:
            sig = " ".join(blocks[len(results) - 1].split())
            n = fail_count.get(sig, 0)
            if n >= 4:
                app.say("warn", "Ассистент застрял: одна и та же команда падает снова и снова. Остановлено — "
                                "уточните задачу или посмотрите ошибку выше.", chat_id)
                stopped_reason = "зациклился"
                break
            if n >= 2:
                note = "ВНИМАНИЕ: этот блок уже падал несколько раз. Смени подход, не повторяй его."
            if consecutive_fail >= 5:
                app.say("warn", "Слишком много ошибок подряд — остановлено.", chat_id)
                stopped_reason = "много ошибок"
                break
        else:
            note = "Проверь, что результат действительно достигнут. Если да — ответь «ГОТОВО: ...» без блока bash, иначе дай следующий шаг."

        messages.append({"role": "user", "content": f"РЕЗУЛЬТАТ ВЫПОЛНЕНИЯ (шаг {step}):\n" + "\n\n".join(feedback) + "\n\n" + note})
    else:
        app.say("warn", f"Достигнут лимит шагов ({MAX_STEPS}). Напишите «продолжай» — ассистент продолжит с этого места.", chat_id)
        stopped_reason = "лимит шагов"

    summary = ""
    if transcript:
        summary += "Выполненные команды:\n" + "\n".join(transcript[-12:]) + "\n"
    if final_text:
        summary += "Итог: " + final_text[:1500]
    elif stopped_reason:
        summary += f"(Работа остановлена: {stopped_reason})"
    if summary:
        agent._append_history(chat_id, "assistant", summary)
