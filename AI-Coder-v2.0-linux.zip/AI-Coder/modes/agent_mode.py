import re

SYSTEM = ("Ты автономный программист в среде Linux (нестандартный дистрибутив: не полагайся на то, что "
          "утилиты установлены и работают, проверяй результат). Пиши рабочий, законченный код. "
          "Отвечай по-русски. Файлы отдавай блоками ```file: путь, команды терминала — блоками ```bash.")


def run(agent, task, chat_id):
    app = agent.app
    saved_state = app.chats.get(chat_id, {}).get("state", {})

    if saved_state and "steps" in saved_state:
        app.say("system", "Продолжаю прерванную задачу…", chat_id)
        steps = saved_state["steps"]
        start_index = saved_state["current_index"]
        plan = saved_state["plan"]
        task = saved_state.get("task", task) or task
    else:
        app.say("system", "Агент: составляю план…", chat_id)
        agent._append_history(chat_id, "user", task)

        plan_prompt = (
            f"{agent._get_history_context(chat_id)}"
            f"Задача: {task}\n"
            f"Создай ОЧЕНЬ подробный пошаговый план выполнения этой задачи (строго от 20 до 250 шагов) в виде нумерованного списка."
        )
        plan = agent.ask_ollama(plan_prompt, system=SYSTEM, chat_id=chat_id, stream=True, kind="plan")
        if app.cancel_flag:
            return
        steps = [line.strip() for line in plan.split("\n") if re.match(r"^\d+[.)]", line.strip())]
        if not steps:
            steps = ["1. Реализовать задачу."]
        start_index = 0

    context = f"Задача: {task}\nОбщий план:\n{plan}\n"
    last_report = ""

    for i in range(start_index, len(steps)):
        step = steps[i]

        if app.cancel_flag:
            app.say("warn", "Задача отменена.", chat_id)
            app.chats[chat_id]["state"] = {}
            app.save_chats()
            return
        if app.pause_flag:
            app.say("warn", f"Пауза перед шагом {i + 1}. Нажмите «Отправить», чтобы продолжить.", chat_id)
            app.chats[chat_id]["state"] = {"steps": steps, "current_index": i, "plan": plan, "task": task}
            app.save_chats()
            return

        app.say("step", f"Шаг {i + 1}/{len(steps)} · {step}", chat_id)

        step_prompt = (
            f"{context}\nТекущие файлы:\n{agent.get_workspace_context()}\n\n"
            + (f"Результат предыдущей команды терминала:\n{last_report}\n\n" if last_report else "")
            + f"Выполни шаг {i + 1}: {step}\n"
            f"КРИТИЧЕСКИ ВАЖНО: Если ты создаешь или меняешь код, ты ОБЯЗАН обернуть весь исходный код в такой блок:\n"
            f"```file: путь/к/файлу.py\n<здесь весь код от начала до конца>\n```\n"
            f"Иначе программа не сохранится! Команды терминала (если нужны) — в блоке ```bash."
        )

        step_response = agent.ask_ollama(step_prompt, system=SYSTEM, chat_id=chat_id, stream=True)
        if app.cancel_flag:
            continue  # на следующей итерации задача будет отменена

        # Ответ уже получен целиком — применяем его, даже если нажата пауза (иначе шаг потеряется)
        results = agent.extract_and_run_commands(step_response, chat_id, allow_file_creation=True)
        last_report = results[-1].for_model(1500) if results else ""

    if not app.cancel_flag and not app.pause_flag:
        final_response = agent.ask_ollama("Дай краткое резюме проделанной работы.", system=SYSTEM,
                                          chat_id=chat_id, stream=True)
        agent._append_history(chat_id, "assistant", f"Выполнен план:\n{plan}\nИтог:\n{final_response}")
        app.chats[chat_id]["state"] = {}
        app.save_chats()
