"""Ядро ИИ-агента: общение с Ollama, работа с файлами проекта и выполнение команд.

Модули в modes/ используют только публичные методы этого класса, а интерфейс
(вывод в чат, диалоги подтверждения) получают через объект `app`.
"""
import os
import re
import threading

import executor
import sysinfo
from llm import LLMError, OllamaClient
from parsing import parse_file_blocks, parse_shell_blocks, strip_code_blocks  # noqa: F401
from modes import agent_mode, assistant_mode, ask_mode, dcoder_mode

SKIP_DIRS = {"__pycache__", "node_modules", "venv", ".venv", "env", "dist", "build", "target", ".git", ".idea",
             ".vscode", ".mypy_cache", ".pytest_cache", ".ai_backup", ".cache", "site-packages"}
TEXT_EXT = {".py", ".txt", ".json", ".html", ".css", ".js", ".ts", ".tsx", ".jsx", ".vue", ".sh", ".md", ".toml",
            ".yml", ".yaml", ".cfg", ".ini", ".c", ".h", ".cpp", ".hpp", ".rs", ".go", ".java", ".sql", ".xml",
            ".env", ".conf", ".service", ".desktop", ".rb", ".php", ".lua", ".kt", ".swift", ".cs"}
MAX_FILE_BYTES = 40_000

class AIAgent:
    def __init__(self, app):
        self.app = app
        self.llm = OllamaClient()
        self._info = None
        self._info_lock = threading.Lock()
        self._runners = {}

    # ───── система ─────
    def get_system_info(self, force=False):
        with self._info_lock:
            if self._info is None or force:
                self._info = sysinfo.probe(self.app.workspace_dir)
            return self._info

    def info_summary(self, info):
        net = info["network"]
        bad = [n for n, v in info["tools"].items() if v["present"] and v["status"] != "ok"]
        missing = [n for n in ("git", "curl", "python3", "pip3") if not info["tools"][n]["present"]]
        parts = [info["distro"], f"пакеты: {info['pkg']['name'] or 'не найден'}", f"sudo: {info['sudo']}"]
        if net.get("dns") is not None:
            parts.append("сеть: " + ("ок" if net["https"] else "НЕТ"))
        text = " · ".join(parts)
        if bad:
            text += f"\nСломаны: {', '.join(bad)}"
        if missing:
            text += f"\nНе установлены: {', '.join(missing)}"
        if info["pkg"].get("note"):
            text += "\n" + info["pkg"]["note"]
        return text

    def get_runner(self, chat_id):
        r = self._runners.get(chat_id)
        if r is None or r.workdir != self.app.workspace_dir:
            r = executor.CommandRunner(
                self.app.workspace_dir, info=self._info,
                on_output=self.app.term_write, on_status=self.app.set_status,
                is_cancelled=lambda: self.app.cancel_flag,
                sudo_password=self.app.ask_sudo_password,
                default_timeout=self.app.cmd_timeout())
            self._runners[chat_id] = r
        r.info = self._info
        r.default_timeout = self.app.cmd_timeout()
        return r

    # ───── история ─────
    def _get_history_context(self, chat_id):
        history = self.app.chats.get(chat_id, {}).get("history", [])
        if not history:
            return ""
        ctx = "--- НАЧАЛО ИСТОРИИ ПРОШЛЫХ ЗАПРОСОВ И ОТВЕТОВ ---\n"
        for msg in history[-6:]:
            role = "Пользователь" if msg["role"] == "user" else "ИИ (Ты)"
            ctx += f"{role}: {msg['content'][:3000]}\n\n"
        ctx += "--- КОНЕЦ ИСТОРИИ ---\n\n"
        return ctx

    def history_messages(self, chat_id, limit=6):
        out = []
        for msg in self.app.chats.get(chat_id, {}).get("history", [])[-limit:]:
            out.append({"role": "user" if msg["role"] == "user" else "assistant", "content": msg["content"][:2500]})
        return out

    def _append_history(self, chat_id, role, content):
        chat = self.app.chats.get(chat_id)
        if chat is None:
            return
        chat.setdefault("history", []).append({"role": role, "content": content})
        chat["history"] = chat["history"][-60:]
        self.app.save_chats()
        log_dir = os.path.join(self.app.workspace_dir, self.app.BACKUP_DIR, "chat_logs")
        try:
            os.makedirs(log_dir, exist_ok=True)
            with open(os.path.join(log_dir, f"{chat_id}.log"), "a", encoding="utf-8") as f:
                f.write(f"[{role.upper()}]\n{content}\n{'-' * 40}\n")
        except OSError:
            pass

    # ───── файлы проекта ─────
    def _iter_workspace(self):
        ws = self.app.workspace_dir
        for root, dirs, files in os.walk(ws):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
            for f in sorted(files):
                yield root, f

    def get_workspace_tree(self):
        ws = self.app.workspace_dir
        tree = []
        for root, dirs, files in os.walk(ws):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not d.startswith("."))
            level = os.path.relpath(root, ws).count(os.sep) if root != ws else 0
            tree.append(f"{'    ' * level}{os.path.basename(root)}/")
            for f in sorted(files):
                if not f.startswith("."):
                    tree.append(f"{'    ' * (level + 1)}{f}")
        return "\n".join(tree[:150])

    def get_workspace_context(self):
        """Структура проекта + содержимое файлов в пределах бюджета контекста."""
        ws = self.app.workspace_dir
        try:
            budget = int(self.app.ctx_var.get()) * 2
        except (ValueError, TypeError):
            budget = 8000
        cands = []
        for root, f in self._iter_workspace():
            if os.path.splitext(f)[1].lower() in TEXT_EXT or f in ("Makefile", "Dockerfile"):
                p = os.path.join(root, f)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                if st.st_size <= MAX_FILE_BYTES:
                    cands.append((st.st_mtime, p))
        cands.sort(reverse=True)  # свежие файлы важнее
        parts, used, skipped = [], 0, 0
        for _, p in cands:
            try:
                with open(p, "r", encoding="utf-8") as fh:
                    body = fh.read()
            except (OSError, UnicodeDecodeError):
                continue
            chunk = f"--- ФАЙЛ: {os.path.relpath(p, ws)} ---\n{body}\n--- КОНЕЦ ФАЙЛА ---\n"
            if used + len(chunk) > budget:
                skipped += 1
                continue
            parts.append(chunk)
            used += len(chunk)
        data = "\n".join(parts) if parts else "(Файлов пока нет)"
        if skipped:
            data += f"\n(ещё {skipped} файл(ов) не поместились в контекст — смотри структуру проекта)"
        return f"СТРУКТУРА ПРОЕКТА:\n{self.get_workspace_tree()}\n\nАКТУАЛЬНОЕ СОДЕРЖИМОЕ ФАЙЛОВ:\n{data}"

    def _safe_path(self, rel):
        ws = os.path.realpath(self.app.workspace_dir)
        rel = rel.strip().strip("`\"'").replace("\\", "/").lstrip("/")
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        root_name = os.path.basename(ws)
        if len(parts) > 1 and parts[0] == root_name:
            parts = parts[1:]
        if not parts or ".." in parts:
            return None, None
        full = os.path.realpath(os.path.join(ws, *parts))
        if not full.startswith(ws + os.sep):
            return None, None
        return full, "/".join(parts)

    def apply_file_blocks(self, response, chat_id):
        """Сохраняет ```file: ...``` блоки. Возвращает список записанных относительных путей."""
        blocks = parse_file_blocks(response)
        if not blocks:
            return []
        written = []
        backed_up = False
        for path, content, closed in blocks:
            full, rel = self._safe_path(path)
            if not full:
                self.app.say("warn", f"Пропущен небезопасный путь «{path}» (за пределами рабочей папки).", chat_id)
                continue
            if not closed:
                self.app.say("warn", f"Файл {rel} не сохранён: ответ модели оборвался (нет закрывающих ```). "
                                     f"Увеличьте контекст в настройках или упростите задачу.", chat_id)
                continue
            new = content.strip("\n") + "\n"
            old = None
            if os.path.isfile(full):
                try:
                    with open(full, "r", encoding="utf-8") as f:
                        old = f.read()
                except (OSError, UnicodeDecodeError):
                    old = None
                if old is not None and old.strip() == new.strip():
                    self.app.say("info", f"Без изменений: {rel}", chat_id)
                    continue
            if not backed_up:
                ok, msg = self.app.backup_manager.create_backup()
                self.app.say("info" if ok else "warn", "Создан бекап перед изменением файлов." if ok else msg, chat_id)
                backed_up = True
            try:
                os.makedirs(os.path.dirname(full), exist_ok=True)
                tmp = full + ".aic_tmp"
                with open(tmp, "w", encoding="utf-8", newline="\n") as f:
                    f.write(new)
                os.replace(tmp, full)
            except OSError as e:
                self.app.say("err", f"Не удалось записать {rel}: {e}", chat_id)
                continue
            self.app.say("file", ("Обновлён файл: " if old is not None else "Создан файл: ") + rel, chat_id)
            written.append(rel)
        if written:
            self.app.refresh_file_tree_async()
        return written

    # ───── LLM ─────
    def chat(self, messages, chat_id=None, stream=True, kind="ai"):
        """Один запрос к модели. stream=True — токены сразу появляются в чате."""
        app = self.app
        if stream and chat_id:
            app.stream_begin(chat_id, kind)
        try:
            text = self.llm.chat(
                messages, app.model_var.get(), app.temp_var.get(), app.ctx_var.get(),
                on_token=(lambda t: app.stream_token(chat_id, t)) if stream and chat_id else None,
                is_cancelled=lambda: app.cancel_flag)
        finally:
            if stream and chat_id:
                app.stream_end(chat_id)
        return text

    def ask_ollama(self, prompt, system=None, chat_id=None, stream=False, kind="ai"):
        """Совместимый с прежним API запрос «одной строкой». Ошибки — LLMError."""
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})
        return self.chat(msgs, chat_id=chat_id, stream=stream, kind=kind)

    # ───── команды ─────
    def execute_block(self, block, chat_id):
        """Выполняет один bash-блок с подтверждением и отчётом в чат.
        Возвращает CommandResult (для заблокированных/отклонённых — с полем blocked)."""
        app = self.app
        runner = self.get_runner(chat_id)
        res = executor.CommandResult(block)
        res.cwd = runner.cwd

        if not app.allow_cmd_var.get():
            res.blocked = "выполнение команд отключено в настройках"
            app.say("warn", "Выполнение команд отключено в настройках — блок не запущен.", chat_id)
            return res

        danger = executor.is_dangerous(block, runner.cwd)
        mode = app.confirm_mode()
        if danger or mode == "all":
            title = "⚠ Опасная команда" if danger else "Подтверждение команды"
            msg = (f"Причина: {danger}.\n" if danger else "") + "Выполнить этот блок?"
            if not app.ask_confirm(title, msg, block, danger=bool(danger)):
                res.blocked = "пользователь отклонил выполнение"
                app.say("warn", "Выполнение отклонено пользователем.", chat_id)
                return res

        n_lines = len([l for l in block.split("\n") if l.strip() and not l.strip().startswith("#")])
        app.say("cmd", f"Выполняю {n_lines} {'команду' if n_lines == 1 else 'команд(ы)'} · {runner.cwd}", chat_id)
        app.term_clear(header=f"$ {runner.cwd}")
        app.set_status("Выполняю команды…")
        res = runner.run(block)
        app.set_status("")
        self.report_result(res, chat_id)
        app.refresh_file_tree_async()
        return res

    def report_result(self, res, chat_id):
        app = self.app
        for n in res.notes:
            app.say("info", n, chat_id)
        out_lines = res.output.strip().split("\n") if res.output.strip() else []
        shown = out_lines[-18:] if res.ok else out_lines[-30:]
        body = ("… (начало вывода скрыто, полный вывод — в панели терминала)\n" if len(out_lines) > len(shown) else "") + "\n".join(shown)
        if res.cancelled:
            app.say("warn", "Выполнение прервано пользователем.", chat_id)
        elif res.timed_out:
            app.say("err", f"Таймаут: команда остановлена после {res.duration:.0f} с.\n{body}", chat_id)
        elif res.ok:
            app.say("ok", f"Готово · код 0 · {res.duration:.1f} с" + (f"\n{body}" if body else ""), chat_id)
        else:
            app.say("err", f"Ошибка · код {res.rc} · {res.duration:.1f} с" + (f"\n{body}" if body else ""), chat_id)
        for h in res.hints:
            app.say("hint", h, chat_id)

    def extract_and_run_commands(self, response, chat_id, allow_file_creation=True, allow_cmd_execution=True):
        """Режим «агент»: сохраняет файлы и выполняет ТОЛЬКО shell-блоки. Возвращает список результатов."""
        if self.app.cancel_flag:
            return []
        if allow_file_creation:
            self.apply_file_blocks(response, chat_id)
        results = []
        if allow_cmd_execution:
            for block in parse_shell_blocks(response, accept_untagged=False):
                if self.app.cancel_flag:
                    break
                res = self.execute_block(block, chat_id)
                results.append(res)
                if not res.ok:
                    break
        return results

    def rollback_changes(self):
        return self.app.backup_manager.restore_latest_backup()

    # ───── маршрутизаторы режимов ─────
    def run_query_mode(self, task, chat_id): ask_mode.run(self, task, chat_id)
    def run_assistant_mode(self, task, chat_id): assistant_mode.run(self, task, chat_id)
    def run_multi_step_pipeline(self, task, chat_id): agent_mode.run(self, task, chat_id)
    def run_dcoder_mode(self, structure, content, chat_id): dcoder_mode.run(self, structure, content, chat_id)
