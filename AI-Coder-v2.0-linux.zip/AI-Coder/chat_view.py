"""Отрисовка чата: сообщения разных типов, мини-markdown, блоки кода с кнопкой «копировать», стриминг."""
import re
import tkinter as tk
import tkinter.font as tkfont

import customtkinter as ctk

import theme
from theme import C

FENCE_RE = re.compile(r"^```([^\n`]*)\n(.*?)(?:^```[ \t]*$|\Z)", re.M | re.S)
INLINE_RE = re.compile(r"(\*\*[^*\n]+\*\*|`[^`\n]+`)")


class ChatView(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color=C["bg"], corner_radius=0)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.t = tk.Text(self, bg=C["bg"], fg=C["text"], insertbackground=C["text"], selectbackground=C["accent_dim"],
                         selectforeground="#ffffff", relief="flat", bd=0, highlightthickness=0, wrap="word",
                         padx=22, pady=10, font=theme.ui(12), spacing2=3, state="disabled", cursor="arrow",
                         inactiveselectbackground=C["accent_dim"])
        self.sb = ctk.CTkScrollbar(self, command=self.t.yview, fg_color=C["bg"], button_color=C["surface_hi"],
                                   button_hover_color=C["border"])
        self.t.configure(yscrollcommand=self.sb.set)
        self.t.grid(row=0, column=0, sticky="nsew")
        self.sb.grid(row=0, column=1, sticky="ns")

        self._fonts = {}
        self._streaming = False
        self._welcome = False
        self._ai_header = "AI-Coder"
        self._mode_color = C["accent"]
        self._setup_tags()

    # ───────────── оформление ─────────────
    def _font(self, key, size, weight="normal", mono=False, slant="roman"):
        fam = theme.MONO_FAMILY if mono else theme.UI_FAMILY
        f = tkfont.Font(family=fam, size=size, weight=weight, slant=slant)
        self._fonts[key] = f  # держим ссылку, иначе шрифт уничтожается сборщиком мусора
        return f

    def _band(self, name, bg, **kw):
        opts = dict(background=bg, lmargin1=16, lmargin2=16, rmargin=16)
        opts.update(kw)
        try:
            self.t.tag_configure(name, lmargincolor=bg, rmargincolor=bg, **opts)  # Tk >= 8.6
        except tk.TclError:
            self.t.tag_configure(name, **opts)

    def _setup_tags(self):
        t = self.t
        body = self._font("body", 12)
        bold = self._font("bold", 12, "bold")
        small = self._font("small", 10)
        small_b = self._font("small_b", 10, "bold")
        mono_f = self._font("mono", 11, mono=True)
        mono_s = self._font("mono_s", 10, mono=True)
        mono_b = self._font("mono_b", 11, "bold", mono=True)
        italic = self._font("italic", 11, slant="italic")
        t.tag_configure("body", font=body, foreground=C["text"])
        t.tag_configure("b", font=bold)
        t.tag_configure("h1", font=self._font("h1", 16, "bold"), foreground="#ffffff", spacing1=10, spacing3=4)
        t.tag_configure("h2", font=self._font("h2", 14, "bold"), foreground="#ffffff", spacing1=8, spacing3=3)
        t.tag_configure("h3", font=self._font("h3", 12, "bold"), foreground=C["accent"], spacing1=6, spacing3=2)
        t.tag_configure("li", lmargin1=12, lmargin2=30)
        t.tag_configure("icode", font=mono_f, background=C["surface_hi"], foreground="#f3c98b")
        t.tag_configure("gap", font=self._font("gap", 5))
        t.tag_configure("gap_s", font=self._font("gap_s", 3))
        t.tag_configure("hdr_user", font=small_b, foreground=C["muted"], spacing1=2)
        t.tag_configure("hdr_ai", font=small_b, foreground=self._mode_color, spacing1=2)
        t.tag_configure("hdr_plan", font=small_b, foreground=C["amber"], spacing1=2)
        self._band("user", C["user_bg"], font=body)
        self._band("code", C["code_bg"], font=mono_f, foreground="#c9d1d9")
        self._band("code_hdr", C["code_bg"], font=small, foreground=C["muted"])
        self._band("card_ok", C["ok_bg"], font=self._font("card_b", 11, "bold"), foreground=C["green"])
        self._band("card_err", C["err_bg"], font=self._font("card_b2", 11, "bold"), foreground=C["red"])
        self._band("card_warn", C["warn_bg"], font=self._font("card_b3", 11, "bold"), foreground=C["amber"])
        self._band("out_ok", C["code_bg"], font=mono_s, foreground=C["muted"])
        self._band("out_err", C["code_bg"], font=mono_s, foreground="#d9a3a0")
        t.tag_configure("system", font=italic, foreground=C["muted"], lmargin1=4, lmargin2=18)
        t.tag_configure("info", font=small, foreground=C["muted"], lmargin1=4, lmargin2=18)
        t.tag_configure("step", font=bold, foreground=C["accent"], spacing1=4)
        t.tag_configure("cmd", font=small_b, foreground=C["violet"], lmargin1=4)
        t.tag_configure("hint", font=italic, foreground=C["teal"], lmargin1=4, lmargin2=18)
        t.tag_configure("filetag", font=small_b, foreground=C["green"], lmargin1=4)
        t.tag_configure("w_title", font=self._font("w_title", 30, "bold", mono=True), foreground=C["accent"], justify="center")
        t.tag_configure("w_sub", font=self._font("w_sub", 12), foreground=C["muted"], justify="center")
        t.tag_configure("w_item", font=self._font("w_item", 11), foreground=C["muted"], justify="center")
        t.tag_raise("icode")
        t.tag_raise("b")
        t.tag_raise("sel")

    def set_mode_color(self, color):
        self._mode_color = color
        self.t.tag_configure("hdr_ai", foreground=color)

    # ───────────── низкоуровневые вставки ─────────────
    def _ins(self, text, *tags):
        self.t.insert("end", text, tags)

    def _gap(self, small=False):
        self._ins("\n", "gap_s" if small else "gap")

    def _at_bottom(self):
        return self.t.yview()[1] >= 0.995

    def _editable(self):
        class Ctx:
            def __enter__(s):
                self.t.configure(state="normal")
            def __exit__(s, *a):
                self.t.configure(state="disabled")
        return Ctx()

    # ───────────── публичный API ─────────────
    def clear(self):
        with self._editable():
            self.t.delete("1.0", "end")
        self._streaming = False
        self._welcome = False

    def load(self, messages, welcome=None):
        self.clear()
        if not messages and welcome:
            self.show_welcome(*welcome)
        for m in messages:
            self.add(m.get("k", "system"), m.get("t", ""), scroll=False)
        self.t.see("end")

    def show_welcome(self, title, subtitle, items):
        with self._editable():
            self._ins("\n\n\n", "gap")
            self._ins("AI-CODER\n", "w_title")
            self._ins(subtitle + "\n\n", "w_sub")
            for it in items:
                self._ins(it + "\n", "w_item")
        self._welcome = True

    def _drop_welcome(self):
        if self._welcome:
            self.t.delete("1.0", "end")
            self._welcome = False

    def add(self, kind, text, scroll=True):
        text = (text or "").rstrip()
        if not text:
            return
        stick = scroll and self._at_bottom()
        with self._editable():
            self._drop_welcome()
            getattr(self, "_r_" + kind, self._r_system)(text)
        if stick:
            self.t.see("end")

    def begin_stream(self, kind="ai"):
        with self._editable():
            self._drop_welcome()
            self._gap()
            self._ins("ПЛАН\n" if kind == "plan" else self._ai_header.upper() + "\n", "hdr_plan" if kind == "plan" else "hdr_ai")
            self.t.mark_set("stream_start", "end-1c")
            self.t.mark_gravity("stream_start", "left")
        self._streaming = True
        self._stream_kind = kind

    def stream(self, text):
        if not self._streaming:
            return
        stick = self._at_bottom()
        with self._editable():
            self._ins(text, "body")
        if stick:
            self.t.see("end")

    def end_stream(self, final_text):
        if not self._streaming:
            return
        stick = self._at_bottom()
        with self._editable():
            self.t.delete("stream_start", "end-1c")
            self.t.mark_set("insert", "stream_start")
            self._markdown(final_text.strip(), at="stream_start")
        self._streaming = False
        if stick:
            self.t.see("end")

    # ───────────── рендереры типов сообщений ─────────────
    def _r_user(self, text):
        self._gap()
        self._ins("ВЫ\n", "hdr_user")
        self._ins(" \n", "user", "gap_s")
        for line in text.split("\n"):
            self._ins(line + "\n", "user")
        self._ins(" \n", "user", "gap_s")

    def _r_ai(self, text):
        self._gap()
        self._ins(self._ai_header.upper() + "\n", "hdr_ai")
        self._markdown(text)

    def _r_plan(self, text):
        self._gap()
        self._ins("ПЛАН\n", "hdr_plan")
        self._markdown(text)

    def _r_step(self, text):
        self._gap(True)
        self._ins("▸ " + text + "\n", "step")

    def _r_system(self, text):
        self._gap(True)
        self._ins(text + "\n", "system")

    def _r_info(self, text):
        for line in text.split("\n"):
            self._ins("• " + line + "\n", "info")

    def _r_cmd(self, text):
        self._gap(True)
        self._ins("▶ " + text + "\n", "cmd")

    def _r_hint(self, text):
        self._ins("→ " + text + "\n", "hint")

    def _r_file(self, text):
        self._ins("◆ " + text + "\n", "filetag")

    def _card(self, text, head_tag, out_tag, mark):
        lines = text.split("\n")
        self._ins(f" {mark} {lines[0]}\n", head_tag)
        if len(lines) > 1:
            for line in lines[1:]:
                self._ins("  " + line + "\n", out_tag)
            self._ins(" \n", out_tag, "gap_s")

    def _r_ok(self, text): self._card(text, "card_ok", "out_ok", "✓")
    def _r_err(self, text): self._card(text, "card_err", "out_err", "✗")
    def _r_warn(self, text): self._card(text, "card_warn", "out_ok", "!")

    # ───────────── мини-markdown ─────────────
    def _markdown(self, text, at=None):
        pos = 0
        for m in FENCE_RE.finditer(text):
            self._prose(text[pos:m.start()])
            self._code(m.group(1).strip(), m.group(2).rstrip("\n"))
            pos = m.end()
        self._prose(text[pos:])
        self._ins("\n", "gap")

    def _inline(self, line, *base):
        for part in INLINE_RE.split(line):
            if not part:
                continue
            if part.startswith("**") and part.endswith("**") and len(part) > 4:
                self._ins(part[2:-2], "body", "b", *base)
            elif part.startswith("`") and part.endswith("`") and len(part) > 2:
                self._ins(" " + part[1:-1] + " ", "icode", *base)
            else:
                self._ins(part, "body", *base)

    def _prose(self, text):
        for raw in text.strip("\n").split("\n") if text.strip() else []:
            line = raw.rstrip()
            if not line.strip():
                self._ins("\n", "gap_s")
                continue
            h = re.match(r"^(#{1,3})\s+(.*)", line)
            if h:
                self._ins(h.group(2) + "\n", f"h{len(h.group(1))}")
                continue
            b = re.match(r"^\s*[-*•]\s+(.*)", line)
            if b:
                self._ins("•  ", "body", "li")
                self._inline(b.group(1), "li")
                self._ins("\n", "body", "li")
                continue
            n = re.match(r"^\s*(\d+)[.)]\s+(.*)", line)
            if n:
                self._ins(f"{n.group(1)}.  ", "body", "li")
                self._inline(n.group(2), "li")
                self._ins("\n", "body", "li")
                continue
            self._inline(line)
            self._ins("\n", "body")

    def _code(self, lang, code):
        label = lang or "код"
        if lang.lower().startswith("file:"):
            label = "файл · " + lang.split(":", 1)[1].strip()
        self._ins(" \n", "code_hdr", "gap_s")
        self._ins(f" {label}   ", "code_hdr")
        btn = tk.Label(self.t, text="копировать", fg=C["muted"], bg=C["code_bg"], cursor="hand2",
                       font=self._fonts["small"])
        btn.bind("<Button-1>", lambda e, c=code, b=btn: self._copy(c, b))
        btn.bind("<Enter>", lambda e, b=btn: b.configure(fg=C["accent"]))
        btn.bind("<Leave>", lambda e, b=btn: b.configure(fg=C["muted"]))
        self.t.window_create("end", window=btn)
        self._ins("\n", "code_hdr")
        for line in (code.split("\n") if code else [""]):
            self._ins(line + "\n", "code")
        self._ins(" \n", "code", "gap_s")

    def _copy(self, code, btn):
        try:
            self.t.clipboard_clear()
            self.t.clipboard_append(code)
            btn.configure(text="скопировано", fg=C["green"])
            btn.after(1500, lambda: btn.winfo_exists() and btn.configure(text="копировать", fg=C["muted"]))
        except tk.TclError:
            pass
