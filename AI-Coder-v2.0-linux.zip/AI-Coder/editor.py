"""Редактор кода: номера строк, подсветка синтаксиса, Ctrl+S, автоотступ, мини-ИИ."""
import os
import re
import threading
import tkinter as tk
from tkinter import messagebox

import customtkinter as ctk

import executor
import theme
from i18n import _
from theme import C

PY_KW = r"\b(?:and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield|None|True|False|self)\b"
JS_KW = r"\b(?:const|let|var|function|return|if|else|for|while|do|switch|case|break|continue|new|class|extends|import|export|from|default|async|await|try|catch|finally|throw|typeof|this|null|undefined|true|false)\b"
SH_KW = r"\b(?:if|then|else|elif|fi|for|while|do|done|case|esac|function|in|return|exit|export|local|echo|cd|set|source|sudo)\b"

STR = r"""(?P<str>"""+'"'*3+r"""[\s\S]*?"""+'"'*3+r"""|'''[\s\S]*?'''|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')"""
LANGS = {
    ".py": re.compile(STR + r"|(?P<com>#[^\n]*)|(?P<deco>^[ \t]*@\w[\w.]*)|(?P<kw>" + PY_KW + r")|(?P<num>\b\d[\d_.]*\b)|(?P<func>(?<=def )\w+)|(?P<cls>(?<=class )\w+)", re.M),
    ".js": re.compile(r"(?P<com>//[^\n]*|/\*[\s\S]*?\*/)|(?P<str>\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'|`(?:\\.|[^`\\])*`)|(?P<kw>" + JS_KW + r")|(?P<num>\b\d[\d_.]*\b)"),
    ".sh": re.compile(r"(?P<com>(?<![\$\w])#[^\n]*)|(?P<str>\"(?:\\.|[^\"\\])*\"|'[^']*')|(?P<var>\$\{?\w+\}?)|(?P<kw>" + SH_KW + r")|(?P<num>\b\d+\b)"),
    ".json": re.compile(r"(?P<str>\"(?:\\.|[^\"\\\n])*\")|(?P<kw>\b(?:true|false|null)\b)|(?P<num>-?\b\d[\d.eE+-]*\b)"),
    ".html": re.compile(r"(?P<com><!--[\s\S]*?-->)|(?P<kw></?\w+)|(?P<str>\"[^\"\n]*\"|'[^'\n]*')"),
    ".css": re.compile(r"(?P<com>/\*[\s\S]*?\*/)|(?P<str>\"[^\"\n]*\"|'[^'\n]*')|(?P<cls>[.#][\w-]+)|(?P<num>\b\d[\d.]*(?:px|em|rem|%|vh|vw)?\b)"),
}
LANGS[".mjs"] = LANGS[".ts"] = LANGS[".jsx"] = LANGS[".tsx"] = LANGS[".js"]
LANGS[".bash"] = LANGS[".sh"]
LANGS[".htm"] = LANGS[".html"]
MAX_HIGHLIGHT = 250_000


class CodeEditorModule(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.pack(fill="both", expand=True)
        self._hl_job = None
        self._ext = ""

        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", pady=(0, 8))
        self.lbl_current_file = ctk.CTkLabel(top, text=_("Файл не выбран"), font=theme.ui(13, "bold"), text_color=C["muted"])
        self.lbl_current_file.pack(side="left", padx=4)
        self.lbl_dirty = ctk.CTkLabel(top, text="", font=theme.ui(12), text_color=C["amber"])
        self.lbl_dirty.pack(side="left")

        self.btn_run_project = ctk.CTkButton(top, text=_("▶ Запустить проект"), width=150, height=30, fg_color=C["green"],
                                             hover_color=C["green_hover"], command=self.run_project)
        self.btn_save_file = ctk.CTkButton(top, text=_("Сохранить  Ctrl+S"), width=140, height=30, command=self.save_file)
        self.btn_run_project.pack(side="right", padx=(6, 0))
        self.btn_save_file.pack(side="right")

        body = ctk.CTkFrame(self, fg_color=C["code_bg"], corner_radius=8, border_width=1, border_color=C["border"])
        body.pack(fill="both", expand=True)
        body.grid_rowconfigure(0, weight=1)
        body.grid_columnconfigure(1, weight=1)

        self.gutter = tk.Canvas(body, width=52, bg=C["code_bg"], highlightthickness=0, bd=0)
        self.gutter.grid(row=0, column=0, sticky="ns", padx=(4, 0), pady=6)
        self.text = tk.Text(body, bg=C["code_bg"], fg="#c9d1d9", insertbackground="#ffffff", selectbackground=C["accent_dim"],
                            relief="flat", bd=0, highlightthickness=0, wrap="none", undo=True, maxundo=200,
                            font=theme.mono(12), padx=8, pady=6, tabs=("4c",), inactiveselectbackground=C["accent_dim"])
        self.text.grid(row=0, column=1, sticky="nsew", pady=2)
        ys = ctk.CTkScrollbar(body, command=self.text.yview, fg_color=C["code_bg"], button_color=C["surface_hi"])
        xs = ctk.CTkScrollbar(body, orientation="horizontal", command=self.text.xview, fg_color=C["code_bg"], button_color=C["surface_hi"])
        ys.grid(row=0, column=2, sticky="ns")
        xs.grid(row=1, column=0, columnspan=2, sticky="ew")
        self.text.configure(yscrollcommand=lambda *a: (ys.set(*a), self._draw_gutter()),
                            xscrollcommand=xs.set)

        for tag, color in (("kw", C["syn_kw"]), ("str", C["syn_str"]), ("com", C["syn_com"]), ("num", C["syn_num"]),
                           ("func", C["syn_func"]), ("cls", C["syn_cls"]), ("deco", C["syn_deco"]), ("var", C["syn_var"])):
            self.text.tag_configure(tag, foreground=color)
        self.text.tag_configure("com", font=theme.mono(12, "normal"))

        self.text.bind("<<Modified>>", self._on_modified)
        self.text.bind("<KeyRelease>", lambda e: self._draw_gutter())
        self.text.bind("<Configure>", lambda e: self._draw_gutter())
        self.text.bind("<Return>", self._auto_indent)
        self.text.bind("<Tab>", lambda e: (self.text.insert("insert", "    "), "break")[1])
        self.text.bind("<Control-s>", lambda e: (self.save_file(), "break")[1])

        self.ai_panel = ctk.CTkFrame(self, fg_color=C["surface"], corner_radius=8)
        self.ai_panel.pack(fill="x", pady=(8, 0))
        self.ai_mode_var = ctk.StringVar(value="AGENT")
        ctk.CTkOptionMenu(self.ai_panel, values=["AGENT", "ASK"], variable=self.ai_mode_var, width=90, height=30,
                          fg_color=C["violet"], button_color=C["violet"]).pack(side="left", padx=8, pady=8)
        self.mini_prompt = ctk.CTkTextbox(self.ai_panel, height=54, font=theme.ui(12), wrap="word", fg_color=C["bg"],
                                          border_width=1, border_color=C["border"])
        self.mini_prompt.pack(side="left", fill="both", expand=True, padx=4, pady=8)
        self.btn_send_mini = ctk.CTkButton(self.ai_panel, text=_("Отправить"), width=110, height=30, command=self.run_mini_ai)
        self.btn_send_mini.pack(side="left", padx=8, pady=8)
        self.mini_prompt.bind("<Control-Return>", lambda e: (self.run_mini_ai(), "break")[1])
        self._draw_gutter()

    # ───── номера строк ─────
    def _draw_gutter(self):
        c = self.gutter
        c.delete("all")
        i = self.text.index("@0,0")
        while True:
            d = self.text.dlineinfo(i)
            if d is None:
                break
            c.create_text(44, d[1] + 2, anchor="ne", text=i.split(".")[0], fill=C["faint"], font=theme.mono(11))
            i = self.text.index(f"{i}+1line")
            if i == self.text.index("end"):
                break

    def _on_modified(self, _e=None):
        if self.text.edit_modified():
            self.lbl_dirty.configure(text="  ● не сохранено")
            self._schedule_highlight()
            self.text.edit_modified(False)
            self._draw_gutter()

    def _auto_indent(self, _e):
        line = self.text.get("insert linestart", "insert")
        indent = re.match(r"[ \t]*", line).group(0)
        if line.rstrip().endswith((":", "{", "(", "[")):
            indent += "    "
        self.text.insert("insert", "\n" + indent)
        self.text.see("insert")
        return "break"

    # ───── подсветка ─────
    def _schedule_highlight(self):
        if self._hl_job:
            self.after_cancel(self._hl_job)
        self._hl_job = self.after(220, self.highlight)

    def highlight(self):
        self._hl_job = None
        for tag in ("kw", "str", "com", "num", "func", "cls", "deco", "var"):
            self.text.tag_remove(tag, "1.0", "end")
        rx = LANGS.get(self._ext)
        data = self.text.get("1.0", "end-1c")
        if not rx or len(data) > MAX_HIGHLIGHT:
            return
        for m in rx.finditer(data):
            kind = m.lastgroup
            if kind:
                self.text.tag_add(kind, f"1.0+{m.start()}c", f"1.0+{m.end()}c")

    # ───── файлы ─────
    def load_file(self, filepath):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
        except (OSError, UnicodeDecodeError):
            messagebox.showwarning(_("Внимание"), "Бинарный или нечитаемый файл нельзя открыть в редакторе.")
            return
        self.app.current_open_file = filepath
        self._ext = os.path.splitext(filepath)[1].lower()
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)
        self.text.edit_reset()
        self.text.edit_modified(False)
        self.lbl_dirty.configure(text="")
        self.lbl_current_file.configure(text=os.path.relpath(filepath, self.app.workspace_dir), text_color=C["text"])
        self.highlight()
        self._draw_gutter()

    def save_file(self):
        if not self.app.current_open_file:
            return
        try:
            content = self.text.get("1.0", "end-1c")
            with open(self.app.current_open_file, "w", encoding="utf-8", newline="\n") as f:
                f.write(content.rstrip("\n") + "\n")
            self.lbl_dirty.configure(text="")
            self.app.set_status("Сохранено: " + os.path.basename(self.app.current_open_file), 2500)
        except OSError as e:
            messagebox.showerror(_("Ошибка"), f"Не удалось сохранить: {e}")

    def run_project(self):
        wd = self.app.workspace_dir
        target = None
        for c in ["main.py", "app.py", "index.py", "index.js", "main.js", "server.js", "run.sh", "start.sh"]:
            if os.path.exists(os.path.join(wd, c)):
                target = os.path.join(wd, c)
                break
        if not target and self.app.current_open_file:
            target = self.app.current_open_file
        if target:
            self.run_file_in_terminal(target)
        else:
            messagebox.showinfo("AI-Coder", "Не найден главный файл (main.py, app.py, index.js, run.sh…).")

    def run_file_in_terminal(self, filepath):
        ext = os.path.splitext(filepath)[1].lower()
        name = os.path.basename(filepath)
        wd = os.path.dirname(filepath)
        if ext in (".html", ".htm"):
            self.app.open_url("file://" + filepath)
            return
        cmds = {".py": f'python3 "{name}"', ".js": f'node "{name}"', ".sh": f'bash "{name}"'}
        if ext not in cmds:
            messagebox.showinfo("AI-Coder", f"Не знаю, как запускать файлы {ext or 'без расширения'}.")
            return
        ok, msg = executor.open_terminal(wd, cmds[ext])
        if not ok:
            messagebox.showerror(_("Ошибка"), msg)

    # ───── мини-ИИ ─────
    def run_mini_ai(self):
        if not self.app.current_open_file:
            messagebox.showwarning(_("Внимание"), _("Файл не выбран"))
            return
        task = self.mini_prompt.get("1.0", "end").strip()
        if not task:
            return
        mode = self.ai_mode_var.get()
        self.mini_prompt.delete("1.0", "end")
        self.btn_send_mini.configure(state="disabled", text="Думаю…")
        threading.Thread(target=self._mini_ai_thread, args=(task, mode), daemon=True).start()

    def _mini_ai_thread(self, task, mode):
        from llm import LLMError
        app = self.app
        filepath = app.current_open_file
        cid = app.current_chat_id
        rel = os.path.relpath(filepath, app.workspace_dir)
        code = self.text.get("1.0", "end-1c")
        try:
            if mode == "ASK":
                app.say("user", f"[{rel}] {task}", cid)
                prompt = f"Вопрос ТОЛЬКО по этому файлу: {rel}.\nКод:\n```\n{code}\n```\nВопрос: {task}"
                app.agent.ask_ollama(prompt, system="Ты ИИ-помощник по программированию. Отвечай по-русски.", chat_id=cid, stream=True)
            else:
                app.say("user", f"[{rel}] {task}", cid)
                with open(filepath, "w", encoding="utf-8", newline="\n") as f:
                    f.write(code)
                prompt = (f"Контекст:\n{app.agent.get_workspace_context()}\n\nИзмени СТРОГО текущий файл: {rel}\nЗАДАЧА: {task}\n\n"
                          f"ВЫВЕДИ ВЕСЬ НОВЫЙ КОД ФАЙЛА ЦЕЛИКОМ:\n```file: {rel}\n<ВЕСЬ КОД>\n```")
                resp = app.agent.ask_ollama(prompt, chat_id=cid, stream=True)
                app.agent.apply_file_blocks(resp, cid)
                app.after(150, lambda: self.load_file(filepath))
            app.after(0, lambda: app.tabview.set(app.TAB_CHAT))
        except LLMError as e:
            app.say("err", str(e), cid)
        finally:
            app.after(0, lambda: self.btn_send_mini.configure(state="normal", text=_("Отправить")))
