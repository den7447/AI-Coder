"""Надёжный исполнитель shell-команд для Linux.

Что исправлено по сравнению с «записать все команды в ai_run.sh и запустить»:

  * блок команд проверяется `bash -n` ДО запуска (нет полувыполненных скриптов);
  * скрипт идёт с `set -e`: на первой ошибке останавливаемся и сообщаем КАКАЯ команда упала;
  * stdin закрыт, пейджеры/запросы пароля/диалоги apt отключены — ничего не «зависает»;
  * жёсткий таймаут + убийство всей группы процессов (раньше процесс после 120 с просто оставался);
  * рабочая папка сохраняется между командами (`cd` работает);
  * sudo: пароль запрашивается у пользователя, а не молча проваливается;
  * git clone / pip / npm / curl: автоматические повторы при сетевых сбоях, смена протокола
    на HTTP/1.1, shallow-клон, запасной путь через архив;
  * по тексту ошибки формируются подсказки для ИИ (нет утилиты, PEP 668, lock apt и т.д.);
  * опасные команды определяются заранее — GUI просит подтверждение.
"""
import os
import re
import shlex
import shutil
import signal
import subprocess
import tempfile
import threading
import time

import sysinfo

ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07]*(?:\x07|\x1b\\)|\x1b[()][A-Za-z0-9]")
CWD_MARK = "__AIC_CWD__="

SCRIPT_HEADER = r'''set -eE
trap '__aic_rc=$?; printf "[AIC] команда завершилась с кодом %s: %s\n" "$__aic_rc" "$BASH_COMMAND" >&2' ERR
trap 'printf "\n__AIC_CWD__=%s\n" "$PWD"' EXIT
'''


def strip_ansi(text):
    return ANSI_RE.sub("", text)


# ───────────────────────── результат ─────────────────────────
class CommandResult:
    def __init__(self, command):
        self.command = command
        self.rc = None
        self.output = ""
        self.duration = 0.0
        self.timed_out = False
        self.cancelled = False
        self.cwd = ""
        self.attempts = 1
        self.notes = []   # что сделал сам исполнитель (подмена python→python3, повторы и т.д.)
        self.hints = []   # подсказки для ИИ по тексту ошибки
        self.blocked = ""  # причина, если команда не запускалась

    @property
    def ok(self):
        return self.rc == 0 and not self.timed_out and not self.cancelled and not self.blocked

    def for_model(self, max_chars=3500):
        """Компактный отчёт, который отправляется обратно модели."""
        out = self.output.strip()
        if len(out) > max_chars:
            head = out[: max_chars // 4]
            tail = out[-(max_chars - max_chars // 4):]
            out = f"{head}\n... [пропущено {len(out) - max_chars} символов] ...\n{tail}"
        status = "OK" if self.ok else "ОШИБКА"
        parts = [f"[{status}] код выхода: {self.rc if self.rc is not None else 'нет'}; время: {self.duration:.1f} с; папка: {self.cwd}"]
        if self.blocked:
            parts.append(f"Команда НЕ выполнялась: {self.blocked}")
        if self.timed_out:
            parts.append("Команда превысила таймаут и была остановлена.")
        if self.cancelled:
            parts.append("Выполнение отменено пользователем.")
        for n in self.notes:
            parts.append(f"(система: {n})")
        parts.append("Вывод:\n" + (out if out else "(пусто)"))
        if self.hints:
            parts.append("Подсказки системы:\n" + "\n".join("- " + h for h in self.hints))
        return "\n".join(parts)


# ───────────────────────── опасные команды ─────────────────────────
_DANGER_PATTERNS = [
    (r"\bmkfs(\.\w+)?\b", "форматирование файловой системы"),
    (r"\bdd\b[^\n;&|]*\bof=/dev/", "запись на блочное устройство через dd"),
    (r">\s*/dev/(sd|nvme|vd|hd|mmcblk)\w*", "запись прямо в блочное устройство"),
    (r":\s*\(\s*\)\s*\{[^}]*:\s*\|\s*:", "fork-бомба"),
    (r"\bchmod\s+(-\w+\s+)*[0-7]*777\s+(/|~|\$HOME)\s*($|[;&|])", "chmod 777 на системный/домашний каталог"),
    (r"\bchown\s+-\w*R\w*\s+\S+\s+(/|~|\$HOME)\s*($|[;&|])", "рекурсивная смена владельца всего каталога"),
    (r"\b(curl|wget)\b[^\n|;]*\|\s*(sudo\s+)?(ba|z|da)?sh\b", "выполнение скрипта из интернета без просмотра"),
    (r"(^|[;&|]\s*)(sudo\s+)?(shutdown|reboot|poweroff|halt)\b", "выключение/перезагрузка системы"),
    (r"\bsystemctl\s+(poweroff|reboot|halt|kexec)\b", "выключение/перезагрузка системы"),
    (r"\binit\s+[06]\b", "выключение/перезагрузка системы"),
    (r"\bgit\s+push\b[^\n;&|]*(--force\b|\s-f\b)", "принудительная отправка в git (git push --force)"),
    (r"\b(fdisk|parted|wipefs|sgdisk|cryptsetup\s+luksFormat)\b", "работа с разделами диска"),
    (r"\bkillall\s+(-9\s+)?(Xorg|Xwayland|gnome-shell|plasmashell|systemd|sshd)\b", "завершение критичного системного процесса"),
    (r"\b(rm|mv)\b[^\n;&|]*\s/(etc|boot|usr|bin|sbin|lib|lib64|var|dev|proc|sys)(/\S*)?(\s|$)", "изменение системных каталогов"),
]
_PROTECTED_RM = {"/", "/*", "~", "~/", "~/*", "$HOME", "$HOME/", "$HOME/*", "*", ".", "..", "./*", "/home", "/root"}


def is_dangerous(script, workdir=None):
    """Возвращает текст причины, если команду стоит подтвердить у пользователя, иначе None."""
    for pat, reason in _DANGER_PATTERNS:
        if re.search(pat, script):
            return reason
    workdir = os.path.realpath(workdir) if workdir else None
    for m in re.finditer(r"(?:^|[;&|(]\s*)(?:sudo\s+(?:-\S+\s+)*)?rm\s+([^;&|\n]*)", script):
        try:
            args = shlex.split(m.group(1))
        except ValueError:
            args = m.group(1).split()
        recursive = any(a.startswith("-") and not a.startswith("--") and ("r" in a or "R" in a) for a in args) \
            or "--recursive" in args
        if not recursive:
            continue
        for a in args:
            if a.startswith("-"):
                continue
            if a in _PROTECTED_RM or ".." in a.split("/"):
                return f"рекурсивное удаление `{a}`"
            if a.startswith(("/", "~", "$HOME")) and not (workdir and os.path.realpath(os.path.expanduser(a)).startswith(workdir + os.sep)):
                return f"рекурсивное удаление вне рабочей папки: `{a}`"
    return None


def uses_sudo(script):
    return bool(re.search(r"(?:^|[;&|(]\s*)sudo\b", script, re.M))


# ───────────────────────── нормализация команд ─────────────────────────
def normalize_script(script, env=None):
    """Мелкие безопасные исправления типичных ошибок моделей. Возвращает (скрипт, заметки)."""
    env = env or sysinfo.clean_env()
    notes = []
    s = script.replace("\r\n", "\n").strip("\n")

    # «$ ls» → «ls» (модели любят добавлять приглашение)
    s2 = re.sub(r"(?m)^\s*\$\s+(?=\S)", "", s)
    if s2 != s:
        notes.append("убраны приглашения `$ ` в начале строк")
        s = s2

    has = lambda t: bool(sysinfo.which(t, env))
    cmd_start = r"((?:^|[;&|(]\s*)(?:sudo\s+(?:-\S+\s+)*)?)"

    if not has("python") and has("python3"):
        s2 = re.sub(r"(?m)" + cmd_start + r"python(?=\s|$)", r"\1python3", s)
        if s2 != s:
            notes.append("`python` отсутствует в системе — заменено на `python3`")
            s = s2
    if not has("pip") and has("pip3"):
        s2 = re.sub(r"(?m)" + cmd_start + r"pip(?=\s|$)", r"\1pip3", s)
        if s2 != s:
            notes.append("`pip` отсутствует — заменено на `pip3`")
            s = s2
    if not has("pip") and not has("pip3") and has("python3"):
        s2 = re.sub(r"(?m)" + cmd_start + r"pip3?(?=\s|$)", r"\1python3 -m pip", s)
        if s2 != s:
            notes.append("pip отсутствует — заменено на `python3 -m pip`")
            s = s2

    # Команды, которые без -y ждут ввода и в нашем режиме (stdin закрыт) просто сорвутся
    def fix_line(line):
        m = re.search(r"\b(apt-get|apt|dnf|yum)\s+((?:-\S+\s+)*)(install|remove|purge|upgrade|dist-upgrade|full-upgrade|autoremove)\b", line)
        if m:
            tail = line[m.end():]
            seg = re.split(r"[;&|]", tail, 1)[0]
            if not re.search(r"(^|\s)(-y|--yes|--assume-yes|-qq|-s|--simulate|--dry-run)(\s|$)", seg + " " + m.group(2)):
                line = line[:m.end()] + " -y" + line[m.end():]
                notes.append(f"добавлен `-y` для `{m.group(1)} {m.group(3)}`")
        m = re.search(r"\bpacman\s+(-S[a-z]*|-R[a-z]*|-U)\b", line)
        if m and "--noconfirm" not in line and not re.search(r"-S[a-z]*[sqi]\b", m.group(1)):
            line = line[:m.end()] + " --noconfirm" + line[m.end():]
            notes.append("добавлен `--noconfirm` для pacman")
        m = re.search(r"\bzypper\s+(?!-n\b|--non-interactive)(install|in|remove|rm|update|up|dup)\b", line)
        if m:
            line = line.replace("zypper ", "zypper --non-interactive ", 1)
            notes.append("добавлен `--non-interactive` для zypper")
        m = re.search(r"\bnpm\s+init\b(?!\s+(-y|--yes))(?=\s*($|[;&|]))", line)
        if m:
            line = line[:m.end()] + " -y" + line[m.end():]
            notes.append("добавлен `-y` для `npm init`")
        return line

    s = "\n".join(fix_line(l) for l in s.split("\n"))
    return s, notes


# ───────────────────────── подсказки по ошибкам ─────────────────────────
_PKG_NAMES = {
    # (что нужно): {менеджер: пакет}
    "pip": {"apt-get": "python3-pip", "dnf": "python3-pip", "yum": "python3-pip", "pacman": "python-pip", "zypper": "python3-pip", "apk": "py3-pip"},
    "pip3": {"apt-get": "python3-pip", "dnf": "python3-pip", "yum": "python3-pip", "pacman": "python-pip", "zypper": "python3-pip", "apk": "py3-pip"},
    "venv": {"apt-get": "python3-venv", "dnf": "python3", "pacman": "python", "zypper": "python3", "apk": "python3"},
    "tkinter": {"apt-get": "python3-tk", "dnf": "python3-tkinter", "yum": "python3-tkinter", "pacman": "tk", "zypper": "python3-tk", "apk": "py3-tkinter"},
    "gcc": {"apt-get": "build-essential", "dnf": "gcc make", "yum": "gcc make", "pacman": "base-devel", "zypper": "gcc make", "apk": "build-base"},
    "make": {"apt-get": "build-essential", "dnf": "make", "yum": "make", "pacman": "base-devel", "zypper": "make", "apk": "build-base"},
    "node": {"apt-get": "nodejs", "dnf": "nodejs", "pacman": "nodejs", "zypper": "nodejs", "apk": "nodejs"},
    "npm": {"apt-get": "npm", "dnf": "npm", "pacman": "npm", "zypper": "npm", "apk": "npm"},
    "python3": {"apt-get": "python3", "dnf": "python3", "pacman": "python", "zypper": "python3", "apk": "python3"},
    "ip": {"apt-get": "iproute2", "dnf": "iproute", "pacman": "iproute2", "zypper": "iproute2", "apk": "iproute2"},
}
_ALTERNATIVES = {
    "ifconfig": "используй `ip addr` / `ip route`",
    "netstat": "используй `ss -tulpn`",
    "service": "используй `systemctl` (если есть systemd) или запускай бинарник напрямую",
    "python": "используй `python3`",
    "pip": "используй `pip3` или `python3 -m pip`",
    "apt": "используй `apt-get` или пакетный менеджер из отчёта о системе",
    "yum": "используй `dnf` или пакетный менеджер из отчёта о системе",
    "open": "в Linux — `xdg-open`",
    "pbcopy": "в Linux — `xclip -selection clipboard` / `wl-copy`",
    "brew": "в Linux — пакетный менеджер дистрибутива",
    "choco": "это Windows — используй пакетный менеджер дистрибутива",
    "systemctl": "systemd нет — запускай процессы напрямую (`nohup ... &`)",
}


def suggest_install(info, what):
    pm = (info or {}).get("pkg", {}).get("name") if info else ""
    if not pm:
        return f"пакетный менеджер не найден — `{what}` придётся ставить вручную (из исходников/бинарника)"
    pkg = _PKG_NAMES.get(what, {}).get(pm, what)
    return f"`{(info['pkg']['install'])} {pkg}`" + ("" if pm != "apt-get" else " (перед этим при необходимости `sudo apt-get update`)")


_TRANSIENT = re.compile(
    r"(could not resolve host|temporary failure in name resolution|name or service not known|network is unreachable|"
    r"connection (timed out|reset|refused|closed)|timed out|timeout|failed to connect|early eof|rpc failed|"
    r"remote end hung up|gnutls_handshake|gnutls recv error|ssl_error_syscall|ssl connect error|tls (handshake|connection)|"
    r"http/2 stream|curl 92|curl 18|curl 28|curl 35|curl 56|invalid index-pack|unexpected disconnect|"
    r"temporary failure|try again|service unavailable|bad gateway|gateway time-?out|502|503|504|"
    r"read timed out|readtimeouterror|connectionerror|incomplete read|premature end|econnreset|etimedout|eai_again|"
    r"failed to fetch|hash sum mismatch|unable to fetch some archives|download failed|cannot download)", re.I)
_GIT_NET_FAIL = re.compile(r"(early eof|rpc failed|remote end hung up|http/2 stream|gnutls|ssl_error_syscall|"
                           r"invalid index-pack|unexpected disconnect|fetch-pack|curl (92|18|28|35|56)|"
                           r"unable to access|failed to connect|could not resolve|timed out|connection)", re.I)


def is_transient(output):
    return bool(_TRANSIENT.search(output or ""))


def classify_output(output, rc, script, info=None, timed_out=False, timeout=0):
    """Превращает сырой вывод ошибки в понятные подсказки для модели."""
    hints = []
    text = output or ""
    low = text.lower()
    pm = (info or {}).get("pkg", {}).get("name", "") if info else ""

    if timed_out:
        hints.append(f"Таймаут {int(timeout)} с. Если это сервер/долгий процесс — запусти его в фоне: "
                     "`nohup <команда> > run.log 2>&1 & echo $!`, затем `sleep 2; tail -n 20 run.log`. "
                     "Если программа ждёт ввода — вызови её с флагами без вопросов (-y, --yes, --non-interactive).")
    if rc == 127 or "command not found" in low or re.search(r": not found\b", low) or "no such file or directory" in low and rc == 127:
        m = re.search(r"(?:bash: (?:line \d+: )?|sh: \d+: )([\w.+-]+): (?:command )?not found", text)
        tool = m.group(1) if m else None
        if tool:
            if tool in _ALTERNATIVES:
                hints.append(f"`{tool}` нет в этой системе: {_ALTERNATIVES[tool]}.")
            else:
                hints.append(f"Утилиты `{tool}` нет в системе. Установить: {suggest_install(info, tool)}. "
                             f"Либо используй другую утилиту; сначала проверь `command -v {tool}`.")
        else:
            hints.append("Команда не найдена. Проверь имя через `command -v <имя>`.")
    if "permission denied" in low:
        hints.append("Нет прав. Варианты: файл не исполняемый (`chmod +x`), каталог принадлежит другому пользователю "
                     "(`ls -ld`), нужен sudo, либо раздел смонтирован с noexec (`mount | grep noexec`). Не делай chmod -R 777.")
    if "externally-managed-environment" in low:
        hints.append("Системный Python защищён (PEP 668). НЕ ломай систему: создай venv — "
                     "`python3 -m venv .venv && . .venv/bin/activate && pip install <пакет>`.")
        sysinfo.remember("pip_needs_venv")
    if "ensurepip is not available" in low or "python3-venv" in low:
        hints.append(f"Не хватает модуля venv. Установи: {suggest_install(info, 'venv')}.")
    if re.search(r"could not get lock|unable to acquire the dpkg|dpkg frontend lock|is another process using it|database is locked|waiting for cache lock", low):
        hints.append("Менеджер пакетов занят другим процессом (обновление/GUI-установщик). Подожди 30–60 с и повтори; "
                     "проверь `ps aux | grep -E 'apt|dpkg|dnf|pacman'`. Lock-файлы вручную НЕ удаляй.")
    if "unable to locate package" in low or "no match for argument" in low or "target not found" in low or "no package" in low and "available" in low:
        hints.append("Пакет не найден. Обнови индекс пакетов (`" + ((info or {}).get("pkg", {}).get("update", "") or "обнови индекс") +
                     "`) или проверь имя — в вашем дистрибутиве пакет может называться иначе (поищи: "
                     + {"apt-get": "`apt-cache search`", "dnf": "`dnf search`", "pacman": "`pacman -Ss`", "zypper": "`zypper search`", "apk": "`apk search`"}.get(pm, "поиск пакетов") + ").")
    if "no space left on device" in low:
        hints.append("Закончилось место на диске. Проверь `df -h` и `du -sh * | sort -h | tail`; не удаляй системные файлы.")
    if re.search(r"modulenotfounderror: no module named '(\w[\w.]*)'", low):
        mod = re.search(r"no module named '([\w.]+)'", low).group(1).split(".")[0]
        if mod == "_tkinter" or mod == "tkinter":
            hints.append(f"Нет tkinter. Установи системный пакет: {suggest_install(info, 'tkinter')}.")
        else:
            hints.append(f"Не хватает Python-модуля `{mod}`: установи его в venv проекта (`.venv/bin/pip install {mod}`), "
                         "название пакета на PyPI может отличаться от имени модуля (cv2→opencv-python, PIL→Pillow, yaml→pyyaml).")
    if "address already in use" in low or "eaddrinuse" in low:
        hints.append("Порт занят. Найди процесс: `ss -tulpn | grep :<порт>` и останови его или выбери другой порт.")
    if re.search(r"destination path '.*' already exists and is not an empty directory", low):
        hints.append("Папка для git clone уже существует и не пуста. Не удаляй её без нужды: проверь `ls -la <папка>`, "
                     "возможно репозиторий уже склонирован — тогда сделай `git -C <папка> pull`.")
    if re.search(r"repository not found|authentication failed|could not read username|terminal prompts disabled", low):
        hints.append("Репозиторий не найден или приватный (git не может спросить логин — интерактив отключён). "
                     "Проверь URL (`git ls-remote <url>`); для приватных нужен токен/SSH-ключ.")
    if re.search(r"ssl certificate problem|certificate verify failed|self[- ]signed|unable to get local issuer", low):
        hints.append("Проблема с SSL-сертификатами. Возможно, не установлен пакет ca-certificates или неверно время/дата системы "
                     "(`date`). НЕ отключай проверку сертификатов (`-k`, `sslVerify=false`) без ведома пользователя.")
    if is_transient(text) and rc not in (0, None):
        hints.append("Похоже на сетевой сбой (DNS/таймаут/обрыв). Проверь соединение (`curl -sI https://github.com | head -1`), "
                     "прокси (`env | grep -i proxy`). Повтор может помочь — исполнитель уже пробовал повторить сам.")
    if re.search(r"unable to access|tunnel failed|proxyconnect|proxy error|received http code 40[37] from proxy|couldn't connect to server", low) and not is_transient(text):
        hints.append("Сервер недоступен (сеть, прокси или фаервол блокирует адрес). Проверь `env | grep -i proxy`, "
                     "`curl -sI <url> | head -3`, доступность хоста; возможно, нужен VPN/зеркало.")
    if "unable to resolve host" in low and "sudo" in low:
        hints.append("sudo ругается на имя хоста — это не ошибка выполнения, команда обычно всё равно отработала.")
    if "a terminal is required" in low or "no tty present" in low or "sudo: a password is required" in low:
        hints.append("sudo требует пароль/терминал. Пароль запрашивает приложение, не пытайся обходить это.")
    if re.search(r"sorry, try again|incorrect password|authentication failure", low):
        hints.append("Неверный пароль sudo.")
    if rc not in (0, None) and not hints and not timed_out:
        hints.append("Прочитай текст ошибки выше, исправь причину и повтори. Не повторяй ту же команду без изменений.")
    return hints


# ───────────────────────── git: повторы и запасной путь ─────────────────────────
_GIT_NET_CMD = re.compile(r"\bgit\s+(?:-\S+\s+(?:\S+\s+)?)*(clone|pull|fetch)\b")
_NET_TOOLS = re.compile(r"\b(git\s+(clone|pull|fetch|submodule)|curl|wget|pip3?\s+(install|download)|python3?\s+-m\s+pip\s+(install|download)|npm\s+(install|i|ci)|yarn|pnpm|"
                        r"apt-get\s+(update|install)|apt\s+(update|install)|dnf|yum|pacman\s+-S|zypper|apk\s+(add|update)|cargo\s+(install|build|fetch)|go\s+(get|install|mod)|npx)\b")
_GIT_HTTP1 = "-c http.version=HTTP/1.1 -c http.postBuffer=524288000 -c http.lowSpeedLimit=0 -c http.lowSpeedTime=999999"


def _add_git_opts(script):
    return _GIT_NET_CMD.sub(lambda m: m.group(0).replace("git ", f"git {_GIT_HTTP1} ", 1) if _GIT_HTTP1 not in m.group(0) else m.group(0), script)


def _add_depth(script):
    def repl(m):
        return m.group(0) if "--depth" in m.group(0) else m.group(0) + " --depth 1"
    return re.sub(r"\bgit\s+(?:-\S+\s+(?:\S+\s+)?)*clone\b", repl, script)


_CLONE_OPTS_WITH_ARG = {"-b", "--branch", "--depth", "-o", "--origin", "--reference", "-c", "--config", "--template",
                        "-j", "--jobs", "--filter", "--separate-git-dir", "-u", "--upload-pack", "--shallow-since",
                        "--shallow-exclude", "--server-option", "--reference-if-able"}


def parse_clone(script):
    """Если скрипт — единственная команда `git clone`, возвращает (url, ветка|None, папка|None)."""
    lines = [l.strip() for l in script.strip().split("\n") if l.strip() and not l.strip().startswith("#")]
    if len(lines) != 1:
        return None
    if re.search(r"[;&|<>`]|\$\(", lines[0]):
        return None
    try:
        toks = shlex.split(lines[0])
    except ValueError:
        return None
    if "clone" not in toks or toks[0] != "git":
        return None
    i = toks.index("clone") + 1
    branch, pos = None, []
    while i < len(toks):
        t = toks[i]
        if t in _CLONE_OPTS_WITH_ARG and "=" not in t:
            if t in ("-b", "--branch") and i + 1 < len(toks):
                branch = toks[i + 1]
            i += 2
            continue
        if t.startswith("--branch="):
            branch = t.split("=", 1)[1]
        elif t.startswith("-"):
            pass
        else:
            pos.append(t)
        i += 1
    if not pos:
        return None
    return pos[0], branch, (pos[1] if len(pos) > 1 else None)


def clone_target(script, cwd):
    """Папка, которую создаст git clone (для очистки неудачных попыток)."""
    parsed = parse_clone(script)
    if not parsed:
        return None
    url, _, d = parsed
    if not d:
        d = re.split(r"[/:]", url.rstrip("/"))[-1]
        d = d[:-4] if d.endswith(".git") else d
    return d if os.path.isabs(d) else os.path.join(cwd, d)


def tarball_url(url, branch=None):
    """Адрес архива для github/gitlab, иначе None."""
    m = re.match(r"(?:https?://|git@)(?:www\.)?(github\.com|gitlab\.com)[/:]([^/\s]+)/([^/\s]+?)(?:\.git)?/?$", url)
    if not m:
        return None
    host, owner, repo = m.groups()
    ref = branch or "HEAD"
    if host == "github.com":
        return f"https://codeload.github.com/{owner}/{repo}/tar.gz/{ref}"
    return f"https://gitlab.com/{owner}/{repo}/-/archive/{ref}/{repo}-{ref.replace('/', '-')}.tar.gz"


# ───────────────────────── исполнитель ─────────────────────────
class CommandRunner:
    def __init__(self, workdir, info=None, on_output=None, on_status=None, is_cancelled=None,
                 sudo_password=None, default_timeout=300):
        self.workdir = workdir
        self.cwd = workdir
        self.info = info
        self.on_output = on_output or (lambda line: None)
        self.on_status = on_status or (lambda text: None)
        self.is_cancelled = is_cancelled or (lambda: False)
        self.sudo_password = sudo_password     # callable(retry: bool) -> str | None
        self.default_timeout = default_timeout
        self._sudo_pw = None
        self._sudo_nopass = None

    # --- sudo ---
    def _ensure_sudo(self):
        """True — sudo готов (root / без пароля / пароль получен); False — отказ пользователя."""
        if os.geteuid() == 0:
            return True
        if self._sudo_nopass is None:
            try:
                p = subprocess.run(["sudo", "-n", "true"], env=sysinfo.clean_env(), stdin=subprocess.DEVNULL,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8)
                self._sudo_nopass = (p.returncode == 0)
            except Exception:
                self._sudo_nopass = False
        if self._sudo_nopass:
            return True
        if not self.sudo_password:
            return False
        for attempt in range(3):
            if self._sudo_pw is None:
                self._sudo_pw = self.sudo_password(attempt > 0)
                if self._sudo_pw is None:
                    return False
            try:
                p = subprocess.run(["sudo", "-S", "-p", "", "-v"], input=self._sudo_pw + "\n", text=True,
                                   env=sysinfo.clean_env(), capture_output=True, timeout=15)
                if p.returncode == 0:
                    return True
            except Exception:
                return False
            self._sudo_pw = None
        return False

    # --- один запуск ---
    def _kill_group(self, proc):
        for sig in (signal.SIGTERM, signal.SIGKILL):
            try:
                os.killpg(proc.pid, sig)
            except (ProcessLookupError, PermissionError):
                return
            for _ in range(15):
                if proc.poll() is not None:
                    return
                time.sleep(0.1)

    def _run_once(self, script, timeout):
        res = CommandResult(script)
        res.cwd = self.cwd

        # синтаксис проверяем заранее: bash исполняет скрипт по мере разбора и может сделать полдела
        fd, path = tempfile.mkstemp(prefix="aic_", suffix=".sh")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(SCRIPT_HEADER + script + "\n")
            chk = subprocess.run(["bash", "-n", path], capture_output=True, text=True, timeout=10)
            if chk.returncode != 0:
                msg = chk.stderr.replace(path, "script").strip()
                res.rc = 2
                res.output = "Синтаксическая ошибка в bash-блоке, ничего не выполнено:\n" + msg
                res.hints = ["Исправь синтаксис (кавычки, скобки, heredoc). Присылай команды простым bash без Python-кода внутри."]
                self.on_output(res.output)
                return res

            env = sysinfo.clean_env()
            stdin_data = None
            run_script_path = path
            if uses_sudo(script) and os.geteuid() != 0:
                if not self._ensure_sudo():
                    res.rc = 1
                    res.blocked = "для sudo нужен пароль, а он не был введён"
                    res.output = ""
                    return res
                if self._sudo_pw:
                    n = len(re.findall(r"\bsudo\b", script)) + 1
                    stdin_data = (self._sudo_pw + "\n") * n
                    fixed = re.sub(r"\bsudo\b(?!\s+-(?:S|n)\b)", "sudo -S -p ''", script)
                    with open(path, "w", encoding="utf-8", newline="\n") as f:
                        f.write(SCRIPT_HEADER + fixed + "\n")

            cwd = self.cwd if os.path.isdir(self.cwd) else self.workdir
            started = time.time()
            proc = subprocess.Popen(["bash", "--noprofile", "--norc", run_script_path], cwd=cwd, env=env,
                                    stdin=subprocess.PIPE if stdin_data else subprocess.DEVNULL,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
            if stdin_data:
                try:
                    proc.stdin.write(stdin_data.encode())
                    proc.stdin.close()
                except OSError:
                    pass

            lines = []
            cwd_after = [None]
            state = {"dropped": 0}

            def emit(raw):
                text = raw.decode("utf-8", errors="replace").rstrip("\r")
                if "\r" in text:  # прогресс-бары: оставляем последний кадр
                    parts = [p for p in text.split("\r") if p.strip()]
                    text = parts[-1] if parts else ""
                text = strip_ansi(text).replace(run_script_path, "bash")  # временный файл скрипта — шум для пользователя и модели
                if text.startswith(CWD_MARK):
                    cwd_after[0] = text[len(CWD_MARK):].strip()
                    return
                if not text.strip() and (not lines or not lines[-1].strip()):
                    return
                lines.append(text)
                if len(lines) > 6000:
                    del lines[300:3000]
                    state["dropped"] += 2700
                    lines.insert(300, f"... [вывод слишком длинный, пропущено ~{state['dropped']} строк] ...")
                self.on_output(text)

            def reader():
                buf = b""
                fdr = proc.stdout.fileno()
                while True:
                    try:
                        chunk = os.read(fdr, 65536)
                    except (OSError, ValueError):
                        break
                    if not chunk:
                        break
                    buf += chunk
                    while b"\n" in buf:
                        line, buf = buf.split(b"\n", 1)
                        emit(line)
                if buf:
                    emit(buf)

            rt = threading.Thread(target=reader, daemon=True)
            rt.start()

            while proc.poll() is None:
                if self.is_cancelled():
                    res.cancelled = True
                    self._kill_group(proc)
                    break
                if time.time() - started > timeout:
                    res.timed_out = True
                    self._kill_group(proc)
                    break
                time.sleep(0.05)
            rt.join(timeout=2.0)   # фоновый процесс может держать пайп — ждать вечно нельзя
            try:
                proc.stdout.close()
            except Exception:
                pass

            res.duration = time.time() - started
            res.rc = proc.returncode if not (res.timed_out or res.cancelled) else (124 if res.timed_out else 130)
            res.output = "\n".join(lines)
            if cwd_after[0] and os.path.isdir(cwd_after[0]):
                self.cwd = cwd_after[0]
            res.cwd = self.cwd
            return res
        finally:
            try:
                os.unlink(path)
            except OSError:
                pass

    # --- публичный запуск с повторами ---
    def run(self, script, timeout=None):
        timeout = timeout or self.default_timeout
        env = sysinfo.clean_env()
        learned = sysinfo.load_learned()
        script, notes = normalize_script(script, env)
        original = script

        git_net = bool(_GIT_NET_CMD.search(script))
        if git_net and learned.get("git_http1"):
            script = _add_git_opts(script)
            notes.append("git: включён HTTP/1.1 (в этой системе HTTP/2 нестабилен)")
        if git_net and learned.get("git_shallow"):
            script = _add_depth(script)

        # план попыток
        variants = [(script, "")]
        if git_net:
            v2 = _add_git_opts(script)
            if v2 != script:
                variants.append((v2, "git: HTTP/1.1 + большой буфер"))
            v3 = _add_depth(v2)
            if v3 != v2:
                variants.append((v3, "git: shallow-клон (--depth 1)"))
        elif _NET_TOOLS.search(script):
            variants += [(script, "повтор после паузы"), (script, "повтор после паузы")]

        target = clone_target(original, self.cwd) if git_net else None
        target_existed = bool(target and os.path.exists(target))
        before_cwd = self.cwd

        res = None
        for idx, (variant, why) in enumerate(variants):
            if idx > 0:
                delay = 3 * idx
                self.on_status(f"Повтор {idx + 1}/{len(variants)}: {why}…")
                self.on_output(f"[AIC] повтор {idx + 1}/{len(variants)} ({why or 'после паузы'}), пауза {delay} с")
                for _ in range(delay * 10):
                    if self.is_cancelled():
                        break
                    time.sleep(0.1)
                if self.is_cancelled():
                    break
                self.cwd = before_cwd
                if target and not target_existed and os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)  # убираем только то, что создала неудачная попытка
            res = self._run_once(variant, timeout)
            res.attempts = idx + 1
            if res.ok or res.cancelled or res.blocked:
                if res.ok and idx > 0 and git_net:
                    if "HTTP/1.1" in variant and "--depth" not in variant:
                        sysinfo.remember("git_http1")
                    elif "--depth" in variant:
                        sysinfo.remember("git_http1")
                        sysinfo.remember("git_shallow")
                break
            retryable = is_transient(res.output) or (git_net and bool(_GIT_NET_FAIL.search(res.output))) or res.timed_out
            if not retryable:
                break

        if res is None:
            res = CommandResult(script)
            res.cancelled = True
            res.rc = 130

        # запасной путь: архив вместо git clone
        if git_net and not res.ok and not res.cancelled and not res.blocked and target is not None:
            parsed = parse_clone(original)
            url = tarball_url(parsed[0], parsed[1]) if parsed else None
            if url and (shutil.which("curl") or shutil.which("wget")) and (is_transient(res.output) or _GIT_NET_FAIL.search(res.output)):
                self.on_status("git clone не удался, пробую скачать архив…")
                self.on_output("[AIC] git clone не сработал — пробую скачать архив репозитория (без истории git)")
                self.cwd = before_cwd
                if not target_existed and os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)
                q = shlex.quote(target)
                dl = (f"mkdir -p {q} && tmp=$(mktemp) && "
                      f"(curl -fL --retry 3 --connect-timeout 20 -o \"$tmp\" {shlex.quote(url)} || wget -q -O \"$tmp\" {shlex.quote(url)}) && "
                      f"tar -xzf \"$tmp\" -C {q} --strip-components=1 && rm -f \"$tmp\"")
                res2 = self._run_once(dl, timeout)
                if res2.ok and os.path.isdir(target) and os.listdir(target):
                    sysinfo.remember("git_tarball")
                    res2.attempts = res.attempts + 1
                    res2.notes.append(f"git clone не сработал, репозиторий скачан архивом в {target} (папки .git нет)")
                    res = res2
                elif not target_existed and os.path.isdir(target):
                    shutil.rmtree(target, ignore_errors=True)

        res.notes = notes + res.notes
        if res.attempts > 1 and res.ok:
            res.notes.append(f"получилось с попытки {res.attempts} (ранние попытки упали из-за нестабильной сети/git)")
        elif res.attempts > 1:
            res.notes.append(f"сделано попыток: {res.attempts}")

        # проверка «успеха»: код 0 ещё не значит, что клон на месте
        if git_net and res.ok and target and "clone" in original and not os.path.isdir(target):
            res.hints.append(f"git clone вернул 0, но папки {target} нет — проверь вывод и `ls`.")
        if git_net and res.ok and target and os.path.isdir(target) and not os.listdir(target):
            res.hints.append(f"Папка {target} пустая — клон не удался, проверь URL/ветку.")

        res.hints = res.hints + [h for h in classify_output(res.output, res.rc, original, self.info, res.timed_out, timeout) if h not in res.hints]
        res.command = original
        return res


# ───────────────────────── запуск терминала ─────────────────────────
def _terminal_variants(cwd, cmd):
    q = shlex.quote
    sh = ["bash", "-c", cmd]
    shs = "bash -c " + q(cmd)
    return [
        ("gnome-terminal", ["gnome-terminal", f"--working-directory={cwd}", "--"] + sh),
        ("konsole", ["konsole", "--workdir", cwd, "-e"] + sh),
        ("xfce4-terminal", ["xfce4-terminal", f"--working-directory={cwd}", "-x"] + sh),
        ("kitty", ["kitty", "--directory", cwd] + sh),
        ("alacritty", ["alacritty", "--working-directory", cwd, "-e"] + sh),
        ("tilix", ["tilix", "-w", cwd, "-e", shs]),
        ("mate-terminal", ["mate-terminal", f"--working-directory={cwd}", "-x"] + sh),
        ("lxterminal", ["lxterminal", f"--working-directory={cwd}", "-e", shs]),
        ("terminator", ["terminator", f"--working-directory={cwd}", "-x"] + sh),
        ("foot", ["foot", f"--working-directory={cwd}"] + sh),
        ("wezterm", ["wezterm", "start", "--cwd", cwd, "--"] + sh),
        ("xterm", ["xterm", "-e"] + sh),
        ("st", ["st", "-e"] + sh),
        ("urxvt", ["urxvt", "-e"] + sh),
        ("x-terminal-emulator", ["x-terminal-emulator", "-e"] + sh),
    ]


def open_terminal(cwd, command=None):
    """Открывает эмулятор терминала. Возвращает (успех, имя|текст ошибки)."""
    env = sysinfo.clean_env()
    for k in ("TERM", "NO_COLOR", "PAGER", "GIT_PAGER", "MANPAGER", "PYTHONUNBUFFERED"):
        env.pop(k, None)
    env["TERM"] = os.environ.get("TERM", "xterm-256color")
    inner = (command + "; echo; echo '[Завершено. Терминал остаётся открытым]'; exec bash") if command else "exec bash"
    variants = _terminal_variants(cwd, inner)
    pref = os.environ.get("TERMINAL", "").split()[:1]
    if pref:
        variants.sort(key=lambda v: 0 if v[0] == os.path.basename(pref[0]) else 1)
    tried = []
    for name, argv in variants:
        if not shutil.which(name, path=env["PATH"]):
            continue
        tried.append(name)
        try:
            p = subprocess.Popen(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, start_new_session=True)
            time.sleep(0.5)
            rc = p.poll()
            if rc is None or rc == 0:
                return True, name
        except OSError:
            continue
    if tried:
        return False, "Терминалы найдены (" + ", ".join(tried) + "), но не запустились."
    return False, "Не найден эмулятор терминала. Установите, например, xterm или gnome-terminal."
