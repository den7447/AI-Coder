"""Клиент локального Ollama (стриминг через /api/chat) с понятными ошибками."""
import json
import os
import shutil
import subprocess
import time

import requests

import sysinfo


class LLMError(Exception):
    """Ошибка общения с моделью; текст уже пригоден для показа пользователю."""


def ollama_base_url():
    """Адрес Ollama с учётом стандартной переменной OLLAMA_HOST."""
    host = os.environ.get("OLLAMA_HOST", "").strip() or "127.0.0.1:11434"
    if "://" not in host:
        host = "http://" + host
    host = host.replace("0.0.0.0", "127.0.0.1").replace("[::]", "127.0.0.1")
    if host.count(":") == 1:  # http://host без порта
        host += ":11434"
    return host.rstrip("/")


class OllamaClient:
    def __init__(self):
        self.base = ollama_base_url()
        self._session = requests.Session()
        self._session.trust_env = False  # системный прокси не должен перехватывать localhost

    def is_running(self, timeout=1.5):
        try:
            return self._session.get(self.base + "/api/tags", timeout=timeout).status_code == 200
        except requests.RequestException:
            return False

    def list_models(self, timeout=3):
        r = self._session.get(self.base + "/api/tags", timeout=timeout)
        r.raise_for_status()
        return [m["name"] for m in r.json().get("models", [])]

    def start_server(self):
        """Пытается запустить `ollama serve` в фоне. Возвращает (успех, сообщение)."""
        exe = sysinfo.which("ollama")
        if not exe:
            return False, "Команда `ollama` не найдена. Установите Ollama: https://ollama.com/download"
        if self.is_running():
            return True, "Ollama уже запущена."
        try:
            log = open(os.path.join(sysinfo.APP_DIR, "ollama_serve.log"), "ab")
            subprocess.Popen([exe, "serve"], stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                             start_new_session=True, env=sysinfo.clean_env())
        except OSError as e:
            return False, f"Не удалось запустить ollama serve: {e}"
        for _ in range(30):
            time.sleep(0.5)
            if self.is_running():
                return True, "Ollama запущена."
        return False, "Ollama не ответила за 15 секунд. Если Ollama работает как systemd-служба — запустите: sudo systemctl start ollama"

    def chat(self, messages, model, temperature=0.2, num_ctx=4096, on_token=None, is_cancelled=None):
        """Потоковый чат. Возвращает полный текст. Бросает LLMError с понятным текстом."""
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,
            "options": {"temperature": float(temperature), "num_ctx": int(num_ctx)},
        }
        try:
            resp = self._session.post(self.base + "/api/chat", json=payload, stream=True, timeout=(5, 600))
        except requests.ConnectionError:
            raise LLMError(f"Ollama не отвечает ({self.base}). Запустите её: `ollama serve` "
                           f"(или кнопка «Запустить Ollama» внизу окна).")
        except requests.RequestException as e:
            raise LLMError(f"Ошибка соединения с Ollama: {e}")

        if resp.status_code != 200:
            detail = ""
            try:
                detail = resp.json().get("error", "")
            except Exception:
                detail = resp.text[:200]
            if resp.status_code == 404 or "not found" in detail.lower():
                raise LLMError(f"Модель «{model}» не найдена в Ollama. Скачайте: `ollama pull {model}` "
                               f"или выберите другую в настройках.")
            raise LLMError(f"Ollama вернула ошибку {resp.status_code}: {detail}")

        full = []
        try:
            for raw in resp.iter_lines():
                if is_cancelled and is_cancelled():
                    resp.close()
                    full.append("\n[генерация прервана]")
                    break
                if not raw:
                    continue
                try:
                    chunk = json.loads(raw.decode("utf-8"))
                except ValueError:
                    continue
                if chunk.get("error"):
                    msg = chunk["error"]
                    if "memory" in msg.lower():
                        msg += " (не хватает памяти: выберите модель поменьше или уменьшите контекст)"
                    raise LLMError(f"Ollama: {msg}")
                piece = chunk.get("message", {}).get("content", "")
                if piece:
                    full.append(piece)
                    if on_token:
                        on_token(piece)
                if chunk.get("done"):
                    break
        except requests.RequestException as e:
            if full:
                full.append(f"\n[соединение оборвалось: {e}]")
            else:
                raise LLMError(f"Соединение с Ollama оборвалось: {e}")
        return "".join(full)
