import os
import shutil
import datetime

IGNORE = {'node_modules', '.venv', 'venv', '__pycache__', 'dist', 'build', 'target', 'site-packages'}
KEEP_LAST = 15

class BackupManager:
    def __init__(self, workspace_dir, backup_dir=".ai_backup"):
        self.workspace_dir = workspace_dir
        self.backup_dir = backup_dir

    def _get_backup_path(self):
        return os.path.join(self.workspace_dir, self.backup_dir, "code_backups")

    def create_backup(self):
        try:
            target_dir = self._get_backup_path()
            os.makedirs(target_dir, exist_ok=True)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_folder = os.path.join(target_dir, f"backup_{timestamp}")

            os.makedirs(backup_folder)

            for item in os.listdir(self.workspace_dir):
                if item == self.backup_dir or item.startswith('.') or item in IGNORE:
                    continue
                s = os.path.join(self.workspace_dir, item)
                d = os.path.join(backup_folder, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    shutil.copy2(s, d)
            self._prune()
            return True, "Бекап успешно создан."
        except Exception as e:
            return False, f"Ошибка при создании бекапа: {e}"

    def _prune(self):
        """Хранит только последние KEEP_LAST бекапов, чтобы диск не заполнялся."""
        try:
            target = self._get_backup_path()
            old = sorted(d for d in os.listdir(target) if os.path.isdir(os.path.join(target, d)))[:-KEEP_LAST]
            for d in old:
                shutil.rmtree(os.path.join(target, d), ignore_errors=True)
        except OSError:
            pass

    def restore_latest_backup(self):
        try:
            target_dir = self._get_backup_path()
            if not os.path.exists(target_dir):
                return False, "Нет доступных бекапов."

            backups = sorted([d for d in os.listdir(target_dir) if os.path.isdir(os.path.join(target_dir, d))])
            if not backups:
                return False, "Нет доступных бекапов."

            latest_backup = os.path.join(target_dir, backups[-1])

            # Очищаем текущую рабочую директорию от изменённых файлов
            for item in os.listdir(self.workspace_dir):
                if item == self.backup_dir or item.startswith('.') or item in IGNORE:
                    continue
                item_path = os.path.join(self.workspace_dir, item)
                if os.path.isdir(item_path):
                    shutil.rmtree(item_path)
                else:
                    os.remove(item_path)

            # Восстанавливаем файлы из последней копии
            for item in os.listdir(latest_backup):
                s = os.path.join(latest_backup, item)
                d = os.path.join(self.workspace_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d)
                else:
                    shutil.copy2(s, d)

            return True, f"Восстановлено из бекапа: {backups[-1]}"
        except Exception as e:
            return False, f"Ошибка восстановления: {e}"
