"""Диагностика Linux-системы пользователя.

Задача модуля — не доверять системе «на слово». Дистрибутив может быть
самосборным или модифицированным, os-release может врать, утилиты могут быть
сломанными обёртками, сети может не быть. Поэтому мы не читаем только
/etc/os-release, а реально ПРОБУЕМ: запускаем `tool --version`, проверяем DNS и
TCP-соединение, смотрим sudo, пакетные менеджеры и т.д.

Результат используется:
  * в промпте ассистента (чтобы ИИ не выдумывал `apt` на Arch),
  * в окне «Диагностика системы»,
  * исполнителем команд (подсказки при ошибках).
"""
import json
import os
import platform
import shutil
import socket
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

APP_DIR = os.path.dirname(os.path.abspath(__file__))
LEARNED_FILE = os.path.join(APP_DIR, "linux_profile.json")

# Каталоги, которых часто нет в PATH у приложения, запущенного из .desktop-файла
EXTRA_PATH_DIRS = [
    "~/.local/bin", "/usr/local/bin", "/usr/local/sbin", "/usr/sbin", "/sbin",
    "/snap/bin", "~/.cargo/bin", "~/go/bin", "/opt/ollama/bin", "~/.nvm/current/bin",
    "/var/lib/flatpak/exports/bin", "~/.local/share/flatpak/exports/bin",
]

# (инструмент, аргументы для проверки версии)
TOOL_CHECKS = {
    "bash": ["--version"], "git": ["--version"], "curl": ["--version"], "wget": ["--version"],
    "python3": ["--version"], "pip3": ["--version"], "node": ["--version"], "npm": ["--version"],
    "gcc": ["--version"], "make": ["--version"], "cmake": ["--version"], "docker": ["--version"],
    "ollama": ["--version"], "cargo": ["--version"], "go": ["version"], "java": ["-version"],
    "unzip": ["-v"], "tar": ["--version"], "sudo": ["--version"],
}
# Инструменты, наличие которых просто проверяется через which
TOOL_PRESENCE = [
    "doas", "systemctl", "flatpak", "snap", "xdg-open", "pkexec", "ip", "ss", "ifconfig",
    "netstat", "service", "rsync", "zip", "7z", "jq", "xclip", "xsel", "wl-copy",
]

PACKAGE_MANAGERS = [
    # (бинарник, команда установки, обновление индекса)
    ("apt-get", "sudo apt-get install -y", "sudo apt-get update"),
    ("dnf", "sudo dnf install -y", "sudo dnf check-update"),
    ("yum", "sudo yum install -y", "sudo yum check-update"),
    ("pacman", "sudo pacman -S --noconfirm --needed", "sudo pacman -Sy"),
    ("zypper", "sudo zypper --non-interactive install", "sudo zypper refresh"),
    ("apk", "sudo apk add", "sudo apk update"),
    ("xbps-install", "sudo xbps-install -y", "sudo xbps-install -S"),
    ("emerge", "sudo emerge --ask=n", "sudo emerge --sync"),
    ("eopkg", "sudo eopkg install -y", "sudo eopkg update-repo"),
    ("nix-env", "nix-env -iA", "nix-channel --update"),
]

TERMINALS = ["x-terminal-emulator", "gnome-terminal", "konsole", "xfce4-terminal", "kitty",
             "alacritty", "tilix", "mate-terminal", "lxterminal", "terminator", "foot",
             "wezterm", "xterm", "st", "urxvt"]


# ───────────────────────── окружение ─────────────────────────
def clean_env(extra=None):
    """Окружение для дочерних процессов.

    * Убираем следы виртуального окружения самого AI-Coder, иначе `pip install`
      ассистента улетит в venv приложения, а не туда, куда ожидает пользователь.
    * Дополняем PATH типичными каталогами.
    * Отключаем интерактивность (пейджеры, запросы пароля git, apt-диалоги).
    """
    env = dict(os.environ)
    venv = env.pop("VIRTUAL_ENV", None)
    for var in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV_PROMPT", "PYTHONSTARTUP"):
        env.pop(var, None)

    parts = [p for p in env.get("PATH", "").split(os.pathsep) if p]
    bad_prefixes = [os.path.join(APP_DIR, ".venv")]
    if venv:
        bad_prefixes.append(venv)
    if sys.prefix != getattr(sys, "base_prefix", sys.prefix):
        bad_prefixes.append(sys.prefix)
    parts = [p for p in parts if not any(p.startswith(b) for b in bad_prefixes)]
    for d in EXTRA_PATH_DIRS:
        d = os.path.expanduser(d)
        if os.path.isdir(d) and d not in parts:
            parts.append(d)
    env["PATH"] = os.pathsep.join(parts)

    env.setdefault("LANG", "C.UTF-8")
    env.update({
        "DEBIAN_FRONTEND": "noninteractive",
        "GIT_TERMINAL_PROMPT": "0",
        "GIT_PAGER": "cat", "PAGER": "cat", "SYSTEMD_PAGER": "", "MANPAGER": "cat",
        "TERM": "dumb", "NO_COLOR": "1",
        "PYTHONUNBUFFERED": "1", "PYTHONIOENCODING": "utf-8",
        "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PIP_NO_INPUT": "1",
        "NPM_CONFIG_UPDATE_NOTIFIER": "false", "NPM_CONFIG_FUND": "false", "NPM_CONFIG_YES": "true",
        "HOMEBREW_NO_AUTO_UPDATE": "1",
    })
    if extra:
        env.update(extra)
    return env


def which(tool, env=None):
    env = env or clean_env()
    return shutil.which(tool, path=env.get("PATH"))


# ───────────────────────── мелкие пробы ─────────────────────────
def _read_os_release():
    data = {}
    for path in ("/etc/os-release", "/usr/lib/os-release"):
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    line = line.strip()
                    if "=" in line and not line.startswith("#"):
                        k, v = line.split("=", 1)
                        data[k] = v.strip().strip('"').strip("'")
            if data:
                break
        except OSError:
            continue
    return data


def _run_probe(argv, env, timeout=5):
    """Возвращает (статус, первая строка вывода). статус: ok | broken | timeout."""
    try:
        p = subprocess.run(argv, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=timeout, text=True, errors="replace")
        line = (p.stdout or "").strip().splitlines()
        first = line[0][:120] if line else ""
        return ("ok" if p.returncode == 0 else "broken"), first
    except subprocess.TimeoutExpired:
        return "timeout", ""
    except Exception as e:  # битый шебанг, нет прав на исполнение и т.п.
        return "broken", str(e)[:120]


def _check_tool(tool, env):
    path = which(tool, env)
    if not path:
        return {"present": False, "status": "missing", "path": "", "version": ""}
    status, first = _run_probe([path] + TOOL_CHECKS[tool], env)
    return {"present": True, "status": status, "path": path, "version": first}


def _check_dns(host="github.com", timeout=4):
    box = {}

    def work():
        try:
            box["ip"] = socket.getaddrinfo(host, 443, proto=socket.IPPROTO_TCP)[0][4][0]
        except Exception as e:
            box["err"] = str(e)
    t = threading.Thread(target=work, daemon=True)
    t.start()
    t.join(timeout)
    return box.get("ip"), box.get("err", "таймаут DNS" if "ip" not in box else "")


def _check_tcp(host, port=443, timeout=4):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _check_network():
    ip, err = _check_dns("github.com")
    res = {"dns": bool(ip), "dns_error": err if not ip else "", "https": False, "proxy": ""}
    if ip:
        res["https"] = _check_tcp(ip, 443)
    for var in ("https_proxy", "HTTPS_PROXY", "http_proxy", "HTTP_PROXY", "all_proxy", "ALL_PROXY"):
        if os.environ.get(var):
            res["proxy"] = os.environ[var]
            break
    # Прямой DNS может не работать, если весь трафик идёт через прокси — это нормально.
    if not res["https"] and res["proxy"]:
        try:
            from urllib.parse import urlparse
            pr = urlparse(res["proxy"] if "//" in res["proxy"] else "//" + res["proxy"])
            if pr.hostname and _check_tcp(pr.hostname, pr.port or 3128):
                res.update(dns=True, https=True, via_proxy=True, dns_error="")
        except Exception:
            pass
    return res


def _check_sudo(env):
    if os.geteuid() == 0:
        return "root"
    if not which("sudo", env):
        return "doas" if which("doas", env) else "нет"
    try:
        p = subprocess.run(["sudo", "-n", "true"], env=env, stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
        return "без пароля" if p.returncode == 0 else "нужен пароль"
    except Exception:
        return "недоступен"


def _check_python_env(env):
    """Системный python3 (не тот, на котором запущен GUI): venv, pip, PEP 668."""
    py = which("python3", env)
    res = {"venv": False, "ensurepip": False, "externally_managed": False}
    if not py:
        return res
    code = (
        "import importlib.util as u, os, sysconfig;"
        "print(int(u.find_spec('venv') is not None), int(u.find_spec('ensurepip') is not None),"
        " int(os.path.exists(os.path.join(sysconfig.get_path('stdlib'), 'EXTERNALLY-MANAGED'))))"
    )
    try:
        out = subprocess.run([py, "-I", "-c", code], env=env, stdin=subprocess.DEVNULL,
                             capture_output=True, text=True, timeout=8).stdout.split()
        res = {"venv": out[0] == "1", "ensurepip": out[1] == "1", "externally_managed": out[2] == "1"}
    except Exception:
        pass
    return res


def detect_package_manager(os_release, env):
    found = [(b, i, u) for b, i, u in PACKAGE_MANAGERS if which(b, env)]
    ids = " ".join([os_release.get("ID", ""), os_release.get("ID_LIKE", "")]).lower()
    expected = None
    if any(x in ids for x in ("debian", "ubuntu", "mint")):
        expected = "apt-get"
    elif any(x in ids for x in ("fedora", "rhel", "centos")):
        expected = "dnf"
    elif any(x in ids for x in ("arch", "manjaro")):
        expected = "pacman"
    elif "suse" in ids:
        expected = "zypper"
    elif "alpine" in ids:
        expected = "apk"
    elif "void" in ids:
        expected = "xbps-install"
    elif "gentoo" in ids:
        expected = "emerge"
    note = ""
    if found:
        main = found[0]
        # если os-release указывает на один менеджер, а реально стоит другой — верим реальности
        if expected and expected != main[0] and not any(f[0] == expected for f in found):
            note = (f"os-release говорит про {expected}, но его нет; реально найден {main[0]} "
                    f"(дистрибутив нестандартный — доверяй найденному).")
        elif expected and any(f[0] == expected for f in found):
            main = [f for f in found if f[0] == expected][0]
        return {"name": main[0], "install": main[1], "update": main[2], "all": [f[0] for f in found], "note": note}
    return {"name": "", "install": "", "update": "", "all": [],
            "note": "Пакетный менеджер не найден — установка системных пакетов может быть невозможна."}


# ───────────────────────── главный пробник ─────────────────────────
def probe(workspace=None, check_network=True):
    """Собирает отчёт о системе. Все проверки с таймаутами, выполняются параллельно."""
    started = time.time()
    env = clean_env()
    os_release = _read_os_release()
    info = {
        "os_release": os_release,
        "distro": os_release.get("PRETTY_NAME") or os_release.get("NAME") or "неизвестный дистрибутив",
        "distro_id": os_release.get("ID", "?"),
        "distro_like": os_release.get("ID_LIKE", ""),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "user": os.environ.get("USER") or os.environ.get("LOGNAME") or str(os.getuid()),
        "home": os.path.expanduser("~"),
        "is_root": os.geteuid() == 0,
        "shell": os.environ.get("SHELL", ""),
        "lang": env.get("LANG", ""),
        "desktop": os.environ.get("XDG_CURRENT_DESKTOP", ""),
        "session": os.environ.get("XDG_SESSION_TYPE", ""),
        "display": bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")),
        "systemd": os.path.isdir("/run/systemd/system"),
        "container": os.path.exists("/.dockerenv") or os.path.exists("/run/.containerenv"),
        "workspace": workspace or "",
    }
    if not os_release:
        info["distro_note"] = "os-release отсутствует — дистрибутив определить нельзя, смотри по найденным утилитам."

    with ThreadPoolExecutor(max_workers=12) as pool:
        tool_futs = {t: pool.submit(_check_tool, t, env) for t in TOOL_CHECKS}
        net_fut = pool.submit(_check_network) if check_network else None
        sudo_fut = pool.submit(_check_sudo, env)
        py_fut = pool.submit(_check_python_env, env)
        info["tools"] = {t: f.result() for t, f in tool_futs.items()}
        info["network"] = net_fut.result() if net_fut else {"dns": None, "https": None, "proxy": "", "dns_error": ""}
        info["sudo"] = sudo_fut.result()
        info["python_env"] = py_fut.result()

    info["extra_tools"] = {t: bool(which(t, env)) for t in TOOL_PRESENCE}
    info["pkg"] = detect_package_manager(os_release, env)
    info["terminals"] = [t for t in TERMINALS if which(t, env)]

    if workspace:
        try:
            os.makedirs(workspace, exist_ok=True)
            info["workspace_writable"] = os.access(workspace, os.W_OK)
            info["disk_free_gb"] = round(shutil.disk_usage(workspace).free / 2**30, 1)
        except OSError:
            info["workspace_writable"] = False
            info["disk_free_gb"] = None
    info["probe_seconds"] = round(time.time() - started, 1)
    return info


# ───────────────────────── «выученные» особенности ─────────────────────────
def load_learned():
    try:
        with open(LEARNED_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_learned(data):
    try:
        with open(LEARNED_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError:
        pass


def remember(key, value=True):
    data = load_learned()
    if data.get(key) != value:
        data[key] = value
        save_learned(data)


LEARNED_TEXT = {
    "git_http1": "git по HTTP/2 в этой системе рвётся — использовать `git -c http.version=HTTP/1.1` (уже подставляется автоматически).",
    "git_shallow": "полный git clone нестабилен — клонировать с `--depth 1`.",
    "git_tarball": "git clone не работает совсем — репозитории с GitHub скачиваются архивом через curl/wget.",
    "pip_needs_venv": "системный pip запрещён (PEP 668) — ставить пакеты только в venv.",
}


# ───────────────────────── форматирование ─────────────────────────
def _tool_line(info, name):
    t = info["tools"].get(name, {})
    if not t.get("present"):
        return f"{name}: НЕТ"
    if t.get("status") != "ok":
        return f"{name}: СЛОМАН/не отвечает ({t.get('version') or t.get('status')})"
    return f"{name}: {t.get('version') or 'ok'}"


def _short_version(text):
    import re
    m = re.search(r"\d+(?:\.\d+)+\S*", text or "")
    return m.group(0)[:20] if m else (text or "")[:20]


def format_for_prompt(info, learned=None):
    """Краткий отчёт для системного промпта ассистента."""
    learned = learned if learned is not None else load_learned()
    t = info["tools"]
    ok = [n for n, v in t.items() if v["present"] and v["status"] == "ok"]
    missing = [n for n, v in t.items() if not v["present"]]
    broken = [n for n, v in t.items() if v["present"] and v["status"] != "ok"]
    pkg = info["pkg"]
    net = info["network"]
    lines = [
        f"Дистрибутив: {info['distro']} (ID={info['distro_id']}, ID_LIKE={info['distro_like'] or '-'}), ядро {info['kernel']}, {info['arch']}.",
        "Это НЕОРИГИНАЛЬНЫЙ/модифицированный Linux: не полагайся на стандартное поведение, проверяй результат каждой команды.",
        f"Пользователь: {info['user']}{' (root)' if info['is_root'] else ''}, HOME={info['home']}, shell={info['shell'] or 'bash'}.",
        f"Пакетный менеджер: {pkg['name'] or 'НЕ НАЙДЕН'}"
        + (f"; установка: `{pkg['install']} <пакет>`; обновление индекса: `{pkg['update']}`" if pkg["name"] else "")
        + (f". ВНИМАНИЕ: {pkg['note']}" if pkg.get("note") else ""),
        f"sudo: {info['sudo']}. systemd: {'да' if info['systemd'] else 'нет (не используй systemctl)'}."
        + (" Работаем внутри контейнера." if info.get("container") else ""),
        f"Рабочая папка: {info.get('workspace') or '?'}"
        + ("" if info.get("workspace_writable", True) else " (НЕТ прав на запись!)")
        + (f", свободно {info['disk_free_gb']} ГБ" if info.get("disk_free_gb") is not None else ""),
        "Работают: " + (", ".join(f"{n} [{_short_version(t[n]['version'])}]" if t[n]["version"] else n for n in ok) or "-"),
    ]
    if broken:
        lines.append("СЛОМАНЫ (есть, но не запускаются): " + ", ".join(broken))
    if missing:
        lines.append("Отсутствуют: " + ", ".join(missing))
    extras = info.get("extra_tools", {})
    lines.append("Прочее: " + ", ".join(f"{k}{'+' if v else '-'}" for k, v in extras.items()))
    if net.get("dns") is None:
        pass
    elif not net["dns"]:
        lines.append(f"СЕТЬ: DNS не работает ({net['dns_error'][:60]}). Скачивание и git clone, скорее всего, не сработают.")
    elif not net["https"]:
        lines.append("СЕТЬ: DNS работает, но HTTPS-соединение с github.com не проходит (фаервол/прокси?).")
    else:
        lines.append("СЕТЬ: работает." + (f" Трафик идёт через прокси {net['proxy']}." if net["proxy"] else ""))
    pe = info.get("python_env", {})
    if pe.get("externally_managed"):
        lines.append("Системный Python помечен EXTERNALLY-MANAGED: `pip install` напрямую упадёт — используй "
                     "`python3 -m venv .venv && . .venv/bin/activate` (venv " + ("доступен" if pe.get("venv") else "НЕ установлен") + ").")
    elif pe and not pe.get("venv"):
        lines.append("Модуль venv у python3 недоступен — для venv сначала поставь пакет (python3-venv).")
    for key, text in LEARNED_TEXT.items():
        if learned.get(key):
            lines.append("Выучено: " + text)
    return "\n".join(lines)


def format_for_user(info):
    """Читаемый отчёт для окна «Диагностика»."""
    t = info["tools"]
    net = info["network"]

    def mark(ok):
        return "[ OK ]" if ok else "[FAIL]"

    out = [
        f"Система:       {info['distro']}",
        f"Ядро / архит.: {info['kernel']} / {info['arch']}",
        f"Пользователь:  {info['user']}{' (root)' if info['is_root'] else ''}   sudo: {info['sudo']}",
        f"Рабочий стол:  {info['desktop'] or '—'} ({info['session'] or '—'})   systemd: {'да' if info['systemd'] else 'нет'}",
        f"Пакетный мен.: {info['pkg']['name'] or 'не найден'}"
        + (f"   (также: {', '.join(info['pkg']['all'][1:])})" if len(info["pkg"]["all"]) > 1 else ""),
    ]
    if info["pkg"].get("note"):
        out.append(f"               ! {info['pkg']['note']}")
    if info.get("distro_note"):
        out.append(f"               ! {info['distro_note']}")
    out.append("")
    out.append("Утилиты:")
    for name, v in t.items():
        if not v["present"]:
            out.append(f"  [ —  ] {name:<8} не установлен")
        elif v["status"] != "ok":
            out.append(f"  [FAIL] {name:<8} есть, но не работает: {v['version'] or v['status']}")
        else:
            out.append(f"  [ OK ] {name:<8} {v['version'][:70]}")
    out.append("")
    out.append("Сеть:")
    if net["dns"] is None:
        out.append("  проверка пропущена")
    else:
        out.append(f"  {mark(net['dns'])} DNS (github.com)" + (f" — {net['dns_error'][:70]}" if not net["dns"] else ""))
        out.append(f"  {mark(net['https'])} HTTPS-соединение")
        if net["proxy"]:
            out.append(f"  прокси: {net['proxy']}")
    pe = info.get("python_env", {})
    out.append("")
    out.append("Python (системный python3):")
    out.append(f"  venv: {'да' if pe.get('venv') else 'нет'}   ensurepip: {'да' if pe.get('ensurepip') else 'нет'}   "
               f"EXTERNALLY-MANAGED: {'да — pip только в venv' if pe.get('externally_managed') else 'нет'}")
    out.append("")
    out.append(f"Рабочая папка: {info.get('workspace') or '—'}  "
               + ("запись разрешена" if info.get("workspace_writable", True) else "НЕТ ПРАВ НА ЗАПИСЬ")
               + (f", свободно {info['disk_free_gb']} ГБ" if info.get("disk_free_gb") is not None else ""))
    out.append(f"Терминалы: {', '.join(info['terminals']) or 'не найдены'}")
    learned = load_learned()
    active = [LEARNED_TEXT[k] for k in LEARNED_TEXT if learned.get(k)]
    if active:
        out.append("")
        out.append("Выучено о вашей системе:")
        out.extend("  • " + a for a in active)
    out.append(f"\n(проверка заняла {info['probe_seconds']} с)")
    return "\n".join(out)


if __name__ == "__main__":
    data = probe(os.getcwd())
    print(format_for_user(data))
    print("\n--- ДЛЯ ПРОМПТА ---\n")
    print(format_for_prompt(data))
