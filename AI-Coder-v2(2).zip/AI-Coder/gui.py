import os
import platform
import queue
import re
import shutil
import subprocess
import threading
import tkinter as tk
import webbrowser
from tkinter import filedialog, messagebox, ttk

import customtkinter as ctk

import theme as T
from core import images as imgs
from core.privileges import is_admin
from core.workspace import BACKUP_DIR
from editor import CodeEditorModule
from i18n import _
from settings_ui import open_settings
from texts import LICENSE_TEXT

MODES = [("agent", "🤖 Агент"), ("query", "💬 ASK"), ("assistant", "🛠️ Ассистент"), ("dcoder", "🎯 D-Coder")]
FENCE = re.compile(r"^\s*(`{3,})(.*)$")
FILE_INFO = re.compile(r"^(?:[\w+#.-]+\s+)?(?:file|filename|path):\s*(.+)$", re.IGNORECASE)
DEVICES = [("gpu", "GPU"), ("auto", "Авто"), ("cpu", "CPU")]


class LoadingSplash(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.overrideredirect(True)
        self.attributes("-topmost", True)
        self.configure(fg_color=T.BG)
        w, h = 460, 240
        self.geometry(f"{w}x{h}+{(self.winfo_screenwidth() - w) // 2}+{(self.winfo_screenheight() - h) // 2}")
        box = ctk.CTkFrame(self, fg_color=T.PANEL, border_width=1, border_color=T.LINE, corner_radius=16)
        box.pack(fill="both", expand=True, padx=2, pady=2)
        ctk.CTkLabel(box, text="⚡ AI-CODER", font=(T.MONO, 28, "bold"), text_color=T.OK).pack(pady=(42, 2))
        ctk.CTkLabel(box, text=_("Автономная среда разработки"), font=(T.UI, 12), text_color=T.MUTE).pack()
        self.status = ctk.CTkLabel(box, text=_("Запуск..."), font=(T.UI, 12), text_color=T.ACC)
        self.status.pack(pady=(24, 6))
        self.bar = ctk.CTkProgressBar(box, width=320, mode="indeterminate", progress_color=T.ACC)
        self.bar.pack()
        self.bar.start()

    def set(self, text):
        if self.winfo_exists():
            self.status.configure(text=text)


class App(ctk.CTk):
    def __init__(self, core):
        super().__init__()
        self.withdraw()
        T.init_fonts(self)
        self.cfg, self.llm, self.store, self.ws = core.cfg, core.llm, core.store, core.ws
        self.backup, self.agent, self.server = core.backup, core.agent, core.server
        self.TAB_CHAT, self.TAB_EDITOR = _("💬 Терминал ИИ"), _("📝 Редактор кода")

        self.title("AI-Coder" + (" [" + _("администратор") + "]" if is_admin() else ""))
        self.geometry("1440x900")
        self.minsize(1040, 660)
        self.configure(fg_color=T.BG)
        try:
            icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icon.png")
            if os.path.exists(icon):
                self.iconphoto(True, tk.PhotoImage(file=icon))
        except tk.TclError:
            pass

        self.current_chat_id = None
        self.current_open_file = None
        self.models = []
        self._retry_job = None
        self._q = queue.Queue()
        self._partial, self._fence, self._depth, self._in_user = "", False, 0, False
        self._tree_paths, self._tree_job = {}, None
        self.attached = []            # вложенные скриншоты: {'name', 'b64'}
        self.agent.bus.subscribe(self._q.put)

        self._init_tree_style()
        self._build_sidebar()
        self._build_main()

        self.refresh_chat_list()
        self.refresh_tree()
        cid = self.store.first_id() or self.store.new()
        self.switch_chat(cid)

        self.splash = LoadingSplash(self)
        threading.Thread(target=self._startup, daemon=True).start()
        self.after(40, self._pump)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    # ------------------------------------------------------------------ запуск
    def _startup(self):
        self._q.put({"t": "splash", "text": _("🔍 Ищу Ollama...")})
        self.llm.ensure_server()
        names, err = self.llm.list_models()
        self._q.put({"t": "ready"})
        self._q.put({"t": "models", "models": names, "err": err, "announce": False})
        self.agent.start_monitor()
        if names:
            if self.cfg.get("model") not in names:
                self.cfg.set("model", names[0])
            ok, werr = self.llm.warmup()         # модель заранее в видеопамяти, первый ответ без задержки
            self._q.put({"t": "toast", "text": _("🧠 Модель загружена") if ok else f"⚠️ {werr}"})

    def _on_ready(self):
        try:
            self.splash.destroy()
        except tk.TclError:
            pass
        self.deiconify()
        if self.cfg.get("serve_network"):
            self.apply_network()
        else:
            self.update_net_chip()
        if self.store.first_run:
            self.after(600, self.open_license_window)
            self.store.first_run = False

    def refresh_models(self, announce=False):
        """Перечитать список установленных моделей Ollama (в фоне)."""
        def work():
            names, err = self.llm.list_models()
            self._q.put({"t": "models", "models": names, "err": err, "announce": announce})
        threading.Thread(target=work, daemon=True).start()

    def _on_models(self, ev):
        names, err = ev["models"], ev["err"]
        if names:
            self.models = names
            self.model_menu.configure(values=names)
            if self._retry_job is not None:
                self.after_cancel(self._retry_job)
                self._retry_job = None
            if self.cfg.get("model") not in names:
                self.cfg.set("model", names[0])
                self.set_toast("ℹ️ " + _("Выбранной модели нет среди установленных, взята") + f" {names[0]}", 9000)
            elif ev["announce"]:
                self.set_toast(f"✅ {_('Найдено моделей')}: {len(names)}")
            self.model_menu.set(self.cfg.get("model"))
            return
        self.set_toast("⚠️ " + (err or _("Ollama работает, но моделей нет. Установите: ollama pull qwen2.5-coder:7b")), 15000)
        if self._retry_job is None:               # пока список пуст, пробуем снова каждые 8 секунд
            self._retry_job = self.after(8000, self._retry_models)

    def _retry_models(self):
        self._retry_job = None
        self.refresh_models()

    def on_close(self):
        self.server.stop()
        self.store.flush()
        self.cfg.save()
        self.destroy()

    # ------------------------------------------------------------------ события из ядра
    def _pump(self):
        events = []
        try:
            while len(events) < 400:
                events.append(self._q.get_nowait())
        except queue.Empty:
            pass
        merged = []
        for ev in events:       # склеиваем подряд идущие куски текста, чтобы перерисовывать раз в 40 мс
            if merged and ev.get("t") == "append" and merged[-1].get("t") == "append" and merged[-1]["cid"] == ev["cid"]:
                merged[-1]["text"] += ev["text"]
            else:
                merged.append(dict(ev))
        for ev in merged:
            try:
                self._handle(ev)
            except tk.TclError:
                pass
        self.after(40, self._pump)

    def _handle(self, ev):
        t = ev.get("t")
        if t == "append":
            if ev["cid"] == self.current_chat_id:
                self.chat_write(ev["text"])
        elif t == "state":
            self.update_state(ev)
        elif t == "stats":
            self.lbl_tps.configure(text=f"⚡ {ev['tps']} ток/с")
        elif t == "gpu":
            self.update_gpu_chip(ev["data"])
        elif t == "chats":
            self.refresh_chat_list()
        elif t == "tree":
            self.schedule_tree_refresh()
        elif t == "cmd_clear":
            self.cmd_output.delete("1.0", "end")
            self.terminal_frame.grid()
        elif t == "cmd":
            self.cmd_output.insert("end", ev["text"])
            self.cmd_output.see("end")
        elif t == "splash":
            self.splash.set(ev["text"])
        elif t == "ready":
            self._on_ready()
        elif t == "models":
            self._on_models(ev)
        elif t == "toast":
            self.set_toast(ev["text"])

    def set_toast(self, text, ms=6000):
        self.lbl_state.configure(text=text, text_color=T.WARN)
        self.after(ms, lambda: self.update_state(self.agent.snapshot()))

    # ------------------------------------------------------------------ боковая панель
    def _init_tree_style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("Treeview", background=T.PANEL2, fieldbackground=T.PANEL2, foreground=T.FG,
                     borderwidth=0, rowheight=26, font=(T.UI, 10))
        st.map("Treeview", background=[("selected", T.ACC)], foreground=[("selected", "#ffffff")])
        st.configure("Vertical.TScrollbar", background=T.LINE, troughcolor=T.PANEL2, borderwidth=0, arrowsize=12)

    def _build_sidebar(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        sb = ctk.CTkFrame(self, width=290, corner_radius=0, fg_color=T.PANEL)
        sb.grid(row=0, column=0, sticky="nsew")
        sb.grid_propagate(False)
        sb.grid_columnconfigure(0, weight=1)
        sb.grid_rowconfigure(3, weight=2)
        sb.grid_rowconfigure(5, weight=3)
        self.sidebar = sb

        brand = ctk.CTkFrame(sb, fg_color="transparent")
        brand.grid(row=0, column=0, sticky="ew", padx=14, pady=(16, 6))
        ctk.CTkLabel(brand, text="⚡ AI-Coder", font=(T.UI, 20, "bold")).pack(anchor="w")
        ctk.CTkLabel(brand, text=_("Локальный ИИ на вашей видеокарте"), font=(T.UI, 11), text_color=T.MUTE).pack(anchor="w")

        ctk.CTkButton(sb, text=_("➕ Новая сессия"), height=36, fg_color=T.ACC, hover_color=T.ACC_HOVER,
                      font=(T.UI, 13, "bold"), command=lambda: self.new_chat()).grid(row=1, column=0, sticky="ew", padx=12, pady=(8, 4))
        ctk.CTkLabel(sb, text=_("История сессий:").upper(), font=(T.UI, 10, "bold"), text_color=T.MUTE,
                     anchor="w").grid(row=2, column=0, sticky="w", padx=14, pady=(10, 2))
        self.chats_frame = ctk.CTkScrollableFrame(sb, fg_color="transparent", height=120)
        self.chats_frame.grid(row=3, column=0, sticky="nsew", padx=6)

        head = ctk.CTkFrame(sb, fg_color="transparent")
        head.grid(row=4, column=0, sticky="ew", padx=14, pady=(8, 2))
        ctk.CTkLabel(head, text=_("Файлы проекта:").upper(), font=(T.UI, 10, "bold"), text_color=T.MUTE).pack(side="left")
        ctk.CTkButton(head, text="🔄", width=28, height=22, fg_color="transparent", hover_color=T.PANEL2,
                      command=self.refresh_tree).pack(side="right")

        tf = ctk.CTkFrame(sb, fg_color=T.PANEL2, corner_radius=8)
        tf.grid(row=5, column=0, sticky="nsew", padx=12, pady=(0, 6))
        tf.grid_rowconfigure(0, weight=1)
        tf.grid_columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(tf, show="tree", selectmode="browse")
        self.tree.grid(row=0, column=0, sticky="nsew", padx=(4, 0), pady=4)
        sc = ttk.Scrollbar(tf, orient="vertical", command=self.tree.yview)
        sc.grid(row=0, column=1, sticky="ns", pady=4)
        self.tree.configure(yscrollcommand=sc.set)
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        self._setup_context_menu()

        ws = ctk.CTkFrame(sb, fg_color="transparent")
        ws.grid(row=6, column=0, sticky="ew", padx=12, pady=(0, 6))
        ws.grid_columnconfigure(0, weight=1)
        self.lbl_ws = ctk.CTkLabel(ws, text="", anchor="w", font=(T.UI, 11), text_color=T.MUTE)
        self.lbl_ws.grid(row=0, column=0, sticky="ew")
        ctk.CTkButton(ws, text=_("📁 Папка"), width=70, height=26, fg_color=T.PANEL2, hover_color=T.LINE,
                      command=self.select_workspace).grid(row=0, column=1)
        self.lbl_ws.configure(text="📂 " + self.ws.name)

        bt = ctk.CTkFrame(sb, fg_color="transparent")
        bt.grid(row=7, column=0, sticky="ew", padx=12, pady=(0, 12))
        bt.grid_columnconfigure((0, 1), weight=1)
        buttons = [
            (_("⚙️ Настройки"), T.ACC, lambda: open_settings(self)), (_("💻 Терминал"), "#2d3748", self.open_cmd),
            (_("⏪ Откат кода"), "#8f2d2d", self.rollback_wrapper), (_("🌐 Web-ИИ"), "#5b21b6", self.open_mini_browser),
            (_("❓ Помощь"), "#8a5a2b", self.open_help_window), (_("📜 О Проекте"), "#2d3748", self.open_license_window),
        ]
        for i, (txt, col, cmd) in enumerate(buttons):
            ctk.CTkButton(bt, text=txt, height=30, fg_color=col, hover_color=T.LINE, font=(T.UI, 12),
                          command=cmd).grid(row=i // 2, column=i % 2, padx=3, pady=3, sticky="ew")

    # ------------------------------------------------------------------ центральная часть
    def _build_main(self):
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.grid(row=0, column=1, sticky="nsew", padx=(10, 10), pady=10)
        main.grid_columnconfigure(0, weight=1)
        main.grid_rowconfigure(1, weight=1)

        # шапка: название чата + режимы
        head = ctk.CTkFrame(main, fg_color="transparent")
        head.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        head.grid_columnconfigure(0, weight=1)
        self.lbl_title = ctk.CTkLabel(head, text="", font=(T.UI, 17, "bold"), anchor="w")
        self.lbl_title.grid(row=0, column=0, sticky="ew", padx=4)
        self.mode_seg = ctk.CTkSegmentedButton(head, values=[_(m[1]) for m in MODES], command=self.on_mode_change,
                                               selected_color=T.ACC, selected_hover_color=T.ACC_HOVER,
                                               unselected_color=T.PANEL2, fg_color=T.PANEL2, font=(T.UI, 12, "bold"))
        self.mode_seg.grid(row=0, column=1, sticky="e")

        self.tabview = ctk.CTkTabview(main, fg_color=T.PANEL, corner_radius=12,
                                      segmented_button_selected_color=T.ACC,
                                      segmented_button_selected_hover_color=T.ACC_HOVER,
                                      segmented_button_unselected_color=T.PANEL2)
        self.tabview.grid(row=1, column=0, sticky="nsew")
        self.tab_chat = self.tabview.add(self.TAB_CHAT)
        self.tab_editor = self.tabview.add(self.TAB_EDITOR)
        self._build_chat(self.tab_chat)
        self.editor = CodeEditorModule(self.tab_editor, self)

        # статус-бар
        bar = ctk.CTkFrame(main, fg_color=T.PANEL, corner_radius=10, height=40)
        bar.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        bar.grid_columnconfigure(1, weight=1)
        self.lbl_state = ctk.CTkLabel(bar, text="● " + _("Готов"), font=(T.UI, 12), text_color=T.OK)
        self.lbl_state.grid(row=0, column=0, padx=12, pady=7)
        self.lbl_tps = ctk.CTkLabel(bar, text="", font=(T.UI, 12), text_color=T.MUTE)
        self.lbl_tps.grid(row=0, column=1, sticky="w")
        mf = ctk.CTkFrame(bar, fg_color="transparent")
        mf.grid(row=0, column=2, padx=4)
        self.model_menu = ctk.CTkComboBox(mf, values=[self.cfg.get("model")], width=230, height=26, fg_color=T.PANEL2,
                                          border_color=T.LINE, button_color=T.LINE, command=self.on_model)
        self.model_menu.set(self.cfg.get("model"))
        self.model_menu.pack(side="left")
        self.model_menu.bind("<Return>", lambda e: self.on_model(self.model_menu.get()))
        ctk.CTkButton(mf, text="🔄", width=28, height=26, fg_color=T.PANEL2, hover_color=T.LINE,
                      command=lambda: self.refresh_models(True)).pack(side="left", padx=(4, 0))
        self.dev_seg = ctk.CTkSegmentedButton(bar, values=[_(d[1]) for d in DEVICES], command=self.on_device,
                                              height=26, selected_color=T.OK, selected_hover_color="#16a34a",
                                              unselected_color=T.PANEL2, fg_color=T.PANEL2, font=(T.UI, 11, "bold"))
        self.dev_seg.set(_(dict(DEVICES)[self.cfg.get("device")]))
        self.dev_seg.grid(row=0, column=3, padx=4)
        self.chip_gpu = ctk.CTkButton(bar, text="GPU …", height=26, font=(T.UI, 11, "bold"), text_color=T.MUTE,
                                      fg_color=T.PANEL2, hover_color=T.LINE, corner_radius=8,
                                      command=lambda: open_settings(self, "gpu"))
        self.chip_gpu.grid(row=0, column=4, padx=4)
        self.chip_net = ctk.CTkButton(bar, text="📱 …", height=26, font=(T.UI, 11, "bold"), text_color=T.MUTE,
                                      fg_color=T.PANEL2, hover_color=T.LINE, corner_radius=8,
                                      command=lambda: open_settings(self, "net"))
        self.chip_net.grid(row=0, column=5, padx=(4, 12))

    def _build_chat(self, tab):
        tab.grid_rowconfigure(0, weight=1)
        tab.grid_columnconfigure(0, weight=1)
        box = ctk.CTkFrame(tab, fg_color=T.BG, corner_radius=10)
        box.grid(row=0, column=0, sticky="nsew", pady=(0, 6))
        box.grid_rowconfigure(0, weight=1)
        box.grid_columnconfigure(0, weight=1)
        self.chat = tk.Text(box, bg=T.BG, fg=T.FG, font=(T.UI, 12), wrap="word", bd=0, highlightthickness=0,
                            padx=16, pady=12, state="disabled", cursor="arrow", spacing1=2, spacing3=2,
                            selectbackground="#264f78", insertbackground=T.FG)
        self.chat.grid(row=0, column=0, sticky="nsew")
        sc = ctk.CTkScrollbar(box, command=self.chat.yview)
        sc.grid(row=0, column=1, sticky="ns", pady=4)
        self.chat.configure(yscrollcommand=sc.set)
        b = (T.UI, 12, "bold")
        self.chat.tag_configure("ai", foreground=T.FG)
        self.chat.tag_configure("user", background=T.USER_BG, foreground="#dbe7ff", lmargin1=10, lmargin2=10,
                                rmargin=10, spacing1=3, spacing3=3)
        self.chat.tag_configure("step", foreground="#7cb7ff", font=b, spacing1=12)
        self.chat.tag_configure("plan", foreground="#c4a7ff", font=b)
        self.chat.tag_configure("ok", foreground=T.OK)
        self.chat.tag_configure("bad", foreground=T.BAD)
        self.chat.tag_configure("warn", foreground=T.WARN)
        self.chat.tag_configure("sys", foreground=T.MUTE)
        self.chat.tag_configure("codehead", background="#111827", foreground=T.MUTE, font=(T.MONO, 10),
                                lmargin1=12, lmargin2=12, spacing1=8)
        self.chat.tag_configure("code", background=T.CODE_BG, foreground="#d6deeb", font=(T.MONO, 11),
                                lmargin1=22, lmargin2=22, rmargin=10)
        self.chat.tag_raise("sel")
        self.chat.mark_set("live_start", "end-1c")
        self.chat.mark_gravity("live_start", "left")
        self.chat.bind("<Control-c>", lambda e: self._copy_selection())
        self.chat.bind("<Button-1>", lambda e: self.chat.focus_set())

        # терминал (появляется, когда ИИ выполняет команды)
        self.terminal_frame = ctk.CTkFrame(tab, fg_color=T.BG, corner_radius=10)
        self.terminal_frame.grid(row=1, column=0, sticky="ew", pady=(0, 6))
        ctk.CTkLabel(self.terminal_frame, text=_("💻 Живой вывод командной строки"), font=(T.UI, 11, "bold"),
                     text_color=T.MUTE).pack(anchor="nw", padx=10, pady=(4, 0))
        self.cmd_output = ctk.CTkTextbox(self.terminal_frame, height=100, font=(T.MONO, 11), fg_color=T.CODE_BG,
                                         text_color="#5eead4")
        self.cmd_output.pack(fill="both", expand=True, padx=8, pady=(2, 8))
        self.terminal_frame.grid_remove()

        # ввод
        ctl = ctk.CTkFrame(tab, fg_color="transparent")
        ctl.grid(row=2, column=0, sticky="ew")
        ctl.grid_columnconfigure(0, weight=1)
        self.inputs = ctk.CTkFrame(ctl, fg_color="transparent", height=0)
        self.inputs.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.inputs.grid_columnconfigure(0, weight=1)
        self.lbl_prompt_1 = ctk.CTkLabel(self.inputs, text=_("Запрос:"), height=16, font=(T.UI, 11, "bold"), text_color=T.MUTE)
        self.lbl_prompt_1.pack(anchor="w", pady=(0, 2))
        self.prompt_entry = ctk.CTkTextbox(self.inputs, height=96, font=(T.UI, 13), wrap="word", fg_color=T.BG,
                                           border_width=1, border_color=T.LINE)
        self.prompt_entry.pack(fill="x")
        self.lbl_prompt_2 = ctk.CTkLabel(self.inputs, text=_("2. Содержимое файлов (какой код куда):"), height=16,
                                         font=(T.UI, 11, "bold"), text_color=T.MUTE)
        self.prompt_entry_2 = ctk.CTkTextbox(self.inputs, height=230, font=(T.MONO, 12), wrap="word", fg_color=T.BG,
                                             border_width=1, border_color=T.LINE)
        self.attach_bar = ctk.CTkFrame(self.inputs, fg_color="transparent", height=0)
        self.attach_bar.pack(fill="x", pady=(6, 0))
        for txt, cmd in ((_("📎 Картинка"), self.attach_files), (_("📋 Вставить"), self.attach_clipboard),
                         (_("📸 Снимок экрана"), self.attach_screenshot)):
            ctk.CTkButton(self.attach_bar, text=txt, width=110, height=26, fg_color=T.PANEL2, hover_color=T.LINE,
                          font=(T.UI, 11), command=cmd).pack(side="left", padx=(0, 6))
        self.chips = ctk.CTkFrame(self.attach_bar, fg_color="transparent")
        self.chips.pack(side="left", fill="x")
        self.prompt_entry.bind("<Control-v>", self._on_paste)
        self.prompt_entry.bind("<Control-Return>", lambda e: (self.start_agent(), "break")[1])
        self.prompt_entry_2.bind("<Control-Return>", lambda e: (self.start_agent(), "break")[1])

        side = ctk.CTkFrame(ctl, fg_color="transparent")
        side.grid(row=0, column=1, sticky="ns")
        self.btn_run = ctk.CTkButton(side, text=_("🚀 ОТПРАВИТЬ"), width=160, height=38, fg_color="#1f7a3a",
                                     hover_color="#176030", font=(T.UI, 13, "bold"), command=self.start_agent)
        self.btn_run.pack(fill="x")
        self.btn_pause = ctk.CTkButton(side, text=_("⏸ ПАУЗА"), width=160, height=30, fg_color="#a16207",
                                       hover_color="#854d0e", command=self.agent.pause, state="disabled")
        self.btn_pause.pack(fill="x", pady=(6, 0))
        self.btn_stop = ctk.CTkButton(side, text=_("🛑 СТОП"), width=160, height=30, fg_color="#b91c1c",
                                      hover_color="#991b1b", command=self.agent.stop, state="disabled")
        self.btn_stop.pack(fill="x", pady=(6, 0))
        ctk.CTkLabel(side, text="Ctrl+Enter", font=(T.UI, 10), text_color=T.MUTE).pack(pady=(6, 0))

    # ------------------------------------------------------------------ чат: отрисовка
    def _classify(self, ln):
        s = ln.lstrip()
        if ln.startswith(("[Задача]", "[Структура")):
            self._in_user = True
            return "user"
        tag = "ai"
        if s.startswith("⚙️"):
            tag = "step"
        elif s.startswith("📋"):
            tag = "plan"
        elif s.startswith(("✅", "📝", "🔄")):
            tag = "ok"
        elif s.startswith(("❌", "🛑", "🛡️")):
            tag = "bad"
        elif s.startswith(("⚠️", "⏸")):
            tag = "warn"
        elif ln.startswith(("[Система]", "[🤖", "[💬", "[🛠️", "[🎯", "[▶️", "[❓", "[⚙️", "⚡", "🚀")) or (s and set(s) <= {"="}):
            tag = "sys"
        if tag != "ai":
            self._in_user = False
        elif self._in_user:
            return "user"
        return tag

    def _line_segment(self, ln):
        m = FENCE.match(ln)
        if m:
            info = m.group(2).strip()
            if not self._fence:
                self._fence, self._depth = True, 0
                fm = FILE_INFO.match(info)
                label = ("📄 " + fm.group(1)) if fm else (info or "code")
                return (" " + label + "\n", "codehead")
            if info == "":
                if self._depth == 0:
                    self._fence = False
                    return None
                self._depth -= 1
            else:
                self._depth += 1
            return (ln + "\n", "code")
        if self._fence:
            return (ln + "\n", "code")
        return (ln + "\n", self._classify(ln))

    def chat_write(self, text):
        t = self.chat
        at_bottom = t.yview()[1] > 0.97
        t.configure(state="normal")
        t.delete("live_start", "end-1c")          # убираем недописанную строку, перерисуем ниже
        data = self._partial + text
        *lines, self._partial = data.split("\n")
        segs = []
        for ln in lines:
            seg = self._line_segment(ln)
            if seg is None:
                continue
            if segs and segs[-1][1] == seg[1]:
                segs[-1] = (segs[-1][0] + seg[0], seg[1])
            else:
                segs.append(seg)
        for s, tag in segs:
            t.insert("end", s, tag)
        t.mark_set("live_start", "end-1c")
        if self._partial:                          # живая недописанная строка, чтобы текст «печатался»
            tag = "code" if self._fence else self._classify(self._partial)
            t.insert("end", self._partial, tag)
        if int(t.index("end-1c").split(".")[0]) > 6000:
            t.delete("1.0", "1500.0")
        t.configure(state="disabled")
        if at_bottom:
            t.see("end")

    def _clear_chat(self):
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.mark_set("live_start", "1.0")
        self.chat.configure(state="disabled")
        self._partial, self._fence, self._depth, self._in_user = "", False, 0, False

    def _copy_selection(self):
        try:
            self.clipboard_clear()
            self.clipboard_append(self.chat.get("sel.first", "sel.last"))
        except tk.TclError:
            pass
        return "break"

    # ------------------------------------------------------------------ чаты
    def refresh_chat_list(self):
        for w in self.chats_frame.winfo_children():
            w.destroy()
        for item in self.store.listing():
            cid = item["id"]
            row = ctk.CTkFrame(self.chats_frame, fg_color="transparent")
            row.pack(fill="x", pady=2)
            row.grid_columnconfigure(0, weight=1)
            cur = cid == self.current_chat_id
            ctk.CTkButton(row, text=item["title"], anchor="w", height=32, fg_color=T.ACC if cur else T.PANEL2,
                          hover_color=T.ACC_HOVER if cur else T.LINE, font=(T.UI, 12),
                          command=lambda c=cid: self.switch_chat(c)).grid(row=0, column=0, sticky="ew")
            ctk.CTkButton(row, text="✖", width=28, height=32, fg_color=T.PANEL2, hover_color=T.BAD,
                          command=lambda c=cid: self.delete_chat(c)).grid(row=0, column=1, padx=(4, 0))

    def new_chat(self, title=None):
        self.switch_chat(self.store.new(title or _("Новый проект")))

    def switch_chat(self, cid):
        chat = self.store.get(cid)
        if not chat:
            return
        self.current_chat_id = cid
        self.lbl_title.configure(text=chat["title"])
        mode = chat.get("mode", "agent")
        self.mode_seg.set(_(dict(MODES).get(mode, MODES[0][1])))
        self._apply_mode_ui(mode)
        self._clear_chat()
        self.chat_write("".join(chat.get("messages", [])))
        self.chat.see("end")
        self.refresh_chat_list()

    def delete_chat(self, cid):
        chat = self.store.get(cid)
        if not chat:
            return
        if self.agent.running_cid == cid:
            return messagebox.showinfo("AI-Coder", _("В этом чате сейчас идёт задача. Сначала остановите её."))
        if not messagebox.askyesno(_("Удаление сессии"), f"{_('Удалить чат')} «{chat['title']}»?"):
            return
        self.store.delete(cid)
        try:
            os.remove(os.path.join(self.ws.root, BACKUP_DIR, "chat_logs", f"{cid}.log"))
        except OSError:
            pass
        if self.current_chat_id == cid:
            self.switch_chat(self.store.first_id() or self.store.new())
        else:
            self.refresh_chat_list()

    def on_mode_change(self, label):
        mode = next((m[0] for m in MODES if _(m[1]) == label), "agent")
        self.store.set_field(self.current_chat_id, "mode", mode)
        self._apply_mode_ui(mode)

    def _apply_mode_ui(self, mode):
        self.lbl_prompt_2.pack_forget()
        self.prompt_entry_2.pack_forget()
        self.lbl_prompt_1.configure(text=_("Запрос:"))
        if mode == "dcoder":
            self.attach_bar.pack_forget()
            self.lbl_prompt_1.configure(text=_("1. Структура проекта (папки/файлы):"))
            self.lbl_prompt_2.pack(anchor="w", pady=(6, 2))
            self.prompt_entry_2.pack(fill="x")
        else:
            self.attach_bar.pack(fill="x", pady=(6, 0))

    # ------------------------------------------------------------------ запуск задач
    def current_mode(self):
        return (self.store.get(self.current_chat_id) or {}).get("mode", "agent")

    def start_agent(self):
        mode = self.current_mode()
        task = self.prompt_entry.get("1.0", "end").strip()
        task2 = self.prompt_entry_2.get("1.0", "end").strip() if mode == "dcoder" else ""
        resumable = bool((self.store.get(self.current_chat_id) or {}).get("state"))
        pics = [a["b64"] for a in self.attached] if mode != "dcoder" else []
        if not (task or task2 or pics or resumable):
            return
        ok, err = self.agent.submit(self.current_chat_id, mode, task, task2, images=pics)
        if not ok:
            return messagebox.showinfo("AI-Coder", err)
        self.attached.clear()
        self.refresh_chips()
        self.prompt_entry.delete("1.0", "end")
        self.prompt_entry_2.delete("1.0", "end")
        self.lbl_title.configure(text=self.store.get(self.current_chat_id)["title"])
        self.terminal_frame.grid_remove()
        self.refresh_chat_list()

    def update_state(self, ev):
        running = ev.get("running")
        self.btn_run.configure(state="disabled" if running else "normal",
                               text=_("🧠 ОБРАБОТКА...") if running else _("🚀 ОТПРАВИТЬ / ПРОДОЛЖ."))
        self.btn_stop.configure(state="normal" if running else "disabled")
        self.btn_pause.configure(state="normal" if running and not ev.get("paused") else "disabled")
        if running:
            where = "" if ev.get("cid") == self.current_chat_id else " (" + _("другой чат") + ")"
            step = f" · {_('шаг')} {ev['step']}" if ev.get("step") else ""
            self.lbl_state.configure(text=("⏸ " + _("Пауза") if ev.get("paused") else "⚙ " + _("Работает")) + step + where,
                                     text_color=T.WARN)
        else:
            self.lbl_state.configure(text="● " + _("Готов"), text_color=T.OK)
            self.editor.reload_if_changed()

    # ------------------------------------------------------------------ вложения (скриншоты)
    def refresh_chips(self):
        for w in self.chips.winfo_children():
            w.destroy()
        for i, a in enumerate(self.attached):
            ctk.CTkButton(self.chips, text=f"🖼 {a['name'][:18]} ✖", height=26, fg_color="#1b2a45", hover_color=T.BAD,
                          font=(T.UI, 11), command=lambda k=i: self.remove_attachment(k)).pack(side="left", padx=2)

    def remove_attachment(self, k):
        if 0 <= k < len(self.attached):
            del self.attached[k]
            self.refresh_chips()

    def _add_attachment(self, name, b64):
        if len(self.attached) >= imgs.MAX_IMAGES:
            return messagebox.showinfo("AI-Coder", f"{_('Максимум изображений')}: {imgs.MAX_IMAGES}")
        self.attached.append({"name": name, "b64": b64})
        self.refresh_chips()

    def attach_files(self):
        paths = filedialog.askopenfilenames(title=_("Выберите изображения"),
                                            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("All", "*.*")])
        for p in paths or ():
            try:
                self._add_attachment(os.path.basename(p), imgs.prepare_file(p))
            except (OSError, ValueError) as e:
                messagebox.showwarning("AI-Coder", f"{os.path.basename(p)}: {e}")

    def _clipboard_image(self):
        """Картинка или файлы-картинки из буфера обмена. None, если там текст или пусто."""
        try:
            from PIL import Image, ImageGrab
            data = ImageGrab.grabclipboard()
        except Exception:
            return None
        if isinstance(data, Image.Image):
            return [("clipboard.png", imgs.from_pil(data))]
        if isinstance(data, list):
            out = []
            for p in data:
                if os.path.splitext(str(p))[1].lower() in (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"):
                    try:
                        out.append((os.path.basename(p), imgs.prepare_file(p)))
                    except (OSError, ValueError):
                        pass
            return out or None
        return None

    def _on_paste(self, _e):
        pics = self._clipboard_image()
        if not pics:
            return None            # обычная вставка текста
        for name, b64 in pics:
            self._add_attachment(name, b64)
        return "break"

    def attach_clipboard(self):
        if not self._on_paste(None):
            messagebox.showinfo("AI-Coder", _("В буфере обмена нет изображения. На Linux для этого нужен xclip или wl-paste."))

    def attach_screenshot(self):
        self.withdraw()

        def grab():
            try:
                from PIL import ImageGrab
                shot = ImageGrab.grab()
                self.deiconify()
                self._add_attachment("screen.png", imgs.from_pil(shot))
            except Exception as e:
                self.deiconify()
                messagebox.showwarning("AI-Coder", f"{_('Не удалось сделать снимок экрана')}: {e}")
        self.after(450, grab)

    # ------------------------------------------------------------------ GPU / сеть / модель
    def on_model(self, name):
        name = (name or "").strip()
        if not name:
            return
        self.cfg.set("model", name)
        self.model_menu.set(name)
        if self.models and name not in self.models:
            self.set_toast("⚠️ " + _("Такой модели нет в списке установленных. Если будет ошибка, выполните") + f": ollama pull {name}", 12000)
        if self.agent.running:
            return self.set_toast("ℹ️ " + _("Модель сменится со следующего запроса"))
        threading.Thread(target=self.llm.warmup, daemon=True).start()
        self.set_toast("🧠 " + _("Загружаю модель") + f" {name}...")

    def on_device(self, label):
        dev = next((d[0] for d in DEVICES if _(d[1]) == label), "auto")
        self.cfg.set("device", dev)
        if self.agent.running:
            return self.set_toast("ℹ️ " + _("Режим применится со следующего запроса"))
        threading.Thread(target=self._reload_model, daemon=True).start()
        self.set_toast("🔄 " + _("Перезагружаю модель в режиме") + f" {label}...")

    def _reload_model(self):
        self.llm.unload()
        ok, err = self.llm.warmup()
        self._q.put({"t": "toast", "text": _("✅ Готово") if ok else f"⚠️ {err}"})

    def sync_device_widget(self):
        self.dev_seg.set(_(dict(DEVICES)[self.cfg.get("device")]))

    def update_gpu_chip(self, d):
        if not d:
            return
        gpus, loaded = d.get("gpus"), d.get("loaded") or []
        gp = gpus[0] if gpus else None
        mem = f" · {gp['used_mb'] / 1024:.1f}/{gp['total_mb'] / 1024:.0f} ГБ" if gp else ""
        if d["device"] == "cpu":
            text, color = "🔵 CPU", "#60a5fa"
        elif d.get("warning"):
            text, color = "🟠 " + (f"GPU {loaded[0]['pct_gpu']}%" if loaded else _("нет GPU")) + mem, T.WARN
        elif loaded:
            text, color = f"🟢 GPU {loaded[0]['pct_gpu']}%{mem}", T.OK
        else:
            text, color = "⚪ " + (gp["name"] + mem if gp else _("модель не загружена")), T.MUTE
        self.chip_gpu.configure(text=text, text_color=color)

    def apply_network(self):
        if self.cfg.get("serve_network"):
            if self.server.running and self.server.httpd.server_address[1] != int(self.cfg.get("port")):
                self.server.stop()
            self.server.start()
        else:
            self.server.stop()
        self.update_net_chip()

    def update_net_chip(self):
        if self.server.running:
            ip = self.server.urls()[0].split("//")[1].split("/")[0]
            self.chip_net.configure(text="📱 " + ip, text_color=T.OK)
        elif self.server.error:
            self.chip_net.configure(text="📱 " + _("ошибка порта"), text_color=T.BAD)
        else:
            self.chip_net.configure(text="📱 " + _("выкл"), text_color=T.MUTE)

    # ------------------------------------------------------------------ файловое дерево
    def schedule_tree_refresh(self):
        if self._tree_job is None:
            self._tree_job = self.after(400, self._do_tree_refresh)

    def _do_tree_refresh(self):
        self._tree_job = None
        self.refresh_tree()
        self.editor.reload_if_changed()

    def refresh_tree(self):
        opened = {self.tree.item(i, "text") for i in self._tree_paths if self.tree.exists(i) and self.tree.item(i, "open")}
        self.tree.delete(*self.tree.get_children())
        self._tree_paths = {}
        root = self.tree.insert("", "end", text="📂 " + self.ws.name, open=True)
        self._tree_paths[root] = self.ws.root
        nodes = {"": root}
        entries = sorted(self.ws.entries(), key=lambda e: (e["path"].count("/"), not e["dir"], e["path"].lower()))
        for e in entries:
            parent_rel, _sep, name = e["path"].rpartition("/")
            parent = nodes.get(parent_rel, root)
            label = ("📁 " if e["dir"] else "📄 ") + name
            iid = self.tree.insert(parent, "end", text=label, open=label in opened)
            self._tree_paths[iid] = os.path.join(self.ws.root, e["path"])
            if e["dir"]:
                nodes[e["path"]] = iid

    def _selected_path(self):
        sel = self.tree.selection()
        return self._tree_paths.get(sel[0]) if sel else None

    def on_tree_select(self, _e=None):
        p = self._selected_path()
        if p and os.path.isfile(p):
            self.editor.load_file(p)
            self.tabview.set(self.TAB_EDITOR)

    def _setup_context_menu(self):
        m = tk.Menu(self, tearoff=0, bg=T.PANEL2, fg=T.FG, activebackground=T.ACC, bd=0)
        m.add_command(label="▶️ " + _("Запустить"), command=self.ctx_run)
        m.add_separator()
        m.add_command(label="📝 " + _("Создать файл"), command=self.ctx_create)
        m.add_command(label="🗑️ " + _("Удалить"), command=self.ctx_delete)
        m.add_separator()
        m.add_command(label="🔄 " + _("Обновить"), command=self.refresh_tree)
        self.ctx_menu = m
        btn = "<Button-2>" if platform.system() == "Darwin" else "<Button-3>"
        self.tree.bind(btn, self._popup_menu)

    def _popup_menu(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
        try:
            self.ctx_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.ctx_menu.grab_release()

    def ctx_run(self):
        p = self._selected_path()
        if p and os.path.isfile(p):
            self.editor.run_file_in_terminal(p)

    def ctx_create(self):
        p = self._selected_path() or self.ws.root
        base = p if os.path.isdir(p) else os.path.dirname(p)
        name = ctk.CTkInputDialog(text=_("Имя файла:"), title=_("Создать файл")).get_input()
        if not name:
            return
        try:
            full = self.ws.resolve(os.path.relpath(os.path.join(base, name), self.ws.root))
            os.makedirs(os.path.dirname(full), exist_ok=True)
            open(full, "a", encoding="utf-8").close()
            self.refresh_tree()
        except (ValueError, OSError) as e:
            messagebox.showerror(_("Ошибка"), str(e))

    def ctx_delete(self):
        p = self._selected_path()
        if not p or p == self.ws.root:
            return
        if messagebox.askyesno(_("Удалить"), f"{_('Удалить')} {os.path.basename(p)}?"):
            try:
                shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
                self.refresh_tree()
            except OSError as e:
                messagebox.showerror(_("Ошибка"), str(e))

    def select_workspace(self):
        folder = filedialog.askdirectory(initialdir=self.ws.root)
        if folder:
            self.ws.set_root(folder)
            self.backup.workspace_dir = self.ws.root
            self.cfg.set("workspace", self.ws.root)
            self.lbl_ws.configure(text="📂 " + self.ws.name)
            self.refresh_tree()
            self.agent.say(self.current_chat_id, f"[Система] Рабочая папка: {self.ws.root}\n")

    def rollback_wrapper(self):
        if self.agent.running:
            return messagebox.showinfo("AI-Coder", _("Сначала остановите задачу."))
        if messagebox.askyesno(_("⏪ Откат кода"), _("Вернуть проект к состоянию до последних изменений ИИ?")):
            ok, msg = self.agent.rollback()
            self.agent.say(self.current_chat_id, f"[Система] ⏪ {msg}\n")
            (messagebox.showinfo if ok else messagebox.showwarning)("AI-Coder", msg)

    # ------------------------------------------------------------------ окна
    def _popup(self, title, w, h, modal=False):
        win = ctk.CTkToplevel(self)
        win.title(title)
        win.configure(fg_color=T.BG)
        win.geometry(f"{w}x{h}+{self.winfo_x() + (self.winfo_width() - w) // 2}+{self.winfo_y() + (self.winfo_height() - h) // 2}")
        win.transient(self)
        if modal:
            win.after(100, win.grab_set)
        win.after(100, win.focus_force)
        return win

    def open_license_window(self):
        win = self._popup(_("📜 О Проекте"), 680, 580, modal=True)
        ctk.CTkLabel(win, text="AI-CODER", font=(T.MONO, 22, "bold"), text_color=T.ACC).pack(pady=(16, 0))
        ctk.CTkLabel(win, text=_("Лицензионное соглашение"), font=(T.UI, 11), text_color=T.MUTE).pack(pady=(0, 10))
        tb = ctk.CTkTextbox(win, font=(T.UI, 12), wrap="word", fg_color=T.PANEL, spacing3=5)
        tb.pack(fill="both", expand=True, padx=16, pady=(0, 12))
        tb.insert("1.0", _(LICENSE_TEXT))
        tb.configure(state="disabled")
        ctk.CTkButton(win, text=_("Я прочитал эту простыню и согласен"), width=320, fg_color=T.ACC,
                      hover_color="#1f7a3a", command=win.destroy).pack(pady=(0, 16))

    def open_help_window(self):
        win = self._popup(_("❓ Помощь"), 620, 560)
        tb = ctk.CTkTextbox(win, font=(T.UI, 13), wrap="word", fg_color=T.PANEL)
        tb.pack(fill="both", expand=True, padx=12, pady=12)
        tb.insert("1.0", _(
            "AI-Coder: локальный ИИ-помощник для программирования. Всё считается на вашем компьютере.\n\n"
            "РЕЖИМЫ\n"
            "🤖 Агент: сам составляет план и пишет файлы шаг за шагом.\n"
            "💬 ASK: вопрос-ответ без изменения файлов.\n"
            "🛠️ Ассистент: сам выполняет команды по кругу: ИИ получает вывод и решает, закончено ли, иначе пробует дальше (лимит шагов в Настройки → Агент).\n"
            "🎯 D-Coder: раскладывает ваш код по файлам по описанной структуре (быстро, без ИИ, если формат понятен).\n\n"
            "ВИДЕОКАРТА\n"
            "Внизу окна переключатель GPU / Авто / CPU и индикатор: сколько процентов модели лежит в видеопамяти. "
            "Если там не 100%, возьмите модель поменьше или уменьшите контекст в настройках.\n\n"
            "ТЕЛЕФОН\n"
            "Настройки → Сеть: включите раздачу, откройте на телефоне адрес из окна (телефон и ПК в одной Wi-Fi сети). "
            "Все задачи выполняет компьютер, а готовый проект на телефоне скачивается кнопкой «Скачать ZIP».\n\n"
            "Горячие клавиши: Ctrl+Enter отправить, Ctrl+S сохранить файл."))
        tb.configure(state="disabled")

    def open_mini_browser(self):
        win = self._popup("Web-AI Catalog", 420, 560)
        ctk.CTkLabel(win, text="🌐 Web-AI", font=(T.UI, 16, "bold")).pack(pady=(14, 4))
        sf = ctk.CTkScrollableFrame(win, fg_color="transparent")
        sf.pack(fill="both", expand=True, padx=14, pady=(4, 14))
        cats = [("🔥 LLM", [("DeepSeek", "#0d47a1", "https://chat.deepseek.com"), ("Claude", "#d97757", "https://claude.ai"),
                            ("ChatGPT", "#10a37f", "https://chatgpt.com"), ("Gemini", "#1a73e8", "https://gemini.google.com"),
                            ("Qwen", "#6f42c1", "https://chat.qwen.ai")]),
                ("⚡ UI/UX Tools", [("v0.dev", "#111111", "https://v0.dev"), ("Bolt.new", "#1e88e5", "https://bolt.new")])]
        for title, items in cats:
            ctk.CTkLabel(sf, text=title, font=(T.UI, 12, "bold"), text_color="#38d9a9", anchor="w").pack(fill="x", pady=(12, 4))
            for name, color, url in items:
                ctk.CTkButton(sf, text=name, fg_color=color, hover_color=T.LINE, anchor="w", height=34,
                              command=lambda u=url: (win.destroy(), webbrowser.open_new(u))).pack(fill="x", pady=3)

    def open_cmd(self):
        try:
            if platform.system() == "Windows":
                subprocess.Popen(["cmd.exe", "/c", "start", "cmd.exe"], cwd=self.ws.root)
                return
            for term in ("gnome-terminal", "x-terminal-emulator", "konsole", "xterm", "lxterminal"):
                if shutil.which(term):
                    subprocess.Popen([term], cwd=self.ws.root)
                    return
            messagebox.showerror(_("Ошибка"), _("Не найден эмулятор терминала Linux."))
        except OSError as e:
            messagebox.showerror(_("Ошибка"), str(e))
