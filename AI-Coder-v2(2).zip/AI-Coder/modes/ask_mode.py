from core.engine import SYSTEM_ASK


def run(agent, cid, task):
    agent.say(cid, "[💬 ASK] Ищу ответ...\n")
    hist = agent.history_messages(cid)
    agent.remember(cid, "user", task)
    resp = agent.ask(cid, task, system=SYSTEM_ASK, header="🤖 [Ответ]:\n", history=hist, images=agent.run_images)
    if not agent.cancelled:
        agent.remember(cid, "assistant", resp)
