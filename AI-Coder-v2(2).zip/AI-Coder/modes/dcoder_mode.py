import re

from core.parsing import parse_structure, split_sections


def run(agent, cid, structure, content):
    agent.say(cid, "[🎯 D-CODER] Этап 1: читаю структуру проекта...\n")
    files = parse_structure(structure)
    if files:
        agent.say(cid, "📋 Структура распознана без ИИ: " + str(len(files)) + " файлов.\n")
    else:
        resp = agent.ask(
            cid,
            "Прочитай структуру проекта и выпиши ВСЕ файлы (папки не нужны) строго в формате:\n"
            "FILE: путь/к/файлу.py\nНикаких других слов.\n\n--- СТРУКТУРА ---\n" + structure,
            header="📋 [РАСПОЗНАННЫЕ ФАЙЛЫ]:\n")
        files = [f.strip().strip("`").replace("\\", "/").lstrip("/")
                 for f in re.findall(r"FILE:\s*([^\n]+)", resp, re.IGNORECASE)]
        files = [f for f in files if f and not f.endswith("/")]
    if agent.cancelled:
        return
    if not files:
        agent.say(cid, "⚠️ Не удалось распознать файлы. Проверьте структуру проекта.\n")
        return

    for f in files:
        try:
            full = agent.ws.resolve(f)
            import os
            os.makedirs(os.path.dirname(full), exist_ok=True)
            if not os.path.exists(full):
                open(full, "w", encoding="utf-8").close()
        except (ValueError, OSError) as e:
            agent.say(cid, f"❌ [{f}]: {e}\n")
    agent.emit(t="tree")
    agent.say(cid, "✅ Пустые файлы и папки созданы.\n\n[🎯 D-CODER] Этап 2: раскладываю код по файлам...\n")

    # Быстрый путь: нарезаем код локально. К ИИ идём только за тем, что не нашли.
    sections = split_sections(content, files)
    agent._ensure_backup(cid)
    for f, code in sections.items():
        try:
            agent.ws.write_file(f, code)
            agent.changed.add(f)
            agent.say(cid, f"📝 [Записан без ИИ] {f}\n")
        except (ValueError, OSError) as e:
            agent.say(cid, f"❌ [{f}]: {e}\n")
    agent.emit(t="tree")

    missing = [f for f in files if f not in sections]
    for i, f in enumerate(missing, 1):
        if agent.cancelled or agent.paused:
            return
        agent.set_step(f"{i}/{len(missing)}")
        agent.say(cid, f"⚙️ [ИИ ищет код {i}/{len(missing)}]: {f}\n")
        prompt = (f"--- ИСХОДНЫЕ КОДЫ ---\n{content}\n--- КОНЕЦ ---\n\n"
                  f"Найди в исходниках код, относящийся к файлу '{f}', и выведи его ПОЛНОСТЬЮ в блоке:\n"
                  f"```file: {f}\nВЕСЬ КОД\n```\nЕсли кода для этого файла нет, ответь одним словом: НЕТ.")
        resp = agent.ask(cid, prompt)
        agent.apply(cid, resp, files=True, commands=False)

    if not agent.cancelled and not agent.paused:
        agent.remember(cid, "user", "[D-CODER: сборка проекта]")
        agent.remember(cid, "assistant", f"Собрано файлов: {len(files)}.")
        agent.say(cid, f"\n✅ [D-CODER] Готово: {len(files)} файлов (без ИИ: {len(sections)}).\n")
