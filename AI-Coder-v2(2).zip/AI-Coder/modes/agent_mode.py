import re

DEPTH = {"short": "от 3 до 8", "normal": "от 6 до 15", "deep": "от 15 до 40"}


def run(agent, cid, task):
    saved = agent.store.get(cid).get("state") or {}
    if saved.get("steps"):
        agent.say(cid, "[▶️ ПРОДОЛЖЕНИЕ] Восстанавливаю прерванную задачу...\n")
        steps, start, plan = saved["steps"], saved["current_index"], saved["plan"]
        task = task or saved.get("task", "")
    else:
        agent.say(cid, "[🤖 АГЕНТ] Запуск автономного программирования...\n")
        agent.remember(cid, "user", task)
        depth = DEPTH.get(agent.cfg.get("plan_depth"), DEPTH["normal"])
        plan = agent.ask(
            cid,
            f"{agent.history_text(cid)}Задача: {task}\n"
            f"Составь пошаговый план реализации ({depth} шагов) нумерованным списком, "
            f"один шаг на строку, коротко и конкретно. Без кода.",
            header="📋 [ПЛАН ПРОЕКТА]:\n", images=agent.run_images)
        if agent.cancelled:
            return
        steps = [l.strip() for l in plan.split("\n") if re.match(r"^\d+[.)]", l.strip())] or ["1. Реализовать задачу."]
        start = 0

    for i in range(start, len(steps)):
        if agent.cancelled:
            agent.store.set_field(cid, "state", {})
            return
        if agent.paused:
            agent.store.set_field(cid, "state", {"steps": steps, "current_index": i, "plan": plan, "task": task})
            agent.say(cid, f"⏸ Пауза перед шагом {i + 1}. Нажмите «Отправить», чтобы продолжить.\n")
            return
        agent.set_step(f"{i + 1}/{len(steps)}")
        # Стабильное начало промпта (задача, план, файлы) позволяет Ollama переиспользовать кэш, шаг в конце.
        prompt = (f"Задача: {task}\nОбщий план:\n{plan}\n\n{agent.ws.context(agent.ctx_budget())}\n\n"
                  f"Выполни шаг {i + 1}: {steps[i]}\n"
                  "Каждый создаваемый или изменяемый файл выводи ЦЕЛИКОМ в блоке ```file: путь/к/файлу.ext ... ```, "
                  "иначе он не сохранится.")
        resp = agent.ask(cid, prompt, header=f"\n⚙️ [ШАГ {i + 1}/{len(steps)}]: {steps[i]}\n🤖 ", images=agent.run_images)
        if agent.cancelled:
            agent.store.set_field(cid, "state", {})
            return
        agent.apply(cid, resp, files=True, commands=True)

    agent.store.set_field(cid, "state", {})
    files = ", ".join(sorted(agent.changed)) or "без изменений"
    agent.remember(cid, "assistant", f"Выполнен план:\n{plan}\nИзменённые файлы: {files}")
    agent.say(cid, f"\n✅ [АГЕНТ] Готово. Изменённые файлы: {files}\n")
