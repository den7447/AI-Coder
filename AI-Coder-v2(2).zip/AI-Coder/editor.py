import os
import platform
import shutil
import subprocess
import tkinter as tk
import webbrowser
from tkinter import messagebox

import customtkinter as ctk

import highlight
import theme as T
from i18n import _


class CodeEditorModule(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.path = None
        self._mtime = 0
        self.dirty = False
        self._hl_job = None
        self.pack(fill="both", expand=True)

        # --- верхняя панель ---
        top = ctk.CTkFrame(self, fg_color="transparent")
        top.pack(fill="x", pady=(0, 6))
        self.lbl_file = ctk.CTkLabel(top, text=_("Файл не выбран"), font=(T.UI, 13, "bold"), text_color=T.MUTE)
        self.lbl_file.pack(side="left", padx=4)
        ctk.CTkButton(top, text=_("▶️ Запустить проект"), width=150, fg_color="#1f7a3a", hover_color="#176030",
                      command=self.run_project).pack(side="right", padx=4)
        ctk.CTkButton(top, text=_("💾 Сохранить"), width=120, fg_color=T.ACC, hover_color=T.ACC_HOVER,
                      command=self.save_file).pack(side="right", padx=4)

        # --- редактор с номерами строк ---
        body = ctk.CTkFrame(self, fg_color=T.CODE_BG, corner_radius=8)
        body.pack(fill="both", expand=True)
        mono = (T.MONO, 12)
        self.nums = tk.Text(body, width=5, padx=6, pady=8, bg=T.CODE_BG, fg="#4b5563", font=mono, bd=0,
                            highlightthickness=0, state="disabled", cursor="arrow", takefocus=0, wrap="none")
        self.nums.tag_configure("r", justify="right")
        self.nums.pack(side="left", fill="y")
        self.sb = ctk.CTkScrollbar(body, command=self._yview)
        self.sb.pack(side="right", fill="y")
        self.text = tk.Text(body, bg=T.CODE_BG, fg=T.FG, insertbackground=T.FG, font=mono, bd=0, wrap="none",
                            highlightthickness=0, padx=8, pady=8, undo=True, maxundo=200, tabs=("2c",),
                            selectbackground="#264f78", yscrollcommand=self._on_yscroll)
        self.text.pack(side="left", fill="both", expand=True)
        hs = ctk.CTkScrollbar(self, orientation="horizontal", command=self.text.xview)
        hs.pack(fill="x")
        self.text.configure(xscrollcommand=hs.set)
        highlight.setup_tags(self.text)

        self.text.bind("<KeyRelease>", self._on_key)
        self.text.bind("<Tab>", self._on_tab)
        self.text.bind("<Return>", self._on_return)
        self.text.bind("<Control-s>", lambda e: (self.save_file(), "break")[1])
        self.text.bind("<Control-S>", lambda e: (self.save_file(), "break")[1])
        self.text.bind("<MouseWheel>", lambda e: self.after(10, self._sync_nums))
        self.text.bind("<Button-4>", lambda e: self.after(10, self._sync_nums))
        self.text.bind("<Button-5>", lambda e: self.after(10, self._sync_nums))

        # --- мини-ИИ для текущего файла ---
        panel = ctk.CTkFrame(self, fg_color=T.PANEL, corner_radius=10)
        panel.pack(fill="x", pady=(8, 0))
        self.ai_mode = ctk.StringVar(value="AGENT")
        ctk.CTkSegmentedButton(panel, values=["AGENT", "ASK"], variable=self.ai_mode, width=140,
                               selected_color=T.ACC).pack(side="left", padx=8, pady=8)
        self.mini = ctk.CTkTextbox(panel, height=56, font=(T.UI, 12), wrap="word", fg_color=T.BG)
        self.mini.pack(side="left", fill="both", expand=True, padx=4, pady=8)
        self.btn_ai = ctk.CTkButton(panel, text=_("🚀 Отправить"), width=110, fg_color=T.ACC,
                                    hover_color=T.ACC_HOVER, command=self.run_mini_ai)
        self.btn_ai.pack(side="left", padx=8)
        self.mini.bind("<Control-Return>", lambda e: (self.run_mini_ai(), "break")[1])

    # ---------- номера строк / прокрутка ----------
    def _yview(self, *a):
        self.text.yview(*a)
        self._sync_nums()

    def _on_yscroll(self, first, last):
        self.sb.set(first, last)
        self.nums.yview_moveto(first)

    def _sync_nums(self):
        total = int(self.text.index("end-1c").split(".")[0])
        cur = self.nums.get("1.0", "end-1c")
        shown = cur.count("\n") + 1 if cur else 0
        if total != shown:
            self.nums.configure(state="normal")
            self.nums.delete("1.0", "end")
            self.nums.insert("1.0", "\n".join(str(i) for i in range(1, total + 1)), "r")
            self.nums.configure(state="disabled")
        self.nums.yview_moveto(self.text.yview()[0])

    # ---------- ввод ----------
    def _on_tab(self, _e):
        self.text.insert("insert", "    ")
        return "break"

    def _on_return(self, _e):
        line = self.text.get("insert linestart", "insert")
        indent = line[:len(line) - len(line.lstrip(" \t"))]
        if line.rstrip().endswith((":", "{", "(", "[")):
            indent += "    "
        self.text.insert("insert", "\n" + indent)
        self.text.see("insert")
        self._mark_dirty()
        self._sync_nums()
        return "break"

    def _on_key(self, e):
        if e.keysym in ("Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Left", "Right", "Up", "Down"):
            return
        self._mark_dirty()
        if self._hl_job:
            self.after_cancel(self._hl_job)
        self._hl_job = self.after(200, self._rehighlight)

    def _rehighlight(self):
        self._hl_job = None
        self._sync_nums()
        highlight.apply(self.text, self.path)

    def _mark_dirty(self):
        if not self.dirty and self.path:
            self.dirty = True
            self._update_label()

    def _update_label(self):
        if not self.path:
            self.lbl_file.configure(text=_("Файл не выбран"), text_color=T.MUTE)
            return
        name = os.path.relpath(self.path, self.app.ws.root)
        self.lbl_file.configure(text=("● " if self.dirty else "") + name,
                                text_color=T.WARN if self.dirty else T.OK)

    # ---------- файлы ----------
    def load_file(self, filepath):
        if self.dirty and self.path and self.path != filepath:
            if not messagebox.askyesno(_("Внимание"), _("Есть несохранённые изменения. Открыть другой файл без сохранения?")):
                return
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
        except (OSError, UnicodeDecodeError):
            messagebox.showwarning(_("Внимание"), _("Этот файл нельзя открыть в редакторе (бинарный?)"))
            return
        self.path = filepath
        self.app.current_open_file = filepath
        self._mtime = os.path.getmtime(filepath)
        self.dirty = False
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)
        self.text.edit_reset()
        self._update_label()
        self._rehighlight()

    def reload_if_changed(self):
        """Если файл изменил ИИ, а в редакторе нет правок, подтягиваем новую версию."""
        if not self.path or self.dirty or not os.path.exists(self.path):
            return
        if os.path.getmtime(self.path) != self._mtime:
            y = self.text.yview()[0]
            self.load_file(self.path)
            self.text.yview_moveto(y)

    def save_file(self):
        if not self.path:
            return
        try:
            with open(self.path, "w", encoding="utf-8", newline="\n") as f:
                f.write(self.text.get("1.0", "end-1c").rstrip("\n") + "\n")
            self._mtime = os.path.getmtime(self.path)
            self.dirty = False
            self._update_label()
        except OSError as e:
            messagebox.showerror(_("Ошибка"), str(e))

    # ---------- запуск ----------
    def run_project(self):
        wd = self.app.ws.root
        for c in ("main.py", "app.py", "index.py", "index.js", "main.js", "server.js", "run.bat", "run.sh"):
            if os.path.exists(os.path.join(wd, c)):
                return self.run_file_in_terminal(os.path.join(wd, c))
        if self.path:
            return self.run_file_in_terminal(self.path)
        messagebox.showinfo("Info", _("Не найден главный файл проекта."))

    def run_file_in_terminal(self, filepath):
        ext = os.path.splitext(filepath)[1].lower()
        wd, name = os.path.dirname(filepath), os.path.basename(filepath)
        win = platform.system() == "Windows"
        if ext == ".py":
            cmd = f'python "{name}"' if win else f'python3 "{name}"'
        elif ext == ".js":
            cmd = f'node "{name}"'
        elif ext in (".html", ".htm"):
            return webbrowser.open("file://" + filepath)
        elif ext in (".bat", ".cmd"):
            cmd = f'"{name}"'
        elif ext == ".sh":
            cmd = f'bash "{name}"'
        else:
            return messagebox.showinfo("Info", f"{_('Неизвестный формат запуска')}: {ext}")
        try:
            if win:
                subprocess.Popen(f'start cmd.exe /k "{cmd}"', shell=True, cwd=wd)
                return
            for term in ("gnome-terminal", "x-terminal-emulator", "konsole", "xterm", "lxterminal"):
                if shutil.which(term):
                    subprocess.Popen([term, "--", "bash", "-c", f"{cmd}; echo; echo '[Finished]'; exec bash"], cwd=wd)
                    return
            messagebox.showerror(_("Ошибка"), _("Не найден эмулятор терминала Linux."))
        except OSError as e:
            messagebox.showerror(_("Ошибка"), str(e))

    # ---------- ИИ по файлу ----------
    def run_mini_ai(self):
        if not self.path:
            return messagebox.showwarning(_("Внимание"), _("Файл не выбран"))
        task = self.mini.get("1.0", "end").strip()
        if not task:
            return
        self.save_file()
        rel, code, mode = self.app.ws.rel(self.path), self.text.get("1.0", "end-1c"), self.ai_mode.get()
        cid = self.app.current_chat_id
        self.mini.delete("1.0", "end")

        def job(agent):
            if mode == "ASK":
                agent.say(cid, f"\n[❓ ASK ({rel})]: {task}\n")
                from core.engine import SYSTEM_ASK
                agent.ask(cid, f"Вопрос ТОЛЬКО по файлу {rel}.\nКод:\n```\n{code}\n```\nВопрос: {task}",
                          system=SYSTEM_ASK, header="🤖 [Ответ]:\n")
            else:
                agent.say(cid, f"\n[⚙️ AGENT ({rel})]: {task}\n")
                prompt = (f"{agent.ws.context(agent.ctx_budget())}\n\nИзмени СТРОГО файл {rel}.\nЗАДАЧА: {task}\n"
                          f"Выведи НОВЫЙ КОД ФАЙЛА ЦЕЛИКОМ:\n```file: {rel}\n<ВЕСЬ КОД>\n```")
                resp = agent.ask(cid, prompt, header="🤖 ")
                agent.apply(cid, resp, files=True, commands=False)
        ok, err = self.app.agent.submit_job(cid, job)
        if not ok:
            messagebox.showinfo("AI-Coder", err)
        elif mode == "ASK":
            self.app.tabview.set(self.app.TAB_CHAT)
