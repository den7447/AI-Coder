"""Подготовка скриншотов для vision-моделей: проверка, поворот по EXIF, уменьшение, base64."""
import base64
import binascii
import io

try:
    from PIL import Image, ImageOps
except ImportError:          # на безголовом сервере Pillow может отсутствовать
    Image = ImageOps = None

MAX_SIDE = 1568
MAX_BYTES = 12_000_000
MAX_IMAGES = 4


def from_pil(img):
    try:
        img = ImageOps.exif_transpose(img)
    except Exception:
        pass
    if max(img.size) > MAX_SIDE:
        img.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        img = bg
    elif img.mode != "RGB":
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, "PNG", optimize=True)          # PNG: текст на скриншотах остаётся чётким
    if buf.tell() > 2_500_000:
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def prepare_bytes(data):
    if len(data) > MAX_BYTES:
        raise ValueError("изображение больше 12 МБ")
    if Image is None:
        return base64.b64encode(data).decode("ascii")
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
    except Exception:
        raise ValueError("это не изображение или формат не поддерживается")
    return from_pil(img)


def prepare_b64(s):
    if "," in s[:100] and s.lstrip().startswith("data:"):
        s = s.split(",", 1)[1]
    try:
        return prepare_bytes(base64.b64decode(s, validate=False))
    except (binascii.Error, ValueError) as e:
        raise ValueError(str(e) or "повреждённые данные изображения")


def prepare_file(path):
    with open(path, "rb") as f:
        return prepare_bytes(f.read())
