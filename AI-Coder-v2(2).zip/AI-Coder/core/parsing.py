"""Разбор ответов ИИ и пользовательских вставок (D-Coder) без обращения к модели."""
import os
import re
from collections import Counter, namedtuple

Block = namedtuple("Block", "kind path body closed")   # kind: file | shell | code

SHELL_LANGS = {"bash", "sh", "shell", "zsh", "cmd", "bat", "batch", "powershell", "ps1", "console"}
FENCE = re.compile(r"^\s*(`{3,})(.*)$")
FILE_INFO = re.compile(r"^(?:[\w+#.-]+\s+)?(?:file|filename|path):\s*(.+)$", re.IGNORECASE)


def parse_blocks(text):
    """Честный разбор ```-блоков (с учётом вложенных), в отличие от жадного регэкспа."""
    lines = text.split("\n")
    blocks, i, n = [], 0, len(lines)
    while i < n:
        m = FENCE.match(lines[i])
        if not m:
            i += 1
            continue
        info = m.group(2).strip()
        i += 1
        body, depth, closed = [], 0, False
        while i < n:
            m2 = FENCE.match(lines[i])
            if m2:
                if m2.group(2).strip() == "":
                    if depth == 0:
                        closed = True
                        break
                    depth -= 1
                else:
                    depth += 1
            body.append(lines[i])
            i += 1
        i += 1
        code = "\n".join(body)
        fm = FILE_INFO.match(info)
        if fm:
            blocks.append(Block("file", fm.group(1).strip().strip("`'\""), code, closed))
        else:
            lang = info.split()[0].lower() if info else ""
            blocks.append(Block("shell" if lang in SHELL_LANGS else "code",
                                "" if lang in SHELL_LANGS else lang, code, closed))
    return blocks


def shell_lines(body):
    out = []
    for raw in body.split("\n"):
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("$ "):
            s = s[2:]
        out.append(s)
    return out


# ---------- структура проекта ----------
KNOWN_NOEXT = {"Dockerfile", "Makefile", "LICENSE", "Procfile", "Gemfile", "README", "CMakeLists.txt"}
_PREFIX = re.compile(r"^([\s│├└─┬┼|`+\\\-—–•*]*)(.*)$")
_COMMENT = re.compile(r"\s{2,}|\s+#|\s+//|\s+<-|\s+←|\s+—|\s+–|\s+-\s|\s+\(")


def parse_structure(text):
    """Дерево (├── / отступы / полные пути) -> список файлов. Пустой список, если не распознано."""
    stack, entries, parents = [], [], set()
    for raw in text.expandtabs(4).splitlines():
        if not raw.strip() or raw.strip().startswith("```"):
            continue
        m = _PREFIX.match(raw)
        prefix, rest = m.group(1), m.group(2)
        rest = _COMMENT.split(rest)[0].strip().strip("`*").rstrip(":").strip()
        if not rest or " " in rest or len(rest) > 120:
            continue
        indent = len(prefix)
        while stack and stack[-1][0] >= indent:
            stack.pop()
        is_dir = rest.endswith("/")
        name = rest.rstrip("/").replace("\\", "/").lstrip("./") if rest not in (".", "./") else ""
        if not name:
            continue
        path = "/".join([s[1] for s in stack] + [name])
        if stack:
            parents.add("/".join(s[1] for s in stack))
        entries.append((path, is_dir))
        stack.append((indent, name))
    files = []
    for path, is_dir in entries:
        base = os.path.basename(path)
        if is_dir or path in parents:
            continue
        if "." in base or base in KNOWN_NOEXT:
            files.append(path)
    return files


# ---------- нарезка кода по файлам ----------
_HDR_LEAD = re.compile(r"^(?:#{1,6}|//+|/\*+|<!--|-{2,}|={2,}|\*+|\d+[.)]|(?:file|filename|файл)\s*:?)\s*", re.IGNORECASE)
_HDR_TAIL = re.compile(r"\s*(?:\*/|-->|-{2,}|={2,}|\*+|:)\s*$")


def _header_candidate(line):
    s = line.strip()
    if not s or len(s) > 200:
        return ""
    for _ in range(3):
        n = _HDR_LEAD.sub("", s, count=1)
        if n == s:
            break
        s = n
    s = _HDR_TAIL.sub("", s).strip().strip("`'\"()[]")
    return s.replace("\\", "/").lstrip("./") if s else ""


def split_sections(content, files):
    """Находит в тексте пользователя код для каждого файла из структуры. -> {путь: код}"""
    # ключи: полный путь и любые его хвосты (src/utils.py, utils.py), если они однозначны
    suffix_count = Counter()
    for f in files:
        parts = f.split("/")
        for k in range(len(parts)):
            suffix_count["/".join(parts[k:])] += 1
    keys = {f: f for f in files}
    for f in files:
        parts = f.split("/")
        for k in range(1, len(parts)):
            suf = "/".join(parts[k:])
            if suffix_count[suf] == 1:
                keys.setdefault(suf, f)

    def header_of(line):
        cand = _header_candidate(line)
        return keys.get(cand)

    sections, cur, buf, fenced, in_fence, depth, tentative = {}, None, [], False, False, 0, False

    def finish():
        nonlocal cur, buf
        if cur and "".join(buf).strip():
            sections[cur] = "\n".join(buf).strip("\n")
        cur, buf = None, []

    for line in content.split("\n"):
        fm = FENCE.match(line)
        if fm:
            info = fm.group(2).strip()
            if not in_fence:
                in_fence, depth = True, 0
                named = None
                if info:
                    fi = FILE_INFO.match(info)
                    cand = (fi.group(1) if fi else info.split()[-1]) if (fi or " " in info) else ""
                    named = keys.get(cand.replace("\\", "/").lstrip("./")) if cand else None
                if named:
                    finish()
                    cur, fenced = named, True
                elif cur is not None and not fenced:
                    fenced = True          # заголовок был до ```
                else:
                    tentative = cur is None
                continue
            if info == "":
                if depth == 0:
                    in_fence, tentative = False, False
                    if fenced:
                        finish()
                    continue
                depth -= 1
            else:
                depth += 1
            buf.append(line) if cur else None
            continue
        if not in_fence:
            h = header_of(line)
            if h:
                finish()
                cur, fenced = h, False
                continue
            if cur is not None and not fenced:
                buf.append(line)
        else:
            if cur is None and tentative and line.strip():
                tentative = False
                h = header_of(line)
                if h:
                    cur, fenced = h, True
                    buf.append(line)
                continue
            if cur is not None:
                buf.append(line)
    finish()
    return sections
