"""Настройки приложения (settings.json). Не зависит от GUI."""
import json
import os
import platform
import secrets
import tempfile
import threading

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IS_WINDOWS = platform.system() == "Windows"

DEFAULTS = {
    "model": "qwen2.5-coder:7b",
    "ollama_host": "http://localhost:11434",
    "device": "gpu",            # auto | gpu | cpu
    "num_ctx": 8192,
    "temperature": 0.2,
    "keep_alive": "30m",        # как долго модель держать в VRAM после ответа
    "num_thread": 0,            # потоки CPU (0 = авто), нужно только для режима CPU
    "plan_depth": "normal",     # short | normal | deep
    "allow_cmd": True,
    "assistant_max_steps": 15,   # лимит шагов автономного ассистента
    "target_os": "auto",          # auto | Windows | Linux | macOS
    "web_access": True,           # ассистент может открывать сайты (OSINT)
    "vision_model": "",           # модель для скриншотов ("" = авто)
    "workspace": "",
    "serve_network": IS_WINDOWS,  # раздавать агента по сети (для телефона)
    "port": 8765,
    "token": "",
}


OS_CHOICES = ["auto", "Linux", "Windows", "macOS"]


def detect_os():
    """-> (имя, подробности): ('Linux', 'Ubuntu 24.04 LTS'), ('Windows', 'Windows 11') и т.п."""
    sysname = platform.system()
    if sysname == "Windows":
        return "Windows", f"Windows {platform.release()}"
    if sysname == "Darwin":
        return "macOS", f"macOS {platform.mac_ver()[0]}".strip()
    detail = "Linux"
    try:
        with open("/etc/os-release", encoding="utf-8") as f:
            for line in f:
                if line.startswith("PRETTY_NAME="):
                    detail = line.split("=", 1)[1].strip().strip('"')
                    break
    except OSError:
        pass
    if "microsoft" in platform.release().lower():
        detail += " (WSL)"
    return "Linux", detail


def effective_os(cfg):
    """ОС, под которую ИИ пишет команды. Возвращает (имя, подробности, определена_автоматически)."""
    choice = cfg.get("target_os")
    name, detail = detect_os()
    if choice in ("Windows", "Linux", "macOS"):
        return choice, (detail if choice == name else choice), False
    return name, detail, True


class Config:
    def __init__(self, path=None):
        self.path = path or os.path.join(APP_DIR, "settings.json")
        self._lock = threading.RLock()
        self._data = dict(DEFAULTS)
        self._listeners = []
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                saved = json.load(f)
            if isinstance(saved, dict):
                self._data.update({k: v for k, v in saved.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass
        if not self._data.get("token"):
            self._data["token"] = secrets.token_urlsafe(18)
            self.save()

    def save(self):
        with self._lock:
            try:
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path), suffix=".tmp")
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(self._data, f, ensure_ascii=False, indent=2)
                os.replace(tmp, self.path)
            except OSError as e:
                print(f"[config] не удалось сохранить: {e}")

    def get(self, key):
        with self._lock:
            return self._data.get(key, DEFAULTS.get(key))

    def set(self, key, value, save=True):
        if key not in DEFAULTS:
            return
        with self._lock:
            if self._data.get(key) == value:
                return
            self._data[key] = value
            if save:
                self.save()
        for fn in list(self._listeners):
            try:
                fn(key, value)
            except Exception:
                pass

    def update(self, values: dict):
        for k, v in values.items():
            self.set(k, v)

    def on_change(self, fn):
        self._listeners.append(fn)

    def regenerate_token(self):
        self.set("token", secrets.token_urlsafe(18))
        return self.get("token")
