"""Рабочая папка проекта: безопасные пути, кэш контекста для ИИ, ZIP."""
import os
import threading
import zipfile

BACKUP_DIR = ".ai_backup"
IGNORE_DIRS = {".git", BACKUP_DIR, "__pycache__", "node_modules", ".venv", "venv", "env",
               "dist", "build", ".idea", ".vscode", ".mypy_cache", ".pytest_cache"}
TEXT_EXT = {".py", ".txt", ".json", ".html", ".css", ".js", ".ts", ".jsx", ".tsx", ".md", ".sh",
            ".bat", ".env", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".c", ".cpp", ".h", ".hpp",
            ".java", ".kt", ".go", ".rs", ".php", ".sql", ".xml", ".vue", ".cs", ".rb", ".lua"}
MAX_FILE_BYTES = 80_000


class Workspace:
    def __init__(self, root):
        self.lock = threading.Lock()
        self._cache = {}          # path -> (mtime, size, text)
        self.set_root(root)

    def set_root(self, root):
        self.root = os.path.abspath(root)
        os.makedirs(self.root, exist_ok=True)
        self._cache.clear()

    @property
    def name(self):
        return os.path.basename(self.root) or self.root

    def resolve(self, rel):
        """Превращает путь от ИИ в абсолютный и не даёт выйти за пределы проекта (../ и т.п.)."""
        rel = (rel or "").strip().strip('"\'`').replace("\\", "/").lstrip("/")
        parts = rel.split("/")
        if len(parts) > 1 and parts[0] == self.name:
            rel = "/".join(parts[1:])
        full = os.path.realpath(os.path.join(self.root, rel))
        root = os.path.realpath(self.root)
        if full != root and not full.startswith(root + os.sep):
            raise ValueError(f"Путь вне проекта: {rel}")
        return full

    def rel(self, full):
        return os.path.relpath(full, self.root).replace(os.sep, "/")

    def _walk(self):
        for cur, dirs, files in os.walk(self.root):
            dirs[:] = sorted(d for d in dirs if d not in IGNORE_DIRS and not d.startswith("."))
            yield cur, dirs, sorted(f for f in files if not f.startswith("."))

    def tree(self, limit=150):
        lines = []
        for cur, _dirs, files in self._walk():
            depth = 0 if cur == self.root else cur[len(self.root):].count(os.sep)
            lines.append("    " * depth + (os.path.basename(cur) or self.name) + "/")
            lines.extend("    " * (depth + 1) + f for f in files)
            if len(lines) > limit:
                lines.append("... (список обрезан)")
                break
        return "\n".join(lines[:limit + 1])

    def entries(self, limit=3000):
        out = []
        for cur, dirs, files in self._walk():
            for d in dirs:
                out.append({"path": self.rel(os.path.join(cur, d)), "dir": True, "size": 0})
            for f in files:
                p = os.path.join(cur, f)
                try:
                    out.append({"path": self.rel(p), "dir": False, "size": os.path.getsize(p)})
                except OSError:
                    pass
            if len(out) >= limit:
                break
        return sorted(out, key=lambda e: (e["path"].count("/"), e["path"]))

    def _read_cached(self, path):
        try:
            st = os.stat(path)
        except OSError:
            return None
        hit = self._cache.get(path)
        if hit and hit[0] == st.st_mtime_ns and hit[1] == st.st_size:
            return hit[2]
        if st.st_size > MAX_FILE_BYTES:
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                text = f.read()
        except (OSError, UnicodeDecodeError):
            return None
        self._cache[path] = (st.st_mtime_ns, st.st_size, text)
        return text

    def context(self, budget_chars):
        """Дерево + содержимое файлов. Свежие файлы идут первыми, всё что не влезло — только именами."""
        files = []
        for cur, _d, names in self._walk():
            for f in names:
                if os.path.splitext(f)[1].lower() in TEXT_EXT:
                    p = os.path.join(cur, f)
                    try:
                        files.append((os.path.getmtime(p), p))
                    except OSError:
                        pass
        files.sort(reverse=True)
        used, parts, skipped = 0, [], []
        for _m, p in files:
            text = self._read_cached(p)
            if text is None:
                skipped.append(self.rel(p))
                continue
            block = f"--- ФАЙЛ: {self.rel(p)} ---\n{text}\n--- КОНЕЦ ФАЙЛА ---\n"
            if used + len(block) > budget_chars:
                skipped.append(self.rel(p))
                continue
            used += len(block)
            parts.append(block)
        body = "\n".join(parts) or "(Файлов пока нет)"
        if skipped:
            body += "\n(Не поместились в контекст, содержимое не показано: " + ", ".join(skipped[:40]) + ")"
        return f"СТРУКТУРА ПРОЕКТА:\n{self.tree()}\n\nАКТУАЛЬНОЕ СОДЕРЖИМОЕ ФАЙЛОВ:\n{body}"

    def read_text(self, rel, limit=400_000):
        full = self.resolve(rel)
        if not os.path.isfile(full) or os.path.getsize(full) > limit:
            raise ValueError("Файл недоступен или слишком большой")
        with open(full, "r", encoding="utf-8") as f:
            return f.read()

    def status(self, rel, content):
        """Что произойдёт при записи: 'created' | 'updated' | 'same' (ничего не пишет)."""
        full = self.resolve(rel)
        if full == os.path.realpath(self.root) or os.path.isdir(full):
            raise ValueError("Это папка, а не файл")
        if not os.path.exists(full):
            return "created"
        try:
            with open(full, "r", encoding="utf-8") as f:
                return "same" if f.read().strip() == content.strip() else "updated"
        except (OSError, UnicodeDecodeError):
            return "updated"

    def write_file(self, rel, content):
        """Возвращает 'created' | 'updated' | 'same'."""
        content = content.strip("\n") + "\n"
        status = self.status(rel, content)
        if status == "same":
            return status
        full = self.resolve(rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
        self._cache.pop(full, None)
        return status

    def zip_to(self, fileobj):
        """Пишет весь проект в ZIP (без служебных папок). Возвращает число файлов."""
        n = 0
        with zipfile.ZipFile(fileobj, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for cur, _d, names in self._walk():
                for f in names:
                    p = os.path.join(cur, f)
                    try:
                        z.write(p, os.path.join(self.name, self.rel(p)))
                        n += 1
                    except OSError:
                        pass
        return n
