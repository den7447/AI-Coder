"""Сборка ядра: общая для окна и безголового режима (--server)."""
import os

from backup_manager import BackupManager

from .config import APP_DIR, Config
from .engine import Agent
from .llm import LLM
from .server import RemoteServer
from .store import ChatStore
from .workspace import BACKUP_DIR, Workspace


class Core:
    pass


def build_core():
    c = Core()
    c.cfg = Config()
    root = c.cfg.get("workspace") or os.path.join(APP_DIR, "Project-AI")
    c.ws = Workspace(root)
    c.store = ChatStore(os.path.join(APP_DIR, "chats.json"))
    c.llm = LLM(c.cfg)
    c.backup = BackupManager(c.ws.root, BACKUP_DIR)
    c.agent = Agent(c.cfg, c.llm, c.store, c.ws, c.backup)
    c.server = RemoteServer(c.agent, c.cfg)
    return c
