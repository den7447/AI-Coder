"""Хранилище чатов. Совместимо со старым chats.json, но пишет редко и атомарно."""
import atexit
import json
import os
import tempfile
import threading
import uuid


class ChatStore:
    def __init__(self, path):
        self.path = path
        self.lock = threading.RLock()
        self.chats = {}
        self.first_run = not os.path.exists(path)
        self._timer = None
        self._dirty = False
        if not self.first_run:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self.chats = data
            except (OSError, ValueError):
                pass
        atexit.register(self.flush)

    # --- сохранение ---
    def save_soon(self, delay=1.0):
        with self.lock:
            self._dirty = True
            if self._timer is None:
                self._timer = threading.Timer(delay, self.flush)
                self._timer.daemon = True
                self._timer.start()

    def flush(self):
        with self.lock:
            self._timer = None
            if not self._dirty:
                return
            self._dirty = False
            try:
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path) or ".", suffix=".tmp")
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(self.chats, f, ensure_ascii=False, separators=(",", ":"))
                os.replace(tmp, self.path)
            except OSError as e:
                print(f"[store] ошибка сохранения: {e}")

    # --- операции ---
    def new(self, title="Новый проект"):
        with self.lock:
            cid = uuid.uuid4().hex[:8]
            self.chats[cid] = {"title": title, "mode": "agent", "messages": [], "history": [], "state": {}}
            self.save_soon()
            return cid

    def delete(self, cid):
        with self.lock:
            self.chats.pop(cid, None)
            self.save_soon()

    def get(self, cid):
        return self.chats.get(cid)

    def first_id(self):
        with self.lock:
            return next(iter(self.chats), None)

    def listing(self):
        with self.lock:
            return [{"id": k, "title": v.get("title", "?"), "mode": v.get("mode", "agent")}
                    for k, v in self.chats.items()]

    def set_field(self, cid, key, value):
        with self.lock:
            if cid in self.chats:
                self.chats[cid][key] = value
                self.save_soon()

    def add_message(self, cid, text):
        with self.lock:
            if cid in self.chats:
                self.chats[cid].setdefault("messages", []).append(text)
                self.save_soon()

    def add_history(self, cid, role, content):
        with self.lock:
            if cid in self.chats:
                self.chats[cid].setdefault("history", []).append({"role": role, "content": content})
                self.save_soon()
