"""Выполнение команд от ИИ с живым выводом, таймаутом и убийством всего дерева процессов."""
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time

from .config import IS_WINDOWS

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

DANGEROUS = re.compile(
    r"(rm\s+-[a-z]*r[a-z]*f?[a-z]*\s+(/|~|\$HOME|\*|/\*)(\s|$)|mkfs\.|dd\s+.*of=/dev/|:\(\)\s*\{|"
    r"\bshutdown\b|\breboot\b|format\s+[a-z]:|del\s+/[a-z]*\s+.*[a-z]:\\\s*$|rd\s+/s\s+/q\s+[a-z]:\\\s*$|"
    r"chmod\s+-R\s+777\s+/\s*$)", re.IGNORECASE)


def is_dangerous(cmd):
    return bool(DANGEROUS.search(cmd))


def _kill_tree(proc):
    try:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True,
                           creationflags=NO_WINDOW)
        else:
            import signal
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass


def run_commands(commands, cwd, on_line, should_stop, timeout=900):
    """Запускает список команд одним скриптом. Возвращает код возврата (None при отмене/таймауте)."""
    tmpdir = tempfile.mkdtemp(prefix="aicoder_")
    try:
        if IS_WINDOWS:
            script = os.path.join(tmpdir, "run.bat")
            with open(script, "w", encoding="utf-8", newline="\r\n") as f:
                f.write("@echo off\r\nchcp 65001 >nul\r\n@echo on\r\n")
                for c in commands:
                    f.write(c + "\r\n")
            argv = ["cmd.exe", "/c", script]
            kw = {"creationflags": NO_WINDOW}
        else:
            script = os.path.join(tmpdir, "run.sh")
            with open(script, "w", encoding="utf-8", newline="\n") as f:
                f.write("#!/bin/bash\nset -x\n")
                for c in commands:
                    f.write(c + "\n")
            os.chmod(script, 0o755)
            argv = [shutil.which("bash") or "sh", script]
            kw = {"start_new_session": True}

        proc = subprocess.Popen(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                stdin=subprocess.DEVNULL, text=True, encoding="utf-8",
                                errors="replace", bufsize=1, **kw)
        killed = {"flag": False}

        def watchdog():
            start = time.time()
            while proc.poll() is None:
                if should_stop() or time.time() - start > timeout:
                    killed["flag"] = True
                    _kill_tree(proc)
                    return
                time.sleep(0.2)

        threading.Thread(target=watchdog, daemon=True).start()
        for line in proc.stdout:
            on_line(line)
        code = proc.wait()
        return None if killed["flag"] else code
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
