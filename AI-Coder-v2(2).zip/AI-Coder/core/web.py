"""Открытие сайтов для ИИ (OSINT по открытым источникам): страница, заголовки, TLS, ссылки, e-mail, поиск.
Только http/https, внутренние адреса запрещены (защита от SSRF), размер и время ограничены."""
import html
import ipaddress
import re
import socket
import ssl
import urllib.parse
from html.parser import HTMLParser

import requests

ALLOW_PRIVATE = False        # только для тестов
UA = "Mozilla/5.0 (compatible; AI-Coder/2.0)"
MAX_BYTES = 1_500_000
TIMEOUT = 15
CGNAT = ipaddress.ip_network("100.64.0.0/10")
SOCIAL = ("twitter.com", "x.com", "facebook.com", "instagram.com", "linkedin.com", "github.com", "gitlab.com",
          "youtube.com", "t.me", "vk.com", "tiktok.com", "reddit.com", "medium.com")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")


class WebError(Exception):
    pass


def normalize(url):
    url = (url or "").strip().strip("`'\"<>")
    if not url:
        raise WebError("пустой адрес")
    if not re.match(r"^[a-z][a-z0-9+.-]*://", url, re.I):
        url = "https://" + url
    p = urllib.parse.urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise WebError("разрешены только http/https адреса")
    return url


def check_host(host):
    if ALLOW_PRIVATE:
        return
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        raise WebError(f"не удалось найти адрес {host}")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0].split("%")[0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast
                or ip.is_unspecified or (ip.version == 4 and ip in CGNAT)):
            raise WebError("адрес во внутренней сети, доступ запрещён")


# ---------- разбор HTML ----------
class _Page(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "template", "iframe"}
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "header",
             "footer", "ul", "ol", "table", "pre", "blockquote"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title, self.meta, self.links, self.parts = "", {}, [], []
        self._skip, self._title, self._href, self._ltext = 0, False, None, []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag in self.SKIP:
            self._skip += 1
        elif tag == "title":
            self._title = True
        elif tag == "meta":
            key = (a.get("name") or a.get("property") or "").lower()
            if key in ("description", "keywords", "author", "generator", "og:title", "og:description",
                       "og:site_name", "twitter:site", "robots") and a.get("content"):
                self.meta[key] = a["content"].strip()[:300]
        elif tag == "a" and a.get("href"):
            self._href, self._ltext = a["href"], []
        if tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1
        elif tag == "title":
            self._title = False
        elif tag == "a" and self._href is not None:
            self.links.append((self._href, " ".join("".join(self._ltext).split())[:80]))
            self._href = None
        if tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self._title:
            self.title += data
            return
        if self._skip:
            return
        self.parts.append(data)
        if self._href is not None:
            self._ltext.append(data)


def _clean_text(parts):
    lines, prev = [], None
    for ln in "".join(parts).split("\n"):
        ln = " ".join(ln.split())
        if ln and ln != prev:
            lines.append(ln)
        prev = ln
    return "\n".join(lines)


def tls_info(host, port=443):
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as s:
                return format_cert(s.getpeercert(), s.version())
    except ssl.SSLCertVerificationError as e:
        return f"сертификат НЕ прошёл проверку: {e.verify_message}"
    except (OSError, ssl.SSLError) as e:
        return f"не удалось получить: {e}"


def format_cert(cert, version=""):
    def flat(rdns):
        return {k: v for rdn in rdns for k, v in rdn}
    subj, issuer = flat(cert.get("subject", ())), flat(cert.get("issuer", ()))
    sans = [v for k, v in cert.get("subjectAltName", ()) if k == "DNS"]
    out = (f"{version}; выдан для {subj.get('commonName', '?')}; издатель {issuer.get('organizationName') or issuer.get('commonName', '?')}; "
           f"действует {cert.get('notBefore', '?')} - {cert.get('notAfter', '?')}")
    if sans:
        out += "; домены: " + ", ".join(sans[:10]) + (f" (+{len(sans) - 10})" if len(sans) > 10 else "")
    return out


def fetch_page(url, max_chars=6000):
    """-> (отчёт для ИИ, {'title','chars','url'}). Бросает WebError."""
    url = normalize(url)
    sess, chain, resp = requests.Session(), [], None
    try:
        for _hop in range(6):
            check_host(urllib.parse.urlparse(url).hostname)
            resp = sess.get(url, headers={"User-Agent": UA, "Accept": "text/html,text/plain,*/*;q=0.8",
                                          "Accept-Language": "ru,en;q=0.8"},
                            timeout=TIMEOUT, allow_redirects=False, stream=True)
            loc = resp.headers.get("Location")
            if resp.status_code in (301, 302, 303, 307, 308) and loc:
                chain.append(f"{resp.status_code} {url}")
                url = urllib.parse.urljoin(url, loc)
                resp.close()
                continue
            break
        else:
            raise WebError("слишком много редиректов")
        body, size = [], 0
        for chunk in resp.iter_content(65536):
            body.append(chunk)
            size += len(chunk)
            if size >= MAX_BYTES:
                break
        raw = b"".join(body)
        resp.close()
    except requests.exceptions.SSLError as e:
        raise WebError(f"ошибка TLS-сертификата: {str(e)[:150]}")
    except requests.RequestException as e:
        raise WebError(f"не удалось открыть: {str(e)[:150]}")

    h = resp.headers
    ctype = h.get("Content-Type", "").split(";")[0].strip().lower()
    lines = [f"URL: {url}", f"Статус: {resp.status_code} {resp.reason or ''}".strip()]
    if chain:
        lines.append("Редиректы: " + " -> ".join(chain) + f" -> {url}")
    info = [f"{k}: {h[k]}" for k in ("Server", "X-Powered-By", "Content-Type", "Last-Modified", "Via", "X-Generator") if h.get(k)]
    cookies = sorted({c.split("=")[0].strip() for c in h.get("Set-Cookie", "").split(", ") if "=" in c})
    if cookies:
        info.append("Cookie (имена): " + ", ".join(cookies[:8]))
    lines.append("Заголовки: " + "; ".join(info) if info else "Заголовки: -")
    sec = {"HSTS": "Strict-Transport-Security", "CSP": "Content-Security-Policy", "X-Frame-Options": "X-Frame-Options",
           "X-Content-Type-Options": "X-Content-Type-Options"}
    lines.append("Защитные заголовки: " + ", ".join(f"{n}: {'есть' if h.get(k) else 'нет'}" for n, k in sec.items()))
    p = urllib.parse.urlparse(url)
    if p.scheme == "https":
        lines.append("TLS: " + tls_info(p.hostname, p.port or 443))

    meta = {"url": url, "title": "", "chars": 0}
    enc = resp.encoding or "utf-8"
    if ctype.startswith("text/html") or ctype in ("application/xhtml+xml", ""):
        text = raw.decode(enc, errors="replace")
        pg = _Page()
        try:
            pg.feed(text)
        except Exception:
            pass
        title = html.unescape(" ".join(pg.title.split()))
        meta["title"] = title
        lines.append(f"Заголовок страницы: {title or '-'}")
        for k, v in pg.meta.items():
            lines.append(f"Meta {k}: {v}")
        body_text = _clean_text(pg.parts)
        emails = sorted({e for e in EMAIL.findall(body_text + " " + " ".join(l for l, _t in pg.links)) if not re.search(r"\.(png|jpe?g|gif|webp|svg)$", e, re.I)})
        if emails:
            lines.append("Найденные e-mail: " + ", ".join(emails[:15]))
        abs_links, social = [], set()
        for href, txt in pg.links:
            if href.startswith(("#", "javascript:", "mailto:", "tel:")):
                continue
            full = urllib.parse.urljoin(url, href)
            host = (urllib.parse.urlparse(full).hostname or "").lower()
            if any(host == s or host.endswith("." + s) for s in SOCIAL):
                social.add(full)
            abs_links.append((full, txt, host != (p.hostname or "").lower()))
        if social:
            lines.append("Соцсети/профили: " + ", ".join(sorted(social)[:10]))
        ext = len({u for u, _t, e in abs_links if e})
        lines.append(f"Ссылок: {len(abs_links)}, внешних: {ext}")
        seen, shown = set(), []
        for full, txt, external in abs_links:
            if full in seen:
                continue
            seen.add(full)
            shown.append(f"  {'[внешняя] ' if external else ''}{txt or '-'} -> {full}")
            if len(shown) >= 25:
                break
        if shown:
            lines.append("Ссылки (первые 25):\n" + "\n".join(shown))
    elif ctype.startswith("text/") or ctype in ("application/json", "application/xml", "application/javascript"):
        body_text = raw.decode(enc, errors="replace").strip()
    else:
        return "\n".join(lines + [f"Бинарный контент ({ctype or 'тип неизвестен'}, {size} байт), текст не извлекается."]), meta

    meta["chars"] = len(body_text)
    cut = body_text[:max_chars]
    lines.append(f"Текст страницы ({len(cut)} из {len(body_text)} символов):\n{cut}")
    return "\n".join(lines), meta


# ---------- поиск ----------
def parse_ddg(page):
    results = []
    anchors = list(re.finditer(r"<a\s([^>]*)>(.*?)</a>", page, re.S))
    for i, m in enumerate(anchors):
        attrs = m.group(1)
        if "result__a" not in attrs:
            continue
        href = re.search(r'href="([^"]+)"', attrs)
        if not href:
            continue
        link = html.unescape(href.group(1))
        if link.startswith("//"):
            link = "https:" + link
        q = urllib.parse.parse_qs(urllib.parse.urlparse(link).query)
        if "uddg" in q:
            link = q["uddg"][0]
        title = html.unescape(re.sub(r"<[^>]+>", "", m.group(2))).strip()
        snippet = ""
        for nxt in anchors[i + 1:i + 4]:
            if "result__snippet" in nxt.group(1):
                snippet = html.unescape(re.sub(r"<[^>]+>", "", nxt.group(2))).strip()
                break
        results.append({"title": title, "url": link, "snippet": snippet})
    return results


def search(query, n=8):
    query = (query or "").strip()
    if not query:
        raise WebError("пустой поисковый запрос")
    try:
        r = requests.post("https://html.duckduckgo.com/html/", data={"q": query}, headers={"User-Agent": UA}, timeout=TIMEOUT)
        r.raise_for_status()
    except requests.RequestException as e:
        raise WebError(f"поиск недоступен: {str(e)[:120]}")
    res = parse_ddg(r.text)[:n]
    if not res:
        raise WebError("поиск не вернул результатов (возможно, временная блокировка)")
    return "\n".join(f"{i}. {x['title']}\n   {x['url']}\n   {x['snippet']}" for i, x in enumerate(res, 1))
