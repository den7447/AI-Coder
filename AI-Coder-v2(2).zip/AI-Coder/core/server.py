"""Мини-сервер для телефона: веб-клиент + API + поток событий. Только стандартная библиотека."""
import hmac
import ipaddress
import json
import os
import queue
import socket
import tempfile
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import images as imgs
from .config import APP_DIR

WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")
MODES = {"agent", "query", "assistant", "dcoder"}
CGNAT = ipaddress.ip_network("100.64.0.0/10")     # Tailscale и подобные


def lan_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(i for i in ips if not i.startswith("127."))


def client_allowed(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_loopback or a.is_private or a.is_link_local or (a.version == 4 and a in CGNAT)


class RemoteServer:
    def __init__(self, agent, cfg):
        self.agent, self.cfg = agent, cfg
        self.httpd = None
        self.thread = None
        self.fails = {}          # ip -> [count, window_start]
        self.error = ""

    @property
    def running(self):
        return self.httpd is not None

    def urls(self):
        port, tok = self.cfg.get("port"), self.cfg.get("token")
        return [f"http://{ip}:{port}/?t={tok}" for ip in lan_ips()] or [f"http://localhost:{port}/?t={tok}"]

    def start(self):
        if self.httpd:
            return True
        outer = self

        class Handler(_Handler):
            srv = outer

        try:
            self.httpd = ThreadingHTTPServer(("0.0.0.0", int(self.cfg.get("port"))), Handler)
        except OSError as e:
            self.httpd, self.error = None, f"Порт {self.cfg.get('port')} занят или недоступен: {e}"
            return False
        self.httpd.daemon_threads = True
        self.error = ""
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        return True

    def stop(self):
        if self.httpd:
            threading.Thread(target=self.httpd.shutdown, daemon=True).start()
            self.httpd.server_close()
            self.httpd = None

    # --- защита от подбора токена ---
    def locked(self, ip):
        f = self.fails.get(ip)
        return bool(f and f[0] >= 8 and time.time() - f[1] < 60)

    def fail(self, ip):
        f = self.fails.get(ip)
        if not f or time.time() - f[1] > 60:
            self.fails[ip] = [1, time.time()]
        else:
            f[0] += 1


class _Handler(BaseHTTPRequestHandler):
    srv = None
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    # --- утилиты ---
    @property
    def agent(self):
        return self.srv.agent

    def _send(self, code, body=b"", ctype="application/json", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        elif isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _authorized(self, allow_query):
        ip = self.client_address[0]
        if not client_allowed(ip):
            self._send(403, {"error": "Доступ только из локальной сети"})
            return False
        if self.srv.locked(ip):
            self._send(429, {"error": "Слишком много попыток, подождите минуту"})
            return False
        token = self.srv.cfg.get("token")
        given = ""
        h = self.headers.get("Authorization", "")
        if h.startswith("Bearer "):
            given = h[7:]
        elif allow_query:
            given = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query).get("t", [""])[0]
        if given and hmac.compare_digest(given.encode(), token.encode()):
            return True
        self.srv.fail(ip)
        self._send(401, {"error": "Неверный токен"})
        return False

    def _json_body(self, limit=2_000_000):
        n = int(self.headers.get("Content-Length") or 0)
        if n > limit:
            raise ValueError("слишком большой запрос")
        return json.loads(self.rfile.read(n) or b"{}")

    # --- GET ---
    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        path, q = url.path, urllib.parse.parse_qs(url.query)
        if path in ("/", "/index.html"):
            return self._file(os.path.join(WEB_DIR, "index.html"), "text/html; charset=utf-8")
        if path == "/manifest.json":
            return self._send(200, {"name": "AI-Coder", "short_name": "AI-Coder", "start_url": "/",
                                    "display": "standalone", "background_color": "#0d1117",
                                    "theme_color": "#0d1117",
                                    "icons": [{"src": "/icon.png", "sizes": "512x512", "type": "image/png"}]},
                              "application/manifest+json")
        if path == "/icon.png":
            return self._file(os.path.join(APP_DIR, "icon.png"), "image/png")
        if not path.startswith("/api/"):
            return self._send(404, {"error": "not found"})
        if not self._authorized(allow_query=True):
            return
        a = self.agent
        if path == "/api/state":
            snap = a.snapshot()
            snap["models"] = a.llm.models()
            return self._send(200, snap)
        if path == "/api/chat":
            c = a.store.get(q.get("id", [""])[0])
            if not c:
                return self._send(404, {"error": "нет такого чата"})
            return self._send(200, {"title": c["title"], "mode": c.get("mode", "agent"),
                                    "text": "".join(c.get("messages", []))})
        if path == "/api/tree":
            return self._send(200, a.ws.entries())
        if path == "/api/file":
            try:
                return self._send(200, a.ws.read_text(q.get("path", [""])[0]), "text/plain; charset=utf-8")
            except (ValueError, OSError, UnicodeDecodeError) as e:
                return self._send(404, {"error": str(e)})
        if path == "/api/zip":
            return self._zip()
        if path == "/api/events":
            return self._events()
        self._send(404, {"error": "not found"})

    def _file(self, p, ctype):
        try:
            with open(p, "rb") as f:
                self._send(200, f.read(), ctype)
        except OSError:
            self._send(404, {"error": "not found"})

    def _zip(self):
        with tempfile.TemporaryFile() as tmp:
            self.agent.ws.zip_to(tmp)
            size = tmp.tell()
            tmp.seek(0)
            name = urllib.parse.quote(self.agent.ws.name + ".zip")
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{name}")
            self.end_headers()
            while True:
                chunk = tmp.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)

    def _events(self):
        q = queue.Queue(maxsize=8000)

        def push(ev):
            try:
                q.put_nowait(ev)
            except queue.Full:
                pass
        unsub = self.agent.bus.subscribe(push)
        self.close_connection = True
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            push({"t": "state", **{k: v for k, v in self.agent.snapshot().items() if k in
                                   ("running", "cid", "mode", "step", "paused")}})
            while True:
                try:
                    ev = q.get(timeout=15)
                except queue.Empty:
                    self.wfile.write(b": ping\n\n")
                    self.wfile.flush()
                    continue
                batch = [ev]
                while True:               # склеиваем подряд идущие куски текста
                    try:
                        nxt = q.get_nowait()
                    except queue.Empty:
                        break
                    last = batch[-1]
                    if nxt.get("t") == "append" and last.get("t") == "append" and nxt.get("cid") == last.get("cid"):
                        last["text"] += nxt["text"]
                    else:
                        batch.append(nxt)
                for e in batch:
                    self.wfile.write(b"data: " + json.dumps(e, ensure_ascii=False).encode() + b"\n\n")
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, OSError):
            pass
        finally:
            unsub()

    # --- POST (только заголовок Authorization, так что чужой сайт в браузере запрос не отправит) ---
    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if not self._authorized(allow_query=False):
            return
        try:
            data = self._json_body(40_000_000 if path == "/api/send" else 2_000_000)
        except (ValueError, json.JSONDecodeError) as e:
            return self._send(400, {"error": str(e)})
        a, cfg = self.agent, self.srv.cfg
        if path == "/api/send":
            mode = data.get("mode", "agent")
            cid = data.get("cid")
            task, task2 = str(data.get("task", ""))[:200_000], str(data.get("task2", ""))[:400_000]
            if mode not in MODES:
                return self._send(400, {"error": "неизвестный режим"})
            images = []
            for raw in (data.get("images") or [])[:imgs.MAX_IMAGES]:
                try:
                    images.append(imgs.prepare_b64(str(raw)))
                except ValueError as e:
                    return self._send(400, {"error": f"изображение отклонено: {e}"})
            if not (task.strip() or task2.strip() or images or (a.store.get(cid) or {}).get("state")):
                return self._send(400, {"error": "пустой запрос"})
            ok, err = a.submit(cid, mode, task.strip(), task2.strip(), images=images)
            return self._send(200 if ok else 409, {"ok": ok, "error": err})
        if path == "/api/stop":
            a.stop()
            return self._send(200, {"ok": True})
        if path == "/api/pause":
            a.pause()
            return self._send(200, {"ok": True})
        if path == "/api/chat/new":
            cid = a.store.new(str(data.get("title") or "Новый проект")[:60])
            a.emit(t="chats")
            return self._send(200, {"cid": cid})
        if path == "/api/chat/delete":
            if a.running_cid == data.get("cid"):
                return self._send(409, {"error": "в этом чате сейчас идёт задача"})
            a.store.delete(data.get("cid"))
            a.emit(t="chats")
            return self._send(200, {"ok": True})
        if path == "/api/rollback":
            ok, msg = a.rollback()
            return self._send(200, {"ok": ok, "message": msg})
        if path == "/api/settings":
            allowed = {"model": str, "device": str, "num_ctx": int, "plan_depth": str, "target_os": str}
            for k, typ in allowed.items():
                if k in data:
                    try:
                        v = typ(data[k])
                    except (TypeError, ValueError):
                        continue
                    if k == "device" and v not in ("auto", "gpu", "cpu"):
                        continue
                    if k == "plan_depth" and v not in ("short", "normal", "deep"):
                        continue
                    if k == "target_os" and v not in ("auto", "Linux", "Windows", "macOS"):
                        continue
                    if k == "num_ctx" and not 1024 <= v <= 131072:
                        continue
                    cfg.set(k, v)
            return self._send(200, {"ok": True})
        self._send(404, {"error": "not found"})
