"""Клиент Ollama: стриминг, выбор CPU/GPU, прогрев модели, диагностика VRAM."""
import json
import os
import re
import shutil
import subprocess
import threading
import time

import requests

NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


class LLMError(Exception):
    pass


def gpu_info():
    """Список NVIDIA-видеокарт через nvidia-smi или None, если его нет."""
    exe = shutil.which("nvidia-smi")
    if not exe:
        return None
    try:
        out = subprocess.check_output(
            [exe, "--query-gpu=name,memory.total,memory.used,utilization.gpu,temperature.gpu",
             "--format=csv,noheader,nounits"],
            text=True, timeout=4, creationflags=NO_WINDOW)
        gpus = []
        for line in out.strip().splitlines():
            name, total, used, util, temp = [x.strip() for x in line.split(",")]
            gpus.append({"name": name, "total_mb": int(total), "used_mb": int(used),
                         "util": int(util), "temp": int(temp)})
        return gpus
    except Exception:
        return None


class LLM:
    def __init__(self, cfg):
        self.cfg = cfg
        self.http = requests.Session()
        self.http.trust_env = False     # системный прокси/VPN не должен перехватывать запросы к локальной Ollama
        self._resp = None
        self._resp_lock = threading.Lock()
        self._vision = {}

    # ---------- сервер ----------
    @property
    def host(self):
        h = (self.cfg.get("ollama_host") or "").strip().rstrip("/")
        if not re.match(r"^https?://", h, re.I):
            h = "http://" + h
        # на Windows localhost часто сначала пробует IPv6 и теряет секунды/таймаут
        return re.sub(r"^(https?://)localhost(?=[:/]|$)", r"\g<1>127.0.0.1", h, flags=re.I)

    def alive(self):
        try:
            return self.http.get(self.host + "/api/version", timeout=3).status_code == 200
        except requests.RequestException:
            return False

    def ensure_server(self, wait=10):
        """Если Ollama не запущена, пробуем поднять её сами (с ускорением памяти)."""
        if self.alive():
            return True
        exe = shutil.which("ollama")
        if not exe:
            return False
        env = dict(os.environ)
        env.setdefault("OLLAMA_FLASH_ATTENTION", "1")
        env.setdefault("OLLAMA_KV_CACHE_TYPE", "q8_0")
        try:
            subprocess.Popen([exe, "serve"], env=env, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
        except OSError:
            return False
        end = time.time() + wait
        while time.time() < end:
            if self.alive():
                return True
            time.sleep(0.4)
        return False

    def list_models(self):
        """-> (список имён, текст ошибки или ''). Ошибка нужна, чтобы показать пользователю причину."""
        try:
            r = self.http.get(self.host + "/api/tags", timeout=(3, 10))
            r.raise_for_status()
            names = [m.get("name") or m.get("model") for m in r.json().get("models", [])]
            return [n for n in names if n], ""
        except requests.ConnectionError:
            return [], f"Ollama не отвечает на {self.host}. Она запущена?"
        except requests.Timeout:
            return [], f"Ollama на {self.host} не ответила вовремя"
        except (requests.RequestException, ValueError) as e:
            return [], f"Ошибка запроса к Ollama: {str(e)[:120]}"

    def models(self):
        return self.list_models()[0]

    def supports_vision(self, model):
        """Понимает ли модель изображения (по данным Ollama, иначе по имени)."""
        if model in self._vision:
            return self._vision[model]
        try:
            j = self.http.post(self.host + "/api/show", json={"model": model}, timeout=8).json()
            caps = j.get("capabilities")
            if isinstance(caps, list):
                val = "vision" in caps
            else:
                val = bool(j.get("projector_info")) or any("vision" in k or "clip" in k for k in j.get("model_info", {}))
        except (requests.RequestException, ValueError):
            val = bool(re.search(r"vision|llava|[-_.]vl\b|minicpm-v|gemma3|moondream", model.lower()))
        self._vision[model] = val
        return val

    def vision_models(self):
        return [m for m in self.models() if self.supports_vision(m)]

    def loaded(self):
        """Какие модели сейчас в памяти и сколько из них в VRAM."""
        try:
            r = self.http.get(self.host + "/api/ps", timeout=3)
            res = []
            for m in r.json().get("models", []):
                size, vram = m.get("size", 0) or 0, m.get("size_vram", 0) or 0
                res.append({"name": m.get("name"), "size": size, "size_vram": vram,
                            "pct_gpu": round(100 * vram / size) if size else 0})
            return res
        except (requests.RequestException, ValueError):
            return []

    def gpu_status(self):
        gpus, loaded = gpu_info(), self.loaded()
        device = self.cfg.get("device")
        warning = None
        if device != "cpu":
            if gpus is None:
                warning = "nvidia-smi не найден: драйвер NVIDIA не установлен или не в PATH"
            else:
                for m in loaded:
                    if m["pct_gpu"] < 90:
                        warning = (f"Модель {m['name']} только на {m['pct_gpu']}% в видеопамяти. "
                                   "Возьмите модель поменьше или уменьшите контекст.")
        return {"gpus": gpus, "loaded": loaded, "device": device, "warning": warning,
                "alive": bool(loaded) or self.alive()}

    # ---------- параметры ----------
    def options(self, force_auto=False):
        o = {"temperature": float(self.cfg.get("temperature")),
             "num_ctx": int(self.cfg.get("num_ctx"))}
        device = "auto" if force_auto else self.cfg.get("device")
        if device == "gpu":
            o["num_gpu"] = 999      # все слои на видеокарту
        elif device == "cpu":
            o["num_gpu"] = 0
        nt = int(self.cfg.get("num_thread") or 0)
        if nt > 0 and device == "cpu":
            o["num_thread"] = nt
        return o

    def warmup(self):
        """Загрузить модель в память заранее, с теми же опциями, чтобы потом не было перезагрузки."""
        try:
            r = self.http.post(self.host + "/api/generate", timeout=300, json={
                "model": self.cfg.get("model"), "prompt": "",
                "keep_alive": self.cfg.get("keep_alive"), "options": self.options()})
            return r.status_code == 200, (r.text[:200] if r.status_code != 200 else "")
        except requests.RequestException as e:
            return False, str(e)

    def unload(self):
        try:
            self.http.post(self.host + "/api/generate", timeout=10,
                           json={"model": self.cfg.get("model"), "prompt": "", "keep_alive": 0})
        except requests.RequestException:
            pass

    # ---------- чат ----------
    def abort(self):
        with self._resp_lock:
            if self._resp is not None:
                try:
                    self._resp.close()
                except Exception:
                    pass

    def stream_chat(self, messages, on_token, should_stop, force_auto=False, model=None):
        payload = {"model": model or self.cfg.get("model"), "messages": messages, "stream": True,
                   "keep_alive": self.cfg.get("keep_alive"), "options": self.options(force_auto)}
        parts, stats = [], {}
        try:
            r = self.http.post(self.host + "/api/chat", json=payload, stream=True, timeout=(5, 900))
        except requests.RequestException as e:
            raise LLMError(f"Нет связи с Ollama ({self.host}): {e}")
        with self._resp_lock:
            self._resp = r
        try:
            if r.status_code != 200:
                raise LLMError(f"Ollama вернула {r.status_code}: {r.text[:300]}")
            for raw in r.iter_lines():
                if should_stop():
                    break
                if not raw:
                    continue
                try:
                    obj = json.loads(raw)
                except ValueError:
                    continue
                if obj.get("error"):
                    raise LLMError(str(obj["error"]))
                piece = (obj.get("message") or {}).get("content", "")
                if piece:
                    parts.append(piece)
                    on_token(piece)
                if obj.get("done"):
                    ec, ed = obj.get("eval_count"), obj.get("eval_duration")
                    if ec and ed:
                        stats["tps"] = round(ec / (ed / 1e9), 1)
        except requests.RequestException as e:
            if not should_stop():
                raise LLMError(f"Обрыв связи с Ollama: {e}")
        finally:
            with self._resp_lock:
                self._resp = None
            r.close()
        return "".join(parts), stats
