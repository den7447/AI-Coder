"""Ядро агента. Не знает про окна: события уходят в шину, а окно и телефон их показывают."""
import os
import re
import threading
import time
import traceback

from . import web
from .config import effective_os
from .llm import LLMError
from .parsing import parse_blocks, shell_lines
from .runner import is_dangerous, run_commands
from .workspace import BACKUP_DIR

SYSTEM_PROMPT = (
    "Ты сильный программист-ассистент в среде разработки AI-Coder. Отвечай на языке пользователя, по делу. "
    "Чтобы создать или изменить файл, выводи ПОЛНЫЙ код файла в блоке:\n"
    "```file: путь/к/файлу.ext\n<код>\n```\n"
    "Команды терминала пиши только в блоках ```{fence} (ОС пользователя: {os}). "
    "Никаких заглушек вроде «остальной код без изменений».")
SYSTEM_ASK = "Ты ИИ-консультант по программированию. Отвечай прямо и понятно, на языке пользователя."


class Bus:
    def __init__(self):
        self._subs, self._lock = [], threading.Lock()

    def subscribe(self, fn):
        with self._lock:
            self._subs.append(fn)

        def unsubscribe():
            with self._lock:
                if fn in self._subs:
                    self._subs.remove(fn)
        return unsubscribe

    def emit(self, **ev):
        with self._lock:
            subs = list(self._subs)
        for fn in subs:
            try:
                fn(ev)
            except Exception:
                pass


class Agent:
    def __init__(self, cfg, llm, store, ws, backup):
        self.cfg, self.llm, self.store, self.ws, self.backup = cfg, llm, store, ws, backup
        self.bus = Bus()
        self._cancel, self._pause = threading.Event(), threading.Event()
        self._run_lock = threading.Lock()
        self.running_cid = self.running_mode = None
        self.step = ""
        self.tps = None
        self.last_gpu = None
        self.changed = set()
        self._backed_up = False
        self._monitor = None
        self.run_images = []          # картинки, которые модель видит напрямую в текущем запуске

    # ---------- флаги и события ----------
    @property
    def cancelled(self):
        return self._cancel.is_set()

    @property
    def paused(self):
        return self._pause.is_set()

    @property
    def running(self):
        return self.running_cid is not None

    def emit(self, **ev):
        self.bus.emit(**ev)

    def emit_state(self):
        self.emit(t="state", running=self.running, cid=self.running_cid, mode=self.running_mode,
                  step=self.step, paused=self.paused)

    def set_step(self, text):
        self.step = text
        self.emit_state()

    def say(self, cid, text):
        """Сообщение в чат: сохраняется и показывается."""
        self.store.add_message(cid, text)
        self.emit(t="append", cid=cid, text=text)

    def snapshot(self):
        return {"chats": self.store.listing(), "running": self.running, "cid": self.running_cid,
                "mode": self.running_mode, "step": self.step, "paused": self.paused,
                "model": self.cfg.get("model"), "device": self.cfg.get("device"),
                "num_ctx": self.cfg.get("num_ctx"), "workspace": self.ws.name,
                "gpu": self.last_gpu, "tps": self.tps,
                "target_os": self.cfg.get("target_os"), "os": effective_os(self.cfg)[1]}

    def start_monitor(self, interval=4):
        if self._monitor:
            return

        def loop():
            while True:
                try:
                    self.last_gpu = self.llm.gpu_status()
                    self.emit(t="gpu", data=self.last_gpu)
                except Exception:
                    pass
                time.sleep(interval)
        self._monitor = threading.Thread(target=loop, daemon=True)
        self._monitor.start()

    def system_prompt(self):
        name, detail, _auto = effective_os(self.cfg)
        return SYSTEM_PROMPT.format(fence="bat" if name == "Windows" else "bash", os=detail)

    # ---------- запуск ----------
    def _start(self, cid, mode, job):
        if cid not in self.store.chats:
            return False, "Чат не найден"
        if not self._run_lock.acquire(blocking=False):
            return False, "ИИ уже выполняет другую задачу"
        self._cancel.clear()
        self._pause.clear()
        self.changed, self._backed_up, self.step = set(), False, ""
        self.running_cid, self.running_mode = cid, mode
        threading.Thread(target=self._worker, args=(cid, job), daemon=True).start()
        self.emit_state()
        return True, ""

    def submit(self, cid, mode, task, task2="", images=None):
        chat = self.store.get(cid)
        if not chat:
            return False, "Чат не найден"
        if self.running:
            return False, "ИИ уже выполняет другую задачу"
        images = list(images or [])[:4] if mode != "dcoder" else []
        if images and not task:
            task = "Посмотри на вложенное изображение и помоги."
        self.store.set_field(cid, "mode", mode)
        if chat["title"] in ("Новый чат", "Новый проект") and (task or task2):
            title = (task or task2).strip().replace("\n", " ")
            chat["title"] = title[:22] + ("…" if len(title) > 22 else "")
            self.emit(t="chats")

        def job():
            from modes import agent_mode, ask_mode, assistant_mode, dcoder_mode
            model_task = task
            self.run_images = []
            if task:
                head = "[Структура проекта]:" if mode == "dcoder" else "[Задача]:"
                body = f"{head}\n{task}\n[Содержимое файлов передано]" if mode == "dcoder" else f"{head} {task}"
                self.say(cid, f"\n{'=' * 50}\n{body}\n")
            if images:
                self.say(cid, f"🖼 [Вложено изображений: {len(images)}]\n")
                self.run_images, described = self.resolve_vision(cid, images, task)
                if described:
                    model_task = f"{task}\n\n[Описание вложенного скриншота]:\n{described}"
            if mode == "query":
                ask_mode.run(self, cid, model_task)
            elif mode == "assistant":
                assistant_mode.run(self, cid, model_task)
            elif mode == "dcoder":
                dcoder_mode.run(self, cid, task, task2)
            else:
                agent_mode.run(self, cid, model_task)
        return self._start(cid, mode, job)

    # ---------- картинки ----------
    def resolve_vision(self, cid, images, task):
        """-> (картинки для прямой передачи, текстовое описание). Либо одно, либо другое, либо пусто."""
        main, chosen = self.cfg.get("model"), (self.cfg.get("vision_model") or "").strip()
        if not chosen and self.llm.supports_vision(main):
            return images, ""
        candidate = chosen or next(iter(self.llm.vision_models()), "")
        if candidate == main and self.llm.supports_vision(main):
            return images, ""
        if not candidate:
            self.say(cid, f"⚠️ Модель {main} не умеет смотреть картинки, и подходящей vision-модели не найдено. "
                          "Скачайте любую (например `ollama pull qwen2.5vl:7b` или `gemma3:4b`), "
                          "изображение пока проигнорировано.\n")
            return [], ""
        self.say(cid, f"🖼 [Распознаю изображение моделью {candidate}, затем передам описание {main}]\n")
        prompt = ("Ты описываешь изображение для программиста. Перепиши ВЕСЬ видимый текст дословно (особенно "
                  "сообщения об ошибках, код, логи, адреса, названия файлов), затем опиши элементы интерфейса и "
                  f"их состояние. Не выдумывай то, чего не видно.\nЗапрос пользователя: {task}")
        msgs = [{"role": "user", "content": prompt, "images": images}]
        self.emit(t="append", cid=cid, text="🤖 [Описание вложения]:\n")
        text, _stats = self.llm.stream_chat(msgs, lambda p: self.emit(t="append", cid=cid, text=p),
                                            lambda: self.cancelled, model=candidate)
        self.emit(t="append", cid=cid, text="\n")
        self.store.add_message(cid, "🤖 [Описание вложения]:\n" + text + "\n")
        return [], text.strip()

    # ---------- сайты ----------
    def open_url(self, cid, url):
        if not self.cfg.get("web_access"):
            return "Доступ к сайтам выключен в настройках (Настройки → Агент)."
        self.say(cid, f"🌐 [Открываю] {url}\n")
        try:
            report, meta = web.fetch_page(url)
        except web.WebError as e:
            self.say(cid, f"⚠️ [Сайт] {e}\n")
            return f"Ошибка: {e}"
        self.say(cid, f"🌐 [Получено] {meta['title'] or meta['url']} ({meta['chars']} симв. текста)\n")
        return report

    def web_search(self, cid, query):
        if not self.cfg.get("web_access"):
            return "Доступ к интернету выключен в настройках (Настройки → Агент)."
        self.say(cid, f"🔎 [Поиск] {query}\n")
        try:
            return web.search(query)
        except web.WebError as e:
            self.say(cid, f"⚠️ [Поиск] {e}\n")
            return f"Ошибка: {e}"

    def submit_job(self, cid, fn, mode="agent"):
        """Произвольная задача (например, правка одного файла) через ту же очередь и кнопку «Стоп»."""
        return self._start(cid, mode, lambda: fn(self))

    def _worker(self, cid, job):
        try:
            if not self.llm.ensure_server():
                self.say(cid, "\n❌ [Ошибка] Ollama не запущена и не удалось её запустить. "
                              "Установите Ollama (ollama.com) и запустите её.\n")
                return
            job()
        except LLMError as e:
            self.say(cid, f"\n❌ [Ошибка ИИ]: {e}\n")
        except Exception as e:
            traceback.print_exc()
            self.say(cid, f"\n[Ошибка выполнения]: {e}\n")
        finally:
            self.store.flush()
            self.running_cid = self.running_mode = None
            self.step = ""
            self._run_lock.release()
            self.emit_state()
            self.emit(t="tree")

    def stop(self):
        if not self.running:
            return
        cid = self.running_cid
        self._cancel.set()
        self._pause.clear()
        self.llm.abort()
        self.store.set_field(cid, "state", {})
        self.say(cid, "\n🛑 [Система] Остановлено. Состояние задачи сброшено.\n")

    def pause(self):
        if self.running and not self._pause.is_set():
            self._pause.set()
            self.say(self.running_cid, "\n⏸ [Система] Пауза: дождусь конца текущего шага...\n")
            self.emit_state()

    # ---------- работа с ИИ ----------
    def ctx_budget(self):
        return max(3000, int((int(self.cfg.get("num_ctx")) - 2500) * 2.5))

    def history_text(self, cid, n=6):
        hist = (self.store.get(cid) or {}).get("history", [])[-n:]
        if not hist:
            return ""
        lines = [f"{'Пользователь' if m['role'] == 'user' else 'ИИ (Ты)'}: {m['content']}" for m in hist]
        return "--- ИСТОРИЯ ---\n" + "\n\n".join(lines) + "\n--- КОНЕЦ ИСТОРИИ ---\n\n"

    def history_messages(self, cid, n=8):
        hist = (self.store.get(cid) or {}).get("history", [])[-n:]
        return [{"role": m["role"], "content": m["content"]} for m in hist]

    def remember(self, cid, role, content):
        self.store.add_history(cid, role, content)
        try:
            d = os.path.join(self.ws.root, BACKUP_DIR, "chat_logs")
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, f"{cid}.log"), "a", encoding="utf-8") as f:
                f.write(f"[{role.upper()}]\n{content}\n{'-' * 40}\n")
        except OSError:
            pass

    def ask(self, cid, prompt, system=None, header=None, history=None, images=None):
        """Один запрос к модели. header != None: ответ стримится в чат и сохраняется целиком."""
        user_msg = {"role": "user", "content": prompt}
        if images:
            user_msg["images"] = images
        msgs = [{"role": "system", "content": system or self.system_prompt()}] + (history or []) + [user_msg]
        show = header is not None
        if show:
            self.emit(t="append", cid=cid, text=header)
        on_tok = (lambda p: self.emit(t="append", cid=cid, text=p)) if show else (lambda p: None)
        try:
            text, stats = self.llm.stream_chat(msgs, on_tok, lambda: self.cancelled)
        except LLMError as e:
            if self.cfg.get("device") == "gpu" and re.search(r"memory|cuda|alloc", str(e), re.I):
                self.say(cid, "\n⚠️ Не хватило видеопамяти для режима «только GPU». "
                              "Повторяю в авто-режиме (часть слоёв уйдёт на CPU).\n")
                text, stats = self.llm.stream_chat(msgs, on_tok, lambda: self.cancelled, force_auto=True)
            else:
                raise
        if self.cancelled:
            text += "\n[🛑 ГЕНЕРАЦИЯ ПРЕРВАНА]"
        if show:
            self.emit(t="append", cid=cid, text="\n")
            self.store.add_message(cid, header + text + "\n")
        if stats.get("tps"):
            self.tps = stats["tps"]
            self.emit(t="stats", tps=self.tps)
        return text

    # ---------- применение ответа ----------
    def _ensure_backup(self, cid):
        if not self._backed_up:
            ok, msg = self.backup.create_backup()
            self._backed_up = True
            if ok:
                self.say(cid, "[Система] 📦 Бекап проекта создан (кнопка «Откат кода» вернёт его).\n")

    def apply(self, cid, response, files=True, commands=True, unlabeled_shell=False):
        if self.cancelled or self.paused:
            return
        blocks = parse_blocks(response)
        if files:
            for b in (b for b in blocks if b.kind == "file"):
                if not b.closed:
                    self.say(cid, f"⚠️ [Пропуск] Ответ оборвался на файле {b.path}, не сохраняю обрезанный код.\n")
                    continue
                try:
                    st = self.ws.status(b.path, b.body.strip("\n") + "\n")
                    if st == "same":
                        self.say(cid, f"⚡ [Пропуск] {b.path} без изменений.\n")
                        continue
                    self._ensure_backup(cid)
                    self.ws.write_file(b.path, b.body)
                    self.changed.add(b.path)
                    self.say(cid, ("📝 [Создан] " if st == "created" else "🔄 [Обновлён] ") + b.path + "\n")
                except (ValueError, OSError) as e:
                    self.say(cid, f"❌ [Файл {b.path}]: {e}\n")
            self.emit(t="tree")
        if not commands:
            return
        cmds = []
        for b in blocks:
            if b.kind == "shell" or (unlabeled_shell and b.kind == "code" and not b.path):
                cmds.extend(shell_lines(b.body))
        if cmds:
            self.run_shell(cid, cmds)

    def run_shell(self, cid, cmds, timeout=900):
        """Выполняет команды. Возвращает dict: ran, code, output, blocked, timed_out, disabled."""
        res = {"ran": False, "code": None, "output": "", "blocked": [], "timed_out": False, "disabled": False}
        safe = []
        for c in cmds:
            if is_dangerous(c):
                res["blocked"].append(c)
                self.say(cid, f"🛡️ [Терминал] Опасная команда заблокирована: {c}\n")
            else:
                safe.append(c)
        if not safe:
            return res
        if not self.cfg.get("allow_cmd"):
            res["disabled"] = True
            self.say(cid, "🛑 [Терминал] Выполнение команд выключено в настройках.\n")
            return res
        self.say(cid, f"🚀 [Терминал] Выполняю {len(safe)} команд...\n")
        self.emit(t="cmd_clear")
        lines = []

        def on_line(line):
            if sum(map(len, lines)) < 300_000:
                lines.append(line)
            self.emit(t="cmd", text=line)
        code = run_commands(safe, self.ws.root, on_line, lambda: self.cancelled, timeout)
        res.update(ran=True, code=code, output="".join(lines))
        if code is None:
            res["timed_out"] = not self.cancelled
            self.say(cid, "🛑 [Терминал] Прервано пользователем.\n" if self.cancelled
                     else f"⏱️ [Терминал] Не завершилось за {timeout} с, процесс остановлен.\n")
        else:
            self.say(cid, "✅ [Терминал] Готово.\n" if code == 0 else f"⚠️ [Терминал] Код возврата: {code}\n")
        self.emit(t="tree")
        return res

    def rollback(self):
        ok, msg = self.backup.restore_latest_backup()
        self.emit(t="tree")
        return ok, msg
