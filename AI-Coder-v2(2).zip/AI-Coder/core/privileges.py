"""Запущена ли программа с правами администратора (Windows) или root (Linux/macOS)."""
import os


def is_admin():
    try:
        if os.name == "nt":
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False
