@echo off
REM Start Ollama with flash attention + compact KV cache. Close Ollama in the tray first.
set OLLAMA_FLASH_ATTENTION=1
set OLLAMA_KV_CACHE_TYPE=q8_0
ollama serve
