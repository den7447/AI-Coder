import datetime
import os
import shutil

from core.workspace import IGNORE_DIRS

KEEP_LAST = 10


class BackupManager:
    """Копия проекта перед изменениями ИИ. Пропускает node_modules/venv/.git, хранит последние 10."""

    def __init__(self, workspace_dir, backup_dir=".ai_backup"):
        self.workspace_dir = workspace_dir
        self.backup_dir = backup_dir

    def _root(self):
        return os.path.join(self.workspace_dir, self.backup_dir, "code_backups")

    def _skip(self, name):
        return name in IGNORE_DIRS or name.startswith(".")

    def create_backup(self):
        try:
            root = self._root()
            os.makedirs(root, exist_ok=True)
            dest = os.path.join(root, "backup_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
            os.makedirs(dest)
            for item in os.listdir(self.workspace_dir):
                if self._skip(item):
                    continue
                s, d = os.path.join(self.workspace_dir, item), os.path.join(dest, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, ignore=shutil.ignore_patterns(*IGNORE_DIRS))
                else:
                    shutil.copy2(s, d)
            old = sorted(x for x in os.listdir(root) if os.path.isdir(os.path.join(root, x)))
            for x in old[:-KEEP_LAST]:
                shutil.rmtree(os.path.join(root, x), ignore_errors=True)
            return True, "Бекап создан."
        except Exception as e:
            return False, f"Ошибка при создании бекапа: {e}"

    def restore_latest_backup(self):
        try:
            root = self._root()
            backups = sorted(x for x in os.listdir(root) if os.path.isdir(os.path.join(root, x))) \
                if os.path.exists(root) else []
            if not backups:
                return False, "Нет доступных бекапов."
            latest = os.path.join(root, backups[-1])
            for item in os.listdir(self.workspace_dir):
                if self._skip(item):
                    continue
                p = os.path.join(self.workspace_dir, item)
                shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
            for item in os.listdir(latest):
                s, d = os.path.join(latest, item), os.path.join(self.workspace_dir, item)
                shutil.copytree(s, d) if os.path.isdir(s) else shutil.copy2(s, d)
            return True, f"Восстановлено из бекапа: {backups[-1]}"
        except Exception as e:
            return False, f"Ошибка восстановления: {e}"
