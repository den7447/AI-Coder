import json, os, sys, tempfile, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from core.config import Config
from core.llm import LLM

def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: sys.exit(1)
def free_port():
    import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p

class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        b = json.dumps({"models": [{"name": "llama3:8b", "model": "llama3:8b"}, {"model": "qwen2.5-coder:7b"}, {}]}).encode()
        self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

cfg = Config(os.path.join(tempfile.mkdtemp(), "s.json")); llm = LLM(cfg)
cfg.set("ollama_host", "http://localhost:11434"); ok(llm.host == "http://127.0.0.1:11434", "localhost -> 127.0.0.1 (без IPv6-задержки на Windows)")
cfg.set("ollama_host", "localhost:11434/"); ok(llm.host == "http://127.0.0.1:11434", "адрес без http:// и со слэшем нормализуется")
cfg.set("ollama_host", "http://192.168.1.5:11434"); ok(llm.host == "http://192.168.1.5:11434", "удалённый адрес не трогаем")
ok(llm.http.trust_env is False, "системный прокси/VPN не используется")
os.environ["HTTP_PROXY"] = "http://127.0.0.1:9"; os.environ["HTTPS_PROXY"] = "http://127.0.0.1:9"
port = free_port()
cfg.set("ollama_host", f"http://localhost:{port}")
names, err = llm.list_models(); ok(names == [] and "не отвечает" in err, f"Ollama выключена -> понятная ошибка: {err}")
srv = ThreadingHTTPServer(("127.0.0.1", port), Fake); threading.Thread(target=srv.serve_forever, daemon=True).start()
names, err = llm.list_models()
ok(names == ["llama3:8b", "qwen2.5-coder:7b"] and err == "", f"список моделей читается (даже с HTTP_PROXY в окружении): {names}")
print("\nВСЕ ПРОВЕРКИ ВЫБОРА МОДЕЛЕЙ ПРОЙДЕНЫ")
