"""Дымовой тест GUI на заглушках tkinter/customtkinter: ловит NameError/AttributeError и проверяет разметку чата."""
import os, sys, types, tempfile, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

class W:
    def __init__(self, *a, **k): self._k = k; self.image = None
    def __getattr__(self, n):
        if n.startswith("__"): raise AttributeError(n)
        return lambda *a, **k: W()
    def winfo_exists(self): return True
    def winfo_children(self): return []
    def winfo_x(self): return 0
    winfo_y = winfo_x
    def winfo_width(self): return 1000
    winfo_height = winfo_width
    def winfo_screenwidth(self): return 1920
    winfo_screenheight = winfo_screenwidth
    def get(self, *a, **k): return ""
    def cget(self, k): return ""
    def index(self, i): return "1.0"
    def yview(self, *a): return (0.0, 1.0)
    def children(self): return []
    def get_children(self, *a): return []
    def selection(self): return []
    def exists(self, i): return False
    def get_input(self): return None
    def after(self, ms, fn=None, *a): return "job"

class Text(W):
    def __init__(self, *a, **k):
        super().__init__(*a, **k); self.buf = []; self.tags = {}
    def insert(self, idx, s, tag=None):
        if idx == "end" and tag: self.buf.append((s, tag))
    def delete(self, a, b=None):
        if a == "live_start": self.live_deleted = True
        if a == "1.0": self.buf = []

tk = types.ModuleType("tkinter"); tk.Text = Text; tk.TclError = Exception
tk.PhotoImage = W; tk.Menu = W; tk.Tk = W; tk.Toplevel = W; tk.StringVar = W; tk.BooleanVar = W
ttk = types.ModuleType("tkinter.ttk"); ttk.Style = W; ttk.Treeview = W; ttk.Scrollbar = W
tkfont = types.ModuleType("tkinter.font"); tkfont.families = lambda root=None: ["Segoe UI", "Consolas"]
mb = types.ModuleType("tkinter.messagebox")
for n in ("showinfo", "showwarning", "showerror"): setattr(mb, n, lambda *a, **k: None)
mb.askyesno = lambda *a, **k: True
fd = types.ModuleType("tkinter.filedialog"); fd.askdirectory = lambda **k: ""; fd.askopenfilenames = lambda **k: ()
tk.ttk, tk.messagebox, tk.filedialog, tk.font = ttk, mb, fd, tkfont
ctk = types.ModuleType("customtkinter")
class CTk(W):
    pass
for n in ("CTkFrame CTkLabel CTkButton CTkToplevel CTkTextbox CTkScrollableFrame CTkScrollbar CTkTabview "
          "CTkSegmentedButton CTkComboBox CTkOptionMenu CTkProgressBar CTkSwitch CTkEntry CTkSlider CTkInputDialog CTkImage").split():
    setattr(ctk, n, type(n, (W,), {}))
ctk.CTk = CTk
ctk.CTkTabview = type("CTkTabview", (W,), {"add": lambda self, n: W()})
ctk.StringVar = ctk.BooleanVar = lambda **k: types.SimpleNamespace(get=lambda: k.get("value"), set=lambda v: None)
for name, mod in {"tkinter": tk, "tkinter.ttk": ttk, "tkinter.font": tkfont, "tkinter.messagebox": mb,
                  "tkinter.filedialog": fd, "customtkinter": ctk}.items():
    sys.modules[name] = mod

from core.bootstrap import build_core
import core.config as cc
tmp = tempfile.mkdtemp()
cc.APP_DIR = tmp
import core.bootstrap as bs
bs.APP_DIR = tmp
os.chdir(tmp)
# настройки/чаты во временной папке
import core.config
core.config.Config.__init__.__defaults__ = (os.path.join(tmp, "settings.json"),)
core_obj = build_core()

import gui
app = gui.App(core_obj)
print("App создан")
app.chat.buf.clear()
app._partial = ""
sample = ("\n" + "=" * 50 + "\n[Задача]: сделай игру\nвторая строка задачи\n[🤖 АГЕНТ] Запуск\n📋 [ПЛАН ПРОЕКТА]:\n1. шаг\n"
          "\n⚙️ [ШАГ 1/2]: файл\n🤖 Создаю:\n```file: a.py\nprint(1)\n```\n📝 [Создан] a.py\n❌ ошибка\n")
# имитация стрима кусочками
for i in range(0, len(sample), 5):
    app.chat_write(sample[i:i + 5])
tags = [t for _s, t in app.chat.buf]
print("теги:", tags)
assert "user" in tags and "step" in tags and "plan" in tags and "codehead" in tags and "code" in tags
assert "ok" in tags and "bad" in tags and "sys" in tags
text = "".join(s for s, t in app.chat.buf if t == "code")
assert "print(1)" in text and "```" not in text
user_text = "".join(s for s, t in app.chat.buf if t == "user")
assert "вторая строка задачи" in user_text, user_text
print("разметка чата OK")
app.refresh_tree(); app.refresh_chat_list(); app.switch_chat(app.store.first_id())
app.update_state({"running": True, "step": "1/3", "cid": app.current_chat_id}); app.update_state({"running": False})
app.update_gpu_chip({"device": "gpu", "gpus": [{"name": "RTX 5060", "used_mb": 5000, "total_mb": 8151}],
                     "loaded": [{"pct_gpu": 100}], "warning": None})
app.update_gpu_chip({"device": "gpu", "gpus": None, "loaded": [], "warning": "x"})
app.update_net_chip(); app.on_device("CPU"); app.on_model("llama3:8b"); app.sync_device_widget()
app.on_mode_change("🎯 D-Coder"); app.on_mode_change("🤖 Агент")
for ev in ({"t": "append", "cid": app.current_chat_id, "text": "hi\n"}, {"t": "cmd", "text": "x\n"}, {"t": "cmd_clear"},
           {"t": "stats", "tps": 55}, {"t": "tree"}, {"t": "chats"}, {"t": "toast", "text": "t"}):
    app._handle(ev)
app.open_license_window(); app.open_help_window(); app.open_mini_browser()
import settings_ui
for tab in (None, "gpu", "net", "agent", "lang"):
    app._settings_win = None
    settings_ui.open_settings(app, tab)
app.editor.save_file(); app.editor.run_project(); app.editor.reload_if_changed()
app.attach_files(); app.attach_clipboard(); app.attach_screenshot()
from core import images as _im
import io as _io, base64 as _b64
from PIL import Image as _I
_b=_io.BytesIO(); _I.new("RGB",(30,30),"red").save(_b,"PNG")
app._add_attachment("a.png", _im.prepare_bytes(_b.getvalue())); assert len(app.attached)==1
app.prompt_entry.get = lambda *a: "смотри скриншот"
app.start_agent(); assert app.attached == [], "вложения очищаются после отправки"
import time as _t
for _ in range(100):
    if not app.agent.running: break
    _t.sleep(0.05)
app.cfg.set("target_os", "Windows"); settings_ui.open_settings(app, "agent")
app._on_models({"models": [], "err": "Ollama не отвечает", "announce": False}); assert app._retry_job is not None
app._on_models({"models": ["a:1", "b:2"], "err": "", "announce": True}); assert app._retry_job is None and app.models == ["a:1", "b:2"]
assert app.cfg.get("model") == "a:1", "модели по умолчанию нет в списке -> взята первая установленная"
app.on_model("b:2"); assert app.cfg.get("model") == "b:2"; app.on_model("   "); assert app.cfg.get("model") == "b:2"
app.on_model("ручная:модель"); assert app.cfg.get("model") == "ручная:модель", "ручной ввод имени работает"
app.refresh_models(True); app._retry_models()
app.rollback_wrapper(); app.delete_chat(app.current_chat_id); app.on_close()
print("ВСЕ ВЫЗОВЫ GUI ПРОШЛИ БЕЗ ИСКЛЮЧЕНИЙ")
shutil.rmtree(tmp, ignore_errors=True)
