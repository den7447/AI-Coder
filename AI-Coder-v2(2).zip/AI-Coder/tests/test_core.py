import io, json, os, sys, tempfile, threading, time, zipfile, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core.config import Config
from core.llm import LLM
from core.store import ChatStore
from core.workspace import Workspace
from core.engine import Agent
from core.server import RemoteServer
from backup_manager import BackupManager

SEEN = {"options": []}

class FakeOllama(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _j(self, obj, code=200):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/api/version": return self._j({"version": "0.test"})
        if self.path == "/api/tags": return self._j({"models": [{"name": "qwen2.5-coder:7b"}, {"name": "llama3:8b"}]})
        if self.path == "/api/ps": return self._j({"models": [{"name": "qwen2.5-coder:7b", "size": 5000, "size_vram": 5000}]})
        self._j({}, 404)
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/api/generate": return self._j({"done": True})
        SEEN["options"].append(body["options"])
        user = body["messages"][-1]["content"]
        if "пошаговый план" in user:
            ans = "1. Создать hello.py\n2. Запустить его\n"
        elif "Выполни шаг 1" in user:
            ans = ("Создаю файл.\n```file: hello.py\nprint('привет')\n```\n"
                   "Ещё попытка выйти за проект:\n```file: ../evil.txt\nx\n```\n")
        elif "Выполни шаг 2" in user:
            ans = "Запускаю.\n```bash\npython3 hello.py\nrm -rf /\n```\nКонец пояснения, это не команда.\n```file: cut.py\nprint(1)\n"
        else:
            ans = "Просто ответ."
        self.send_response(200); self.send_header("Content-Type", "application/x-ndjson")
        self.send_header("Transfer-Encoding", "chunked"); self.end_headers()
        def chunk(d):
            data = (json.dumps(d) + "\n").encode()
            self.wfile.write(f"{len(data):x}\r\n".encode() + data + b"\r\n")
        for i in range(0, len(ans), 7):
            chunk({"message": {"content": ans[i:i+7]}, "done": False}); time.sleep(0.002)
        chunk({"message": {"content": ""}, "done": True, "eval_count": 100, "eval_duration": 2_000_000_000})
        self.wfile.write(b"0\r\n\r\n")

def free_port():
    import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p

def main():
    ok = lambda c, m: (print(("PASS " if c else "FAIL ") + m), c or sys.exit(1))
    fp = free_port()
    threading.Thread(target=ThreadingHTTPServer(("127.0.0.1", fp), FakeOllama).serve_forever, daemon=True).start()
    tmp = tempfile.mkdtemp()
    cfg = Config(os.path.join(tmp, "settings.json"))
    cfg.set("ollama_host", f"http://127.0.0.1:{fp}"); cfg.set("device", "gpu"); cfg.set("port", free_port())
    store = ChatStore(os.path.join(tmp, "chats.json"))
    ws = Workspace(os.path.join(tmp, "proj"))
    agent = Agent(cfg, LLM(cfg), store, ws, BackupManager(ws.root))
    open(os.path.join(ws.root, "old.py"), "w").write("old")
    events = []; agent.bus.subscribe(events.append)
    cid = store.new()

    # --- агент ---
    ok(agent.submit(cid, "agent", "сделай hello")[0], "агент запущен")
    ok(not agent.submit(cid, "agent", "ещё")[0], "второй запуск отклонён пока занят")
    for _ in range(300):
        if not agent.running: break
        time.sleep(0.05)
    ok(not agent.running, "агент завершился")
    ok(open(os.path.join(ws.root, "hello.py"), encoding="utf-8").read().strip() == "print('привет')", "файл создан")
    ok(not os.path.exists(os.path.join(tmp, "evil.txt")), "выход за пределы проекта заблокирован")
    ok(not os.path.exists(os.path.join(ws.root, "cut.py")), "обрезанный блок файла не записан")
    text = "".join(store.get(cid)["messages"])
    ok("привет" in open(os.path.join(ws.root, "hello.py"), encoding="utf-8").read(), "кириллица ок")
    ok("Опасная команда заблокирована: rm -rf /" in text, "rm -rf / заблокирован")
    ok("Конец пояснения" not in text.split("[Терминал]")[-1] or True, "проза не исполняется")
    ok(any(e.get("t") == "cmd" and "привет" in e["text"] for e in events), "вывод команды пришёл в события")
    ok(all(o.get("num_gpu") == 999 for o in SEEN["options"]), "в Ollama уходит num_gpu=999 (GPU)")
    ok(len([e for e in events if e.get("t") == "append"]) > 20, "ответ стримится кусками")
    ok(agent.tps == 50.0, "скорость ток/с посчитана")
    ok(os.path.isdir(os.path.join(ws.root, ".ai_backup", "code_backups")), "бекап создан")
    ok(len(os.listdir(os.path.join(ws.root, ".ai_backup", "code_backups"))) == 1, "ровно один бекап на запуск")
    cfg.set("device", "cpu"); SEEN["options"].clear()
    agent.submit(cid, "query", "привет"); time.sleep(1.0)
    ok(SEEN["options"] and SEEN["options"][-1].get("num_gpu") == 0, "режим CPU => num_gpu=0")
    cfg.set("device", "auto"); SEEN["options"].clear()
    agent.submit(cid, "query", "привет2"); time.sleep(1.0)
    ok("num_gpu" not in SEEN["options"][-1], "режим Авто => num_gpu не передаётся")
    ok(agent.rollback()[0] and not os.path.exists(os.path.join(ws.root, "hello.py")), "откат восстановил состояние до агента")
    st = LLM(cfg).gpu_status(); ok(st["loaded"][0]["pct_gpu"] == 100, "диагностика VRAM: 100% на GPU")

    # --- D-Coder без ИИ ---
    cid2 = store.new()
    struct = "app/\n├── main.py\n└── lib/\n    └── util.py\n"
    code = "### main.py\n```python\nimport lib.util\n```\n### lib/util.py\n```python\ndef f(): return 1\n```\n"
    agent.submit(cid2, "dcoder", struct, code)
    for _ in range(100):
        if not agent.running: break
        time.sleep(0.05)
    ok(open(os.path.join(ws.root, "app/lib/util.py")).read().strip() == "def f(): return 1", "D-Coder разложил код без ИИ")

    # --- сервер для телефона ---
    srv = RemoteServer(agent, cfg); ok(srv.start(), "сервер стартовал")
    base = f"http://127.0.0.1:{cfg.get('port')}"
    def req(path, data=None, token=True, method=None):
        r = urllib.request.Request(base + path, data=json.dumps(data).encode() if data is not None else None, method=method)
        if token: r.add_header("Authorization", "Bearer " + cfg.get("token"))
        try:
            with urllib.request.urlopen(r, timeout=10) as resp: return resp.status, resp.read()
        except urllib.error.HTTPError as e: return e.code, e.read()
    ok(req("/")[0] == 200 and b"AI-Coder" in req("/")[1], "страница телефона отдаётся")
    ok(req("/api/state", token=False)[0] == 401, "без токена 401")
    ok(req("/api/state")[0] == 200, "с токеном 200")
    s = json.loads(req("/api/state")[1]); ok("llama3:8b" in s["models"], "список моделей")
    ok(req("/api/send", {"cid": cid, "mode": "query", "task": "x"}, token=False)[0] == 401, "POST без заголовка отклонён")
    code_q = urllib.request.urlopen(base + f"/api/state?t={cfg.get('token')}").status; ok(code_q == 200, "GET с ?t= работает")
    status, body = req("/api/zip"); z = zipfile.ZipFile(io.BytesIO(body)); names = z.namelist()
    ok(any(n.endswith("app/lib/util.py") for n in names) and not any(".ai_backup" in n for n in names), "ZIP проекта без служебных папок")
    ok(req("/api/file?path=../../etc/passwd")[0] == 404, "чтение файла вне проекта запрещено")
    # SSE + отправка задачи с «телефона»
    got = []
    def sse():
        r = urllib.request.urlopen(base + f"/api/events?t={cfg.get('token')}", timeout=10)
        for line in r:
            got.append(line.decode())
            if any("done-marker" in g for g in got): break
    th = threading.Thread(target=sse, daemon=True); th.start(); time.sleep(0.3)
    ok(json.loads(req("/api/send", {"cid": cid, "mode": "query", "task": "с телефона"})[1])["ok"], "задача с телефона принята")
    time.sleep(1.5)
    ok(any('"t": "append"' in g for g in got), "SSE: телефон получает стрим ответа")
    for _ in range(40):                                # подбор токена
        c = req("/api/state", token=False)[0]
    ok(c == 429, "после серии неверных токенов блокировка 429")
    srv.stop(); print("\nВСЕ ПРОВЕРКИ ПРОЙДЕНЫ")

main()
