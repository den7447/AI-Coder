import base64, io, json, os, sys, tempfile, threading, time, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from PIL import Image
from core import web, images as imgs
from core.config import Config, effective_os, detect_os
from core.llm import LLM
from core.store import ChatStore
from core.workspace import Workspace
from core.engine import Agent
from core.server import RemoteServer
from backup_manager import BackupManager
from modes import assistant_mode

def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: sys.exit(1)
def free_port():
    import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p

# ---------- сайт-заглушка ----------
PAGE = """<html><head><title>Acme &amp; Co</title><meta name="description" content="Мы делаем ракеты">
<script>var secret='SCRIPTTEXT';</script><style>.x{}</style></head><body><h1>Добро пожаловать</h1>
<p>Пишите: info@acme.test или <a href="mailto:sales@acme.test">sales</a></p>
<a href="/about">О нас</a> <a href="https://github.com/acme">GitHub</a> <a href="https://other.example/x">Партнёр</a>
<img src="logo@2x.png"></body></html>"""
class Site(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path == "/old":
            self.send_response(301); self.send_header("Location", "/page"); self.send_header("Content-Length", "0"); self.end_headers(); return
        body = PAGE.encode() if self.path == "/page" else b"nope"
        self.send_response(200 if self.path == "/page" else 404)
        self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Server", "AcmeSrv/1.0")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

# ---------- Ollama-заглушка ----------
CALLS = []; SCRIPT = {"fn": lambda model, msgs: "ответ"}
class Fake(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _j(self, o):
        b = json.dumps(o).encode(); self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/api/tags": return self._j({"models": [{"name": "coder:7b"}, {"name": "vis:7b"}]})
        self._j({"version": "x"})
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/api/show": return self._j({"capabilities": ["completion", "vision"] if "vis" in body["model"] else ["completion"]})
        if self.path == "/api/generate": return self._j({})
        CALLS.append({"model": body["model"], "msgs": body["messages"]})
        ans = SCRIPT["fn"](body["model"], body["messages"])
        data = (json.dumps({"message": {"content": ans}, "done": False}) + "\n" + json.dumps({"message": {"content": ""}, "done": True}) + "\n").encode()
        self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

sp, fp = free_port(), free_port()
threading.Thread(target=ThreadingHTTPServer(("127.0.0.1", sp), Site).serve_forever, daemon=True).start()
threading.Thread(target=ThreadingHTTPServer(("127.0.0.1", fp), Fake).serve_forever, daemon=True).start()
SITE = f"http://127.0.0.1:{sp}"

def make(**cfgset):
    tmp = tempfile.mkdtemp(); cfg = Config(os.path.join(tmp, "s.json")); cfg.set("ollama_host", f"http://127.0.0.1:{fp}"); cfg.set("model", "coder:7b")
    for k, v in cfgset.items(): cfg.set(k, v)
    ws = Workspace(os.path.join(tmp, "p")); st = ChatStore(os.path.join(tmp, "c.json"))
    ag = Agent(cfg, LLM(cfg), st, ws, BackupManager(ws.root)); return cfg, ws, st, ag, st.new()
def wait(ag):
    for _ in range(600):
        if not ag.running: return
        time.sleep(0.05)
    raise SystemExit("таймаут")

# ===== 1. ОС =====
cfg, ws, st, ag, cid = make()
ok(effective_os(cfg)[2] is True and effective_os(cfg)[0] == detect_os()[0], "ОС определяется автоматически")
cfg.set("target_os", "Windows")
name, detail, auto = effective_os(cfg)
ok(name == "Windows" and not auto, "ручной выбор ОС перекрывает автоопределение")
ok("```bat" in ag.system_prompt() and "```bat" in assistant_mode.system_prompt(cfg), "промпты агента и ассистента переключились на Windows/bat")
cfg.set("target_os", "macOS"); ok("zsh" in assistant_mode.system_prompt(cfg), "macOS поддержана")
cfg.set("target_os", "auto")

# ===== 2. веб-модуль =====
try: web.fetch_page(SITE + "/page"); ok(False, "локальный адрес должен быть заблокирован")
except web.WebError as e: ok("внутренней сети" in str(e), "SSRF: 127.0.0.1 заблокирован")
try: web.fetch_page("file:///etc/passwd"); ok(False, "file:// запрещён")
except web.WebError: ok(True, "схема file:// запрещена")
web.ALLOW_PRIVATE = True
rep, meta = web.fetch_page(SITE + "/old")
ok("301" in rep and "Редиректы" in rep, "редирект отслежен")
ok(meta["title"] == "Acme & Co" and "Мы делаем ракеты" in rep, "заголовок и meta description")
ok("SCRIPTTEXT" not in rep and "Добро пожаловать" in rep, "script/style вырезаны, текст на месте")
ok("info@acme.test" in rep and "sales@acme.test" in rep and "logo@2x.png" not in rep, "e-mail найдены, мусор отфильтрован")
ok("github.com/acme" in rep and "[внешняя] Партнёр" in rep, "соцсети и внешние ссылки")
ok("AcmeSrv/1.0" in rep and "HSTS: нет" in rep, "заголовки и проверка защитных заголовков")
sample = ('<a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fa&amp;rut=1">Пример <b>А</b></a>'
          '<a class="result__snippet" href="x">Описание А</a><a class="result__a" href="https://b.test/">B</a>')
r = web.parse_ddg(sample); ok(r[0]["url"] == "https://example.com/a" and r[0]["title"] == "Пример А" and r[0]["snippet"] == "Описание А" and r[1]["url"] == "https://b.test/", "разбор выдачи поиска")
ok("example.test" in web.format_cert({"subject": ((("commonName", "example.test"),),), "issuer": ((("organizationName", "CA"),),), "notBefore": "a", "notAfter": "b", "subjectAltName": (("DNS", "example.test"),)}, "TLSv1.3"), "формат TLS-сертификата")

# ===== 3. картинки =====
big = Image.new("RGB", (4000, 2000), "red"); buf = io.BytesIO(); big.save(buf, "PNG")
b64 = imgs.prepare_bytes(buf.getvalue()); out = Image.open(io.BytesIO(base64.b64decode(b64)))
ok(max(out.size) == 1568, f"большой скриншот уменьшен до {out.size}")
try: imgs.prepare_bytes(b"not an image"); ok(False, "мусор должен отклоняться")
except ValueError: ok(True, "не-изображение отклонено")
small = io.BytesIO(); Image.new("RGBA", (50, 50), (0, 0, 255, 128)).save(small, "PNG"); ok(imgs.prepare_bytes(small.getvalue()), "RGBA с прозрачностью обработан")
IMG = b64

# ===== 4. vision-конвейер =====
SCRIPT["fn"] = lambda model, msgs: "На экране ошибка: ModuleNotFoundError: foo" if model == "vis:7b" else "Понял, ставлю foo."
cfg, ws, st, ag, cid = make(); CALLS.clear()
ok(ag.submit(cid, "query", "что это?", images=[IMG])[0], "запрос со скриншотом принят"); wait(ag)
ok([c["model"] for c in CALLS] == ["vis:7b", "coder:7b"], f"сначала vision-модель, потом кодовая: {[c['model'] for c in CALLS]}")
ok(CALLS[0]["msgs"][-1].get("images") == [IMG], "картинка ушла vision-модели")
last = CALLS[1]["msgs"][-1]
ok("ModuleNotFoundError: foo" in last["content"] and "images" not in last, "кодовая модель получила описание текстом, без картинки")
ok("🖼 [Вложено изображений: 1]" in "".join(st.get(cid)["messages"]), "в чате отмечено вложение")

CALLS.clear(); SCRIPT["fn"] = lambda model, msgs: "вижу"
cfg, ws, st, ag, cid = make(model="vis:7b"); ag.submit(cid, "query", "смотри", images=[IMG]); wait(ag)
ok(len(CALLS) == 1 and CALLS[0]["model"] == "vis:7b" and CALLS[0]["msgs"][-1].get("images") == [IMG], "модель с vision получает картинку напрямую")

CALLS.clear(); cfg, ws, st, ag, cid = make(vision_model="vis:7b"); SCRIPT["fn"] = lambda m, msgs: "описание" if m == "vis:7b" else "ок"
ag.submit(cid, "query", "x", images=[IMG]); wait(ag); ok(CALLS[0]["model"] == "vis:7b", "явно выбранная vision-модель используется")

CALLS.clear(); cfg, ws, st, ag, cid = make(); ag.llm.vision_models = lambda: []; ag.submit(cid, "query", "x", images=[IMG]); wait(ag)
ok(len(CALLS) == 1 and not any("images" in m for m in CALLS[0]["msgs"]) and "не умеет смотреть картинки" in "".join(st.get(cid)["messages"]), "нет vision-модели: предупреждение, картинки не отправляются")

CALLS.clear(); cfg, ws, st, ag, cid = make(); SCRIPT["fn"] = lambda m, msgs: "ок"
ag.submit(cid, "query", "", images=[IMG]); wait(ag); ok("Посмотри на вложенное" in "".join(st.get(cid)["messages"]), "скриншот без текста тоже работает")

# ===== 5. сервер принимает картинки =====
cfg, ws, st, ag, cid = make(); cfg.set("port", free_port()); srv = RemoteServer(ag, cfg); srv.start(); base = f"http://127.0.0.1:{cfg.get('port')}"
def post(path, data):
    r = urllib.request.Request(base + path, data=json.dumps(data).encode(), headers={"Authorization": "Bearer " + cfg.get("token")})
    try:
        with urllib.request.urlopen(r, timeout=10) as x: return x.status, json.loads(x.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
CALLS.clear(); SCRIPT["fn"] = lambda m, msgs: "описание" if m == "vis:7b" else "ок"
code, d = post("/api/send", {"cid": cid, "mode": "query", "task": "с телефона", "images": ["data:image/png;base64," + IMG]})
ok(code == 200 and d["ok"], "телефон отправил скриншот"); wait(ag); ok(CALLS and CALLS[0]["model"] == "vis:7b", "скриншот с телефона дошёл до модели")
code, d = post("/api/send", {"cid": cid, "mode": "query", "task": "x", "images": ["!!!not-base64!!!"]})
ok(code == 400 and "изображение отклонено" in d["error"], "битая картинка отклоняется с понятной ошибкой")
code, d = post("/api/settings", {"target_os": "Windows"}); ok(cfg.get("target_os") == "Windows", "ОС переключается с телефона")
srv.stop()

# ===== 6. ассистент ходит на сайт =====
def script(model, msgs):
    u = msgs[-1]["content"]
    if "Начни" in u: return f"Проверю сайт.\n```web\n{SITE}/page\n```"
    if "Acme & Co" in u and "info@acme.test" in u and "недоверенные" in u: return "ГОТОВО: у сайта заголовок Acme & Co"
    return "НЕВОЗМОЖНО: нет данных"
SCRIPT["fn"] = script; cfg, ws, st, ag, cid = make(); CALLS.clear()
ag.submit(cid, "assistant", "проверь сайт"); wait(ag); txt = "".join(st.get(cid)["messages"])
ok("🌐 [Открываю]" in txt and "✅ [АССИСТЕНТ] Задача выполнена: у сайта заголовок Acme & Co" in txt, "ассистент открыл сайт и сделал вывод по содержимому")
ok("```web" in CALLS[0]["msgs"][0]["content"], "в системном промпте описан блок web/search")
cfg2, ws, st, ag, cid = make(web_access=False); CALLS.clear(); ag.submit(cid, "assistant", "проверь сайт"); wait(ag)
ok("выключен" in CALLS[1]["msgs"][-1]["content"] and "```web" not in CALLS[0]["msgs"][0]["content"], "web_access=False: инструмент скрыт и недоступен")
web.ALLOW_PRIVATE = False
cfg, ws, st, ag, cid = make(); CALLS.clear(); ag.submit(cid, "assistant", "проверь сайт"); wait(ag)
ok("внутренней сети" in CALLS[1]["msgs"][-1]["content"], "ИИ получает отказ при попытке открыть внутренний адрес")
print("\nВСЕ ПРОВЕРКИ НОВЫХ ФУНКЦИЙ ПРОЙДЕНЫ")
