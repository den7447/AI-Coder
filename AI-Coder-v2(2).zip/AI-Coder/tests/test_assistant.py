import json, os, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from core.config import Config
from core.llm import LLM
from core.store import ChatStore
from core.workspace import Workspace
from core.engine import Agent
from backup_manager import BackupManager

SCRIPT = {"fn": None}; SEEN = []

class Fake(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def _j(self, o):
        b = json.dumps(o).encode(); self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self): self._j({"version": "x", "models": []})
    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/api/generate": return self._j({})
        SEEN.append(body["messages"]); ans = SCRIPT["fn"](body["messages"])
        data = (json.dumps({"message": {"content": ans}, "done": False}) + "\n" + json.dumps({"message": {"content": ""}, "done": True}) + "\n").encode()
        self.send_response(200); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

def free_port():
    import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p

def ok(c, m):
    print(("PASS " if c else "FAIL ") + m)
    if not c: sys.exit(1)

fp = free_port()
threading.Thread(target=ThreadingHTTPServer(("127.0.0.1", fp), Fake).serve_forever, daemon=True).start()

def make():
    tmp = tempfile.mkdtemp(); cfg = Config(os.path.join(tmp, "s.json")); cfg.set("ollama_host", f"http://127.0.0.1:{fp}")
    ws = Workspace(os.path.join(tmp, "p")); st = ChatStore(os.path.join(tmp, "c.json"))
    ag = Agent(cfg, LLM(cfg), st, ws, BackupManager(ws.root)); return cfg, ws, st, ag, st.new()

def wait(ag):
    for _ in range(400):
        if not ag.running: return
        time.sleep(0.05)
    raise SystemExit("таймаут")

def last_user(m): return m[-1]["content"]

# --- 1. ошибка -> анализ -> исправление -> проверка -> ГОТОВО ---
def s1(m):
    u = last_user(m)
    if "Начни с первого шага" in u: return "Прочитаю папку.\n```bash\nls no_such_dir\n```"
    if "Код возврата: 0" in u and "made" in u: return "ГОТОВО: создал made/a.txt"
    if "No such file" in u or "no_such_dir" in u: return "Папки нет, создам.\n```bash\nmkdir -p made && echo ok > made/a.txt && cat made/a.txt\n```"
    return "ГОТОВО: ???"
SCRIPT["fn"] = s1; cfg, ws, st, ag, cid = make()
ag.submit(cid, "assistant", "создай made/a.txt"); wait(ag)
text = "".join(st.get(cid)["messages"])
ok(os.path.exists(os.path.join(ws.root, "made", "a.txt")), "ИИ исправил ошибку и создал файл")
ok(len(SEEN) == 3, f"ровно 3 обращения к ИИ (команда, исправление, вердикт), было {len(SEEN)}")
ok("No such file" in SEEN[1][-1]["content"] and "Код возврата: 2" in SEEN[1][-1]["content"], "логи и код возврата переданы ИИ")
ok("Выполнено: создал made/a.txt" in str(st.get(cid)["history"]), "итог записан в историю")
ok("✅ [АССИСТЕНТ] Задача выполнена" in text and not st.get(cid)["state"], "задача закрыта, состояние чистое")

# --- 2. зацикливание ---
SEEN.clear(); SCRIPT["fn"] = lambda m: "Пробую.\n```bash\necho same\n```"
cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
ok(len(SEEN) == 3 and "одни и те же действия" in "".join(st.get(cid)["messages"]), "зацикливание остановлено на 3-м повторе")

# --- 3. опасная команда блокируется и модель об этом узнаёт ---
SEEN.clear()
def s3(m):
    u = last_user(m)
    if "Начни" in u: return "```bash\nrm -rf /\n```"
    return "НЕВОЗМОЖНО: команда запрещена"
SCRIPT["fn"] = s3; cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
ok("заблокированы как опасные" in SEEN[1][-1]["content"], "ИИ получил сообщение о блокировке")
ok("❌ [АССИСТЕНТ] Остановлен: команда запрещена" in "".join(st.get(cid)["messages"]), "вердикт НЕВОЗМОЖНО обработан")

# --- 4. команды выключены ---
SEEN.clear(); SCRIPT["fn"] = lambda m: "```bash\necho hi\n```"
cfg, ws, st, ag, cid = make(); cfg.set("allow_cmd", False); ag.submit(cid, "assistant", "x"); wait(ag)
ok(len(SEEN) == 1 and "выключено в настройках" in "".join(st.get(cid)["messages"]), "при выключенных командах цикл не крутится вхолостую")

# --- 5. лимит шагов + продолжение с тем же контекстом ---
SEEN.clear(); n = {"i": 0}
def s5(m):
    n["i"] += 1
    return f"Шаг.\n```bash\necho step{n['i']}\n```" if n["i"] < 5 else "ГОТОВО: конец"
SCRIPT["fn"] = s5; cfg, ws, st, ag, cid = make(); cfg.set("assistant_max_steps", 2)
ag.submit(cid, "assistant", "долгая"); wait(ag)
ok(len(SEEN) == 2 and st.get(cid)["state"].get("asst"), "на лимите шагов состояние сохранено")
ag.submit(cid, "assistant", ""); wait(ag)
ok("ГОТОВО" in str(SEEN[-1]) or "конец" in "".join(st.get(cid)["messages"]), "«Отправить» продолжил и довёл до ГОТОВО")
ok(len(SEEN[2]) >= 5, "контекст прошлых шагов сохранён при продолжении")

# --- 6. модель не прислала ни команд, ни вердикта ---
SEEN.clear(); SCRIPT["fn"] = lambda m: "Не знаю, что делать."
cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
ok(len(SEEN) == 2 and "ни команд, ни вердикта" in "".join(st.get(cid)["messages"]), "молчаливая модель: одно напоминание и стоп")

# --- 7. повтор без изменений не запускается заново ---
SEEN.clear(); SCRIPT["fn"] = lambda m: "Пишу.\n```bash\necho x >> counter.txt\n```"
cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
cnt = open(os.path.join(ws.root, "counter.txt")).read().count("x"); txt = "".join(st.get(cid)["messages"])
ok(cnt == 1, f"одинаковая команда выполнена один раз, а не три (было {cnt})")
ok(len(SEEN) == 3 and "[Повтор]" in txt and "повторяет одни и те же действия" in txt, "ИИ предупреждён о повторе, на втором повторе остановка")
ok("ничего не менялось" in SEEN[2][-1]["content"] and "Код возврата: 0" in SEEN[2][-1]["content"], "в предупреждении есть результат прошлого запуска")

# --- 8. легитимный повтор после изменений разрешён ---
SEEN.clear(); n = {"i": 0}
def s8(m):
    n["i"] += 1
    return ["```bash\nls\n```", "```bash\ntouch a.txt\n```", "```bash\nls\n```", "ГОТОВО: файл появился"][min(n["i"] - 1, 3)]
SCRIPT["fn"] = s8; cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
ok(len(SEEN) == 4 and "a.txt" in SEEN[3][-1]["content"], "повторный ls после touch выполнен и показал новый файл")

# --- 9. ранняя сдача: один раз возвращаем к работе ---
SEEN.clear(); n = {"i": 0}
def s9(m):
    n["i"] += 1
    return ["НЕВОЗМОЖНО: путь не найден", "```bash\necho ok > r.txt\n```", "ГОТОВО: сделал"][min(n["i"] - 1, 2)]
SCRIPT["fn"] = s9; cfg, ws, st, ag, cid = make(); ag.submit(cid, "assistant", "x"); wait(ag)
ok("Рано сдаваться" in SEEN[1][-1]["content"] and os.path.exists(os.path.join(ws.root, "r.txt")), "после первого «НЕВОЗМОЖНО» модель возвращена к работе и справилась")

# --- 10. подсказка про текущую папку при «путь не найден» (как на скриншоте) ---
SEEN.clear(); n = {"i": 0}
def s10(m):
    n["i"] += 1
    return ["```bash\ncd Project-AI && ls\n```", "ГОТОВО: ок"][min(n["i"] - 1, 1)]
SCRIPT["fn"] = s10; cfg, ws, st, ag, cid = make(); open(os.path.join(ws.root, "main.py"), "w").write("x")
ag.submit(cid, "assistant", "покажи файлы"); wait(ag)
fb = SEEN[1][-1]["content"]
ok("ты уже в ней" in fb and "main.py" in fb, "при ошибке пути ИИ получает текущую папку и список файлов")
ok("ты уже внутри неё" in SEEN[0][-1]["content"] or "ты уже внутри неё" in str(SEEN[0]), "в первом сообщении сказано, что cd в папку проекта не нужен")
from modes import assistant_mode as am
ok("Права:" in am.system_prompt(cfg, ws.root), "в промпте указаны права (админ/обычный)")

print("\nВСЕ ПРОВЕРКИ АССИСТЕНТА ПРОЙДЕНЫ")
