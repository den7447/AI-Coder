#!/bin/bash
# Запуск Ollama с ускорением памяти (если она не запущена как сервис)
export OLLAMA_FLASH_ATTENTION=1
export OLLAMA_KV_CACHE_TYPE=q8_0
exec ollama serve
