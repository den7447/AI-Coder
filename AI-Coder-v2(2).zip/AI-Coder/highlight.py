"""Лёгкая подсветка синтаксиса без внешних библиотек."""
import bisect
import os
import re

COLORS = {"kw": "#ff7b72", "str": "#a5d6ff", "com": "#8b949e", "num": "#79c0ff", "fn": "#d2a8ff",
          "deco": "#ffa657", "tag": "#7ee787", "var": "#ffa657", "prop": "#79c0ff"}

PY_KW = ("and as assert async await break class continue def del elif else except finally for from global if "
         "import in is lambda nonlocal not or pass raise return try while with yield None True False self cls print")
C_KW = ("abstract async await break case catch class const continue default delete do else enum export extends "
        "false final finally for from function go if implements import in instanceof interface let new null of "
        "package private protected public return static struct super switch this throw true try typeof var void "
        "while with yield fn impl mut pub use mod match loop func type int string bool float double char long")
SH_KW = "if then else elif fi for do done while case esac function echo cd export set exit return source in call goto"


def _kw(words):
    return r"\b(?:" + "|".join(words.split()) + r")\b"


STR = r"""(?P<str>"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')"""

RULES = {
    "py": re.compile(
        r"(?P<com>#[^\n]*)|(?P<str>[rbfRBF]{0,2}(?:\"\"\"[\s\S]*?\"\"\"|'''[\s\S]*?'''|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*'))"
        r"|(?P<deco>^[ \t]*@\w+)|(?P<fn>(?<=def )\w+|(?<=class )\w+)|(?P<kw>" + _kw(PY_KW) + r")|(?P<num>\b\d+(?:\.\d+)?\b)", re.M),
    "c": re.compile(
        r"(?P<com>//[^\n]*|/\*[\s\S]*?\*/)|(?P<str>`[\s\S]*?`|\"(?:\\.|[^\"\\\n])*\"|'(?:\\.|[^'\\\n])*')"
        r"|(?P<kw>" + _kw(C_KW) + r")|(?P<num>\b\d+(?:\.\d+)?\b)"),
    "html": re.compile(
        r"(?P<com><!--[\s\S]*?-->)|(?P<tag></?[A-Za-z][\w:-]*|/?>)|(?P<str>\"[^\"\n]*\"|'[^'\n]*')|(?P<prop>\b[\w:-]+(?==))"),
    "css": re.compile(
        r"(?P<com>/\*[\s\S]*?\*/)|" + STR + r"|(?P<deco>@[\w-]+)"
        r"|(?P<prop>[\w-]+(?=\s*:))|(?P<num>#[0-9a-fA-F]{3,8}\b|-?\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms)?\b)"),
    "json": re.compile(r"(?P<prop>\"(?:\\.|[^\"\\\n])*\"(?=\s*:))|(?P<str>\"(?:\\.|[^\"\\\n])*\")"
                       r"|(?P<kw>\b(?:true|false|null)\b)|(?P<num>-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)"),
    "sh": re.compile(r"(?P<com>(?:^|\s)#[^\n]*|^\s*(?:rem|REM)\s[^\n]*)|" + STR +
                     r"|(?P<var>\$\{[^}]*\}|\$\w+|%\w+%)|(?P<kw>" + _kw(SH_KW) + r")", re.M),
}
EXT = {".py": "py", ".js": "c", ".ts": "c", ".jsx": "c", ".tsx": "c", ".java": "c", ".c": "c", ".cpp": "c",
       ".h": "c", ".hpp": "c", ".cs": "c", ".go": "c", ".rs": "c", ".kt": "c", ".php": "c",
       ".html": "html", ".htm": "html", ".xml": "html", ".vue": "html", ".css": "css", ".json": "json",
       ".sh": "sh", ".bat": "sh", ".cmd": "sh"}


def setup_tags(text):
    for name, color in COLORS.items():
        text.tag_configure(name, foreground=color)
    text.tag_configure("com", foreground=COLORS["com"])


def apply(text, path):
    """Перекрашивает весь текст (для больших файлов только видимую часть)."""
    for name in COLORS:
        text.tag_remove(name, "1.0", "end")
    rule = RULES.get(EXT.get(os.path.splitext(path or "")[1].lower(), ""))
    if not rule:
        return
    total = int(text.index("end-1c").split(".")[0])
    first, last = 1, total
    if total > 4000:
        first = max(1, int(text.index("@0,0").split(".")[0]) - 100)
        last = min(total, int(text.index(f"@0,{text.winfo_height()}").split(".")[0]) + 300)
    chunk = text.get(f"{first}.0", f"{last}.end")
    starts, pos = [], 0
    for ln in chunk.split("\n"):
        starts.append(pos)
        pos += len(ln) + 1

    def idx(off):
        i = bisect.bisect_right(starts, off) - 1
        return f"{first + i}.{off - starts[i]}"

    for m in rule.finditer(chunk):
        kind = m.lastgroup
        if kind and m.end() > m.start():
            text.tag_add(kind, idx(m.start()), idx(m.end()))
