"""Палитра и шрифты. tk.Text не понимает цвета customtkinter, поэтому тут обычные hex-строки."""
import tkinter.font as tkfont

BG = "#0d1117"
PANEL = "#161b22"
PANEL2 = "#1c2330"
LINE = "#2a3342"
FG = "#e6edf3"
MUTE = "#8b98a9"
ACC = "#3b82f6"
ACC_HOVER = "#2563eb"
OK = "#22c55e"
WARN = "#f59e0b"
BAD = "#ef4444"
CODE_BG = "#0a0e14"
USER_BG = "#1b2a45"

UI = "Segoe UI"
MONO = "Consolas"


def init_fonts(root):
    global UI, MONO
    fams = set(tkfont.families(root))
    for f in ("Segoe UI", "Inter", "Noto Sans", "Ubuntu", "DejaVu Sans", "Helvetica"):
        if f in fams:
            UI = f
            break
    for f in ("JetBrains Mono", "Cascadia Code", "Consolas", "DejaVu Sans Mono", "Liberation Mono", "Courier New"):
        if f in fams:
            MONO = f
            break
