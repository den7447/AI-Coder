"""AI-Coder. Запуск:  python main.py            (окно)
                    python main.py --server   (без окна: только сервер для телефона)"""
import os
import subprocess
import sys

os.chdir(os.path.dirname(os.path.abspath(__file__)))


def ensure_dependencies(packages):
    if os.environ.get("AI_CODER_INSTALL_LOOP_PREVENT") == "1":
        return
    missing = []
    for module, pip_name in packages.items():
        try:
            __import__(module)
        except ImportError:
            missing.append(pip_name)
    if not missing:
        return
    print(f"\n⚙️  Устанавливаю недостающие библиотеки: {', '.join(missing)} ...\n")
    for extra in (["--break-system-packages"], []):
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", *missing, *extra])
            os.environ["AI_CODER_INSTALL_LOOP_PREVENT"] = "1"
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except subprocess.CalledProcessError:
            continue
    print("❌ Не удалось установить пакеты. Выполните вручную: pip install " + " ".join(missing))
    sys.exit(1)


def run_headless():
    ensure_dependencies({"requests": "requests"})
    from core.bootstrap import build_core
    core = build_core()
    core.agent.start_monitor()
    core.cfg.set("serve_network", True, save=False)
    if not core.server.start():
        print("❌", core.server.error)
        sys.exit(1)
    print("AI-Coder сервер запущен. Откройте на телефоне (одна Wi-Fi сеть):")
    for u in core.server.urls():
        print("  ", u)
    print("Токен:", core.cfg.get("token"), "\nCtrl+C, чтобы остановить.")
    try:
        import time
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        core.store.flush()


def run_gui():
    ensure_dependencies({"customtkinter": "customtkinter", "requests": "requests"})
    import customtkinter as ctk
    from core.bootstrap import build_core
    from gui import App
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    App(build_core()).mainloop()


if __name__ == "__main__":
    run_headless() if "--server" in sys.argv else run_gui()
