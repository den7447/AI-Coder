import json
import os
import threading

# Пытаемся импортировать автопереводчик. Если его еще нет, программа не упадет.
try:
    from deep_translator import GoogleTranslator
except ImportError:
    GoogleTranslator = None

LANG_FILE = "settings_lang.json"
CACHE_FILE = "lang_cache.json"

# Вшитый словарь для Английского (чтобы работал оффлайн и без задержек)
EN_DICT = {
    "📁 Выбрать папку проекта": "📁 Select Workspace",
    "➕ Новая сессия": "➕ New Session",
    "История сессий:": "Session History:",
    "Файлы проекта:": "Project Files:",
    "💻 Терминал": "💻 Terminal",
    "⏪ Откат кода": "⏪ Rollback Code",
    "⚙️ Настройки": "⚙️ Settings",
    "❓ Помощь": "❓ Help",
    "🌐 Web-ИИ": "🌐 Web-AI",
    "📜 О Проекте": "📜 About Project",
    "💬 Терминал ИИ": "💬 AI Terminal",
    "📝 Редактор кода": "📝 Code Editor",
    "💻 Живой вывод командной строки": "💻 Live CLI Output",
    "Запрос:": "Prompt:",
    "2. Содержимое файлов (какой код куда):": "2. File contents (where code goes):",
    "🤖 Режим: АГЕНТ": "🤖 Mode: AGENT",
    "💬 Режим: ASK": "💬 Mode: ASK",
    "🛠️ Режим: АССИСТЕНТ": "🛠️ Mode: ASSISTANT",
    "🎯 Режим: D-CODER": "🎯 Mode: D-CODER",
    "🚀 ОТПРАВИТЬ": "🚀 SEND",
    "⏸ ПАУЗА": "⏸ PAUSE",
    "🛑 СТОП": "🛑 STOP",
    "▶️ Запустить проект": "▶️ Run Project",
    "💾 Сохранить": "💾 Save",
    "🚀 Отправить": "🚀 Send",
    "Файл не выбран": "No file selected",
    "Параметры генерации": "Generation Settings",
    "Модель:": "Model:",
    "Целевая ОС:": "Target OS:",
    "Контекст:": "Context:",
    "Креатив:": "Creativity:",
    "Разрешить ИИ выполнять команды": "Allow AI to execute commands",
    "Язык интерфейса:": "UI Language:",
    "Я прочитал эту простыню и согласен": "I have read this and agree",
    "Перезапуск": "Restart Required",
    "Пожалуйста, перезапустите AI-Coder, чтобы язык обновился.": "Please restart AI-Coder to apply the language change."
}

EN_DICT.update({
    "🧠 Модель и GPU": "🧠 Model & GPU", "🤖 Агент": "🤖 Agent", "📱 Сеть": "📱 Network", "🌐 Язык": "🌐 Language",
    "Считать на:": "Run on:", "Авто": "Auto", "Модель:": "Model:", "Контекст (токенов):": "Context (tokens):",
    "Креативность:": "Creativity:", "Держать модель в VRAM:": "Keep model in VRAM:",
    "⚡ Применить и прогреть модель": "⚡ Apply & warm up model", "🔍 Проверить, где работает": "🔍 Check where it runs",
    "Целевая ОС для команд:": "Target OS for commands:", "Глубина плана агента:": "Agent plan depth:",
    "Раздавать агента по сети (для телефона)": "Share the agent over network (for phone)",
    "Раздаётся по сети": "Shared over network", "Выключено": "Off", "Порт:": "Port:", "Применить": "Apply",
    "Токен доступа:": "Access token:", "Локальный ИИ на вашей видеокарте": "Local AI on your GPU",
    "Запуск...": "Starting...", "🔍 Ищу Ollama...": "🔍 Looking for Ollama...", "Готов": "Ready", "Работает": "Working",
    "Пауза": "Paused", "шаг": "step", "📁 Папка": "📁 Folder", "🧠 Модель загружена": "🧠 Model loaded",
    "🚀 ОТПРАВИТЬ / ПРОДОЛЖ.": "🚀 SEND / RESUME", "🧠 ОБРАБОТКА...": "🧠 WORKING...",
    "1. Структура проекта (папки/файлы):": "1. Project structure (folders/files):",
    "Запустить": "Run", "Создать файл": "Create file", "Удалить": "Delete", "Обновить": "Refresh",
    "Имя файла:": "File name:", "Ошибка": "Error", "Успех": "Success", "Внимание": "Warning",
    "Новый проект": "New project", "Автономная среда разработки": "Autonomous dev environment",
    "🤖 Агент": "🤖 Agent", "🛠️ Ассистент": "🛠️ Assistant", "Сначала остановите задачу.": "Stop the task first.",
})

class AutoTranslator:
    def __init__(self):
        self.lang = "ru"
        self.cache = {"en": EN_DICT}
        self._failed = set()      # что не удалось перевести (нет сети): повторно не мучаем сеть
        self.load_settings()
        self.load_cache()

    def load_settings(self):
        if os.path.exists(LANG_FILE):
            try:
                with open(LANG_FILE, "r", encoding="utf-8") as f:
                    self.lang = json.load(f).get("lang", "ru")
            except Exception: pass

    def load_cache(self):
        if os.path.exists(CACHE_FILE):
            try:
                with open(CACHE_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    for k, v in loaded.items():
                        if k not in self.cache:
                            self.cache[k] = v
                        else:
                            self.cache[k].update(v)
            except Exception: pass

    def save_cache(self):
        try:
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, ensure_ascii=False, indent=4)
        except Exception: pass

    def set_lang(self, lang_code):
        self.lang = lang_code
        try:
            with open(LANG_FILE, "w", encoding="utf-8") as f:
                json.dump({"lang": lang_code}, f, ensure_ascii=False)
        except Exception: pass

    def __call__(self, text):
        if not text or not isinstance(text, str):
            return text

        if self.lang == "ru":
            return text

        if self.lang not in self.cache:
            self.cache[self.lang] = {}

        if text in self.cache[self.lang]:
            return self.cache[self.lang][text]

        # Автопереводчик для новых языков
        if GoogleTranslator and (self.lang, text) not in self._failed:
            try:
                translated = GoogleTranslator(source='ru', target=self.lang).translate(text)
                self.cache[self.lang][text] = translated
                threading.Thread(target=self.save_cache, daemon=True).start()
                return translated
            except Exception:
                self._failed.add((self.lang, text))
                return text

        return text

_translator = AutoTranslator()

# Функция _() будет оборачивать все тексты в программе
def _(text):
    return _translator(text)

def set_language(lang_code):
    _translator.set_lang(lang_code)

def get_language():
    return _translator.lang
