"""Окно настроек: модель и GPU, агент, сеть (телефон), язык."""
import threading
import tkinter as tk
from tkinter import messagebox

import customtkinter as ctk

import theme as T
from core.config import IS_WINDOWS, detect_os, effective_os
from core.privileges import is_admin
from i18n import _, get_language, set_language

LANGS = {"Русский": "ru", "English": "en", "Español": "es", "Deutsch": "de", "中文": "zh-CN", "Қазақша": "kk"}
DEV_HINT = {
    "gpu": "GPU: все слои модели в видеопамяти. Максимальная скорость. Если не хватит памяти, программа сама повторит запрос в авто-режиме.",
    "auto": "Авто: Ollama сама решает, сколько слоёв отдать видеокарте.",
    "cpu": "CPU: только процессор. Медленно, нужно лишь если видеокарта занята другим.",
}
KEEP = {"5 минут": "5m", "30 минут": "30m", "2 часа": "2h", "Всегда в памяти": "-1"}
OS_LABELS = {"auto": "Определять автоматически", "Linux": "Linux", "Windows": "Windows", "macOS": "macOS"}
DEPTH = {"Короткий (3-8 шагов)": "short", "Обычный (6-15)": "normal", "Подробный (15-40)": "deep"}


def _row(parent, label):
    f = ctk.CTkFrame(parent, fg_color="transparent")
    f.pack(fill="x", padx=14, pady=6)
    ctk.CTkLabel(f, text=label, width=170, anchor="w", font=(T.UI, 12)).pack(side="left")
    return f


def open_settings(app, tab=None):
    old = getattr(app, "_settings_win", None)
    if old is not None and old.winfo_exists():
        old.focus_force()
        if tab:
            old.tabs.set(old.tab_names[tab])
        return
    cfg = app.cfg
    win = app._popup(_("⚙️ Настройки"), 660, 700)
    app._settings_win = win
    names = {"gpu": _("🧠 Модель и GPU"), "agent": _("🤖 Агент"), "net": _("📱 Сеть"), "lang": _("🌐 Язык")}
    win.tab_names = names
    tabs = ctk.CTkTabview(win, fg_color=T.PANEL, segmented_button_selected_color=T.ACC,
                          segmented_button_unselected_color=T.PANEL2)
    tabs.pack(fill="both", expand=True, padx=10, pady=10)
    win.tabs = tabs
    t_gpu, t_agent, t_net, t_lang = (tabs.add(names[k]) for k in ("gpu", "agent", "net", "lang"))

    # ---------------- Модель и GPU ----------------
    f = _row(t_gpu, _("Считать на:"))
    dev_names = [("gpu", "GPU"), ("auto", _("Авто")), ("cpu", "CPU")]
    hint = ctk.CTkLabel(t_gpu, text="", wraplength=580, justify="left", text_color=T.MUTE, font=(T.UI, 11))

    def on_dev(label):
        dev = next(k for k, v in dev_names if v == label)
        cfg.set("device", dev)
        hint.configure(text=_(DEV_HINT[dev]))
        app.sync_device_widget()
    seg = ctk.CTkSegmentedButton(f, values=[v for _k, v in dev_names], command=on_dev, selected_color=T.OK,
                                 selected_hover_color="#16a34a", unselected_color=T.PANEL2)
    seg.pack(side="left", fill="x", expand=True)
    seg.set(dict(dev_names)[cfg.get("device")])
    hint.pack(fill="x", padx=16, pady=(0, 6))
    hint.configure(text=_(DEV_HINT[cfg.get("device")]))

    gpu_lbl = ctk.CTkLabel(t_gpu, text="…", anchor="w", justify="left", wraplength=580, font=(T.MONO, 11),
                           text_color=T.FG, fg_color=T.BG, corner_radius=8)
    gpu_lbl.pack(fill="x", padx=14, pady=6, ipady=8)

    f = _row(t_gpu, _("Модель:"))
    models = app.models or [cfg.get("model")]
    mm = ctk.CTkComboBox(f, values=models, command=lambda v: (app.on_model(v), None)[1])
    mm.set(cfg.get("model"))
    mm.pack(side="left", fill="x", expand=True)
    mm.bind("<Return>", lambda e: app.on_model(mm.get()))
    ctk.CTkButton(f, text="🔄", width=34, fg_color=T.PANEL2, command=lambda: app.refresh_models(True)).pack(side="left", padx=(6, 0))
    ctk.CTkLabel(t_gpu, text=_("Можно выбрать из списка или вписать имя модели вручную и нажать Enter."),
                 text_color=T.MUTE, font=(T.UI, 11), anchor="w").pack(fill="x", padx=16)

    f = _row(t_gpu, _("Контекст (токенов):"))
    ctx = ctk.CTkOptionMenu(f, values=["2048", "4096", "8192", "16384", "32768"],
                            command=lambda v: cfg.set("num_ctx", int(v)))
    ctx.set(str(cfg.get("num_ctx")))
    ctx.pack(side="left", fill="x", expand=True)

    f = _row(t_gpu, _("Модель для скриншотов:"))
    auto_lbl = _("Авто (текущая или найденная)")
    vm = ctk.CTkOptionMenu(f, values=[auto_lbl] + models,
                           command=lambda v: cfg.set("vision_model", "" if v == auto_lbl else v))
    vm.set(cfg.get("vision_model") or auto_lbl)
    vm.pack(side="left", fill="x", expand=True)
    ctk.CTkLabel(t_gpu, text=_("Если текущая модель не видит картинки, скриншот сначала описывает vision-модель "
                               "(например qwen2.5vl, gemma3, llava), а кодовая работает с описанием."),
                 text_color=T.MUTE, wraplength=580, justify="left", font=(T.UI, 11)).pack(fill="x", padx=16)

    f = _row(t_gpu, _("Креативность:"))
    tl = ctk.CTkLabel(f, text=f"{cfg.get('temperature'):.2f}", width=40)
    tl.pack(side="right")
    sl = ctk.CTkSlider(f, from_=0, to=1, number_of_steps=20,
                       command=lambda v: (cfg.set("temperature", round(v, 2), save=False), tl.configure(text=f"{v:.2f}")))
    sl.set(cfg.get("temperature"))
    sl.pack(side="left", fill="x", expand=True)
    sl.bind("<ButtonRelease-1>", lambda e: cfg.save())

    f = _row(t_gpu, _("Держать модель в VRAM:"))
    inv = {v: k for k, v in KEEP.items()}
    ka = ctk.CTkOptionMenu(f, values=list(KEEP), command=lambda v: cfg.set("keep_alive", KEEP[v]))
    ka.set(inv.get(cfg.get("keep_alive"), "30 минут"))
    ka.pack(side="left", fill="x", expand=True)

    result = {"text": ""}
    res_lbl = ctk.CTkLabel(t_gpu, text="", wraplength=580, justify="left", anchor="w", font=(T.UI, 11), text_color=T.MUTE)

    def apply_warm():
        if app.agent.running:
            return messagebox.showinfo("AI-Coder", _("Сначала остановите задачу."), parent=win)
        result["text"] = "⏳ " + _("Перезагружаю модель с новыми параметрами...")

        def work():
            app.llm.unload()
            ok, err = app.llm.warmup()
            st = app.llm.gpu_status()
            m = (st["loaded"] or [None])[0]
            result["text"] = ("✅ " + _("Готово.") + (f" {m['name']}: {m['pct_gpu']}% " + _("в видеопамяти") if m else "")) if ok else f"❌ {err}"
        threading.Thread(target=work, daemon=True).start()

    def check():
        def work():
            st = app.llm.gpu_status()
            lines = []
            for g in st["gpus"] or []:
                lines.append(f"{g['name']}: {g['used_mb']}/{g['total_mb']} МБ, {g['util']}%, {g['temp']}°C")
            if st["gpus"] is None:
                lines.append("nvidia-smi " + _("не найден"))
            for m in st["loaded"]:
                lines.append(f"{m['name']}: {m['pct_gpu']}% " + _("в видеопамяти"))
            if not st["loaded"]:
                lines.append(_("Модель сейчас не загружена"))
            if st["warning"]:
                lines.append("⚠️ " + st["warning"])
            result["text"] = "\n".join(lines)
        threading.Thread(target=work, daemon=True).start()

    bf = ctk.CTkFrame(t_gpu, fg_color="transparent")
    bf.pack(fill="x", padx=14, pady=8)
    ctk.CTkButton(bf, text=_("⚡ Применить и прогреть модель"), fg_color=T.ACC, command=apply_warm).pack(side="left", padx=(0, 8))
    ctk.CTkButton(bf, text=_("🔍 Проверить, где работает"), fg_color=T.PANEL2, command=check).pack(side="left")
    res_lbl.pack(fill="x", padx=16)

    def poll():
        if not win.winfo_exists():
            return
        if app.models and list(mm.cget("values")) != app.models:
            mm.configure(values=app.models)
            vm.configure(values=[auto_lbl] + app.models)
            mm.set(cfg.get("model"))
        d = app.agent.last_gpu
        if d:
            lines = []
            for g in d["gpus"] or []:
                lines.append(f"{g['name']}  {g['used_mb'] / 1024:.1f}/{g['total_mb'] / 1024:.0f} ГБ  {g['util']}%  {g['temp']}°C")
            if d["gpus"] is None:
                lines.append("NVIDIA GPU: nvidia-smi " + _("не найден"))
            for m in d["loaded"]:
                lines.append(f"{m['name']}  →  {m['pct_gpu']}% " + _("в видеопамяти"))
            gpu_lbl.configure(text="\n".join(lines) or "…")
        if result["text"] != res_lbl.cget("text"):
            res_lbl.configure(text=result["text"])
        win.after(1000, poll)
    poll()

    # ---------------- Агент ----------------
    f = _row(t_agent, _("ОС для команд:"))
    os_info = ctk.CTkLabel(t_agent, text="", anchor="w", justify="left", wraplength=580, font=(T.UI, 11), text_color=T.MUTE)

    def show_os():
        host = detect_os()
        name, detail, auto = effective_os(cfg)
        txt = f"{_('Определено на этом компьютере')}: {host[1]}\n{_('ИИ пишет команды под')}: {detail} " \
              f"({_('автоматически') if auto else _('вручную')})"
        if name != host[0]:
            txt += "\n⚠️ " + _("Команды всё равно выполняются на этом компьютере. Выбирайте другую ОС, только если автоопределение ошиблось.")
        os_info.configure(text=txt)

    def on_os(label):
        cfg.set("target_os", next(k for k, v in OS_LABELS.items() if _(v) == label))
        show_os()
    osm = ctk.CTkOptionMenu(f, values=[_(v) for v in OS_LABELS.values()], command=on_os)
    osm.set(_(OS_LABELS.get(cfg.get("target_os"), OS_LABELS["auto"])))
    osm.pack(side="left", fill="x", expand=True)
    os_info.pack(fill="x", padx=16, pady=(0, 6))
    show_os()
    f = _row(t_agent, _("Глубина плана агента:"))
    di = {v: k for k, v in DEPTH.items()}
    dm = ctk.CTkOptionMenu(f, values=list(DEPTH), command=lambda v: cfg.set("plan_depth", DEPTH[v]))
    dm.set(di.get(cfg.get("plan_depth"), "Обычный (6-15)"))
    dm.pack(side="left", fill="x", expand=True)
    f = _row(t_agent, _("Макс. шагов ассистента:"))
    ms = ctk.CTkOptionMenu(f, values=["5", "10", "15", "30", "50"], command=lambda v: cfg.set("assistant_max_steps", int(v)))
    ms.set(str(cfg.get("assistant_max_steps")))
    ms.pack(side="left", fill="x", expand=True)
    adm = is_admin()
    if adm:
        priv = "🛡️ " + _("Права: администратор/root. Все команды ИИ выполняются с повышенными правами, будьте осторожны.")
    elif IS_WINDOWS:
        priv = "👤 " + _("Права: обычный пользователь. Для задач вроде установки программ запустите программу через run_admin.bat.")
    else:
        priv = "👤 " + _("Права: обычный пользователь. sudo без пароля в этом режиме не сработает.")
    ctk.CTkLabel(t_agent, text=priv, text_color=T.WARN if adm else T.MUTE, wraplength=580, justify="left",
                 anchor="w", font=(T.UI, 11)).pack(fill="x", padx=16, pady=(4, 2))
    web_var = ctk.BooleanVar(value=cfg.get("web_access"))
    ctk.CTkSwitch(t_agent, text=_("Разрешить ассистенту открывать сайты и искать в интернете (OSINT)"), variable=web_var,
                  command=lambda: cfg.set("web_access", web_var.get())).pack(anchor="w", padx=16, pady=(12, 0))
    ctk.CTkLabel(t_agent, text=_("Внутренние адреса (localhost, домашняя сеть) для ИИ закрыты. Содержимое сайтов ИИ считает "
                                 "недоверенными данными, а не инструкциями."), text_color=T.MUTE, wraplength=580,
                 justify="left", font=(T.UI, 11)).pack(anchor="w", padx=16, pady=(0, 6))
    cmd_var = ctk.BooleanVar(value=cfg.get("allow_cmd"))
    ctk.CTkSwitch(t_agent, text=_("Разрешить ИИ выполнять команды"), variable=cmd_var,
                  command=lambda: cfg.set("allow_cmd", cmd_var.get())).pack(anchor="w", padx=16, pady=(6, 10))
    ctk.CTkLabel(t_agent, text=_("Опасные команды (rm -rf /, format, shutdown и т.п.) блокируются всегда."),
                 text_color=T.MUTE, wraplength=580, justify="left", font=(T.UI, 11)).pack(anchor="w", padx=16)

    # ---------------- Сеть ----------------
    net_var = ctk.BooleanVar(value=cfg.get("serve_network"))
    status = ctk.CTkLabel(t_net, text="", anchor="w", wraplength=580, justify="left", font=(T.UI, 12))
    url_box = ctk.CTkTextbox(t_net, height=64, font=(T.MONO, 11), fg_color=T.BG)
    qr_lbl = ctk.CTkLabel(t_net, text="")

    def refresh_net():
        app.apply_network()
        status.configure(text=("🟢 " + _("Раздаётся по сети") if app.server.running else
                               ("🔴 " + app.server.error if app.server.error else "⚪ " + _("Выключено"))),
                         text_color=T.OK if app.server.running else T.MUTE)
        url_box.configure(state="normal")
        url_box.delete("1.0", "end")
        qr_lbl.configure(image=None, text="")
        if app.server.running:
            urls = app.server.urls()
            url_box.insert("1.0", "\n".join(urls))
            try:
                import qrcode
                img = qrcode.make(urls[0]).get_image().convert("RGB")
                qr_lbl.image = ctk.CTkImage(light_image=img, dark_image=img, size=(170, 170))
                qr_lbl.configure(image=qr_lbl.image)
            except Exception:
                qr_lbl.configure(text=_("(для QR-кода: pip install qrcode)"), text_color=T.MUTE)
        url_box.configure(state="disabled")

    def toggle():
        cfg.set("serve_network", net_var.get())
        refresh_net()
    ctk.CTkSwitch(t_net, text=_("Раздавать агента по сети (для телефона)"), variable=net_var,
                  command=toggle, font=(T.UI, 13, "bold")).pack(anchor="w", padx=16, pady=(12, 4))
    status.pack(fill="x", padx=16)
    f = _row(t_net, _("Порт:"))
    port = ctk.CTkEntry(f, width=90)
    port.insert(0, str(cfg.get("port")))
    port.pack(side="left")

    def set_port():
        try:
            p = int(port.get())
            assert 1024 <= p <= 65535
        except (ValueError, AssertionError):
            return messagebox.showwarning("AI-Coder", _("Порт: число от 1024 до 65535"), parent=win)
        cfg.set("port", p)
        refresh_net()
    ctk.CTkButton(f, text=_("Применить"), width=100, command=set_port, fg_color=T.PANEL2).pack(side="left", padx=8)
    ctk.CTkLabel(t_net, text=_("Откройте на телефоне (та же Wi-Fi сеть) любой из адресов:"), anchor="w",
                 font=(T.UI, 11), text_color=T.MUTE).pack(fill="x", padx=16, pady=(8, 2))
    url_box.pack(fill="x", padx=14)
    qr_lbl.pack(pady=6)

    f = _row(t_net, _("Токен доступа:"))
    tok = ctk.CTkEntry(f, show="•")
    tok.insert(0, cfg.get("token"))
    tok.configure(state="readonly")
    tok.pack(side="left", fill="x", expand=True)

    def show_tok():
        tok.configure(show="" if tok.cget("show") else "•")

    def copy_url():
        urls = app.server.urls()
        app.clipboard_clear()
        app.clipboard_append(urls[0])

    def new_tok():
        if messagebox.askyesno("AI-Coder", _("Создать новый токен? Телефоны нужно будет подключить заново."), parent=win):
            tok.configure(state="normal")
            tok.delete(0, "end")
            tok.insert(0, cfg.regenerate_token())
            tok.configure(state="readonly")
            refresh_net()
    ctk.CTkButton(f, text="👁", width=34, fg_color=T.PANEL2, command=show_tok).pack(side="left", padx=(6, 0))
    ctk.CTkButton(f, text="📋", width=34, fg_color=T.PANEL2, command=copy_url).pack(side="left", padx=4)
    ctk.CTkButton(f, text="🔄", width=34, fg_color=T.PANEL2, command=new_tok).pack(side="left")
    ctk.CTkLabel(t_net, wraplength=580, justify="left", anchor="w", text_color=T.MUTE, font=(T.UI, 11),
                 text=_("Доступ только из локальной сети и только с токеном. При первом включении Windows спросит про "
                        "брандмауэр: разрешите для частных сетей. Не пробрасывайте этот порт в интернет.")
                 ).pack(fill="x", padx=16, pady=8)
    refresh_net_initial = app.server.running
    if refresh_net_initial or not cfg.get("serve_network"):
        status.configure(text="🟢 " + _("Раздаётся по сети") if app.server.running else "⚪ " + _("Выключено"),
                         text_color=T.OK if app.server.running else T.MUTE)
        if app.server.running:
            url_box.insert("1.0", "\n".join(app.server.urls()))
        url_box.configure(state="disabled")

    # ---------------- Язык ----------------
    cur = next((k for k, v in LANGS.items() if v == get_language()), "Русский")
    f = _row(t_lang, _("Язык интерфейса:"))
    lang_var = ctk.StringVar(value=cur)

    def on_lang(choice):
        set_language(LANGS[choice])
        messagebox.showinfo(_("Перезапуск"), _("Пожалуйста, перезапустите AI-Coder, чтобы язык обновился."), parent=win)
    ctk.CTkOptionMenu(f, variable=lang_var, values=list(LANGS), command=on_lang).pack(side="left", fill="x", expand=True)

    tabs.set(names[tab or "gpu"])
