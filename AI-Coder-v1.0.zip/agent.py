import os
import subprocess
import requests
import re
import threading
import json
import time

# Импорты отдельных файлов режимов из папки modes
from modes import agent_mode, dcoder_mode, ask_mode, assistant_mode

class AIAgent:
    def __init__(self, app):
        self.app = app

    def _get_history_context(self, chat_id):
        history = self.app.chats.get(chat_id, {}).get("history", [])
        if not history: return ""
        ctx = "--- НАЧАЛО ИСТОРИИ ПРОШЛЫХ ЗАПРОСОВ И ОТВЕТОВ ---\n"
        for msg in history[-6:]:
            role = "Пользователь" if msg["role"] == "user" else "ИИ (Ты)"
            ctx += f"{role}: {msg['content']}\n\n"
        ctx += "--- КОНЕЦ ИСТОРИИ ---\n\n"
        return ctx

    def _append_history(self, chat_id, role, content):
        chat = self.app.chats.get(chat_id)
        if chat is not None:
            if "history" not in chat: chat["history"] = []
            chat["history"].append({"role": role, "content": content})
            self.app.save_chats()

            log_dir = os.path.join(self.app.workspace_dir, self.app.BACKUP_DIR, "chat_logs")
            os.makedirs(log_dir, exist_ok=True)
            log_path = os.path.join(log_dir, f"{chat_id}.log")
            try:
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(f"[{role.upper()}]\n{content}\n{'-'*40}\n")
            except Exception: pass

    def get_workspace_tree(self):
        tree = []
        for root, dirs, files in os.walk(self.app.workspace_dir):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__' and d != self.app.BACKUP_DIR]
            level = root.replace(self.app.workspace_dir, '').count(os.sep)
            indent = ' ' * 4 * level
            tree.append(f"{indent}{os.path.basename(root)}/")
            subindent = ' ' * 4 * (level + 1)
            for f in files:
                if not f.startswith('.'): tree.append(f"{subindent}{f}")
        return "\n".join(tree[:100])

    def get_workspace_context(self):
        tree = self.get_workspace_tree()
        contents = []
        for root, dirs, files in os.walk(self.app.workspace_dir):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__' and d != self.app.BACKUP_DIR]
            for f in files:
                if f.endswith(('.py', '.txt', '.json', '.html', '.css', '.js', '.sh', '.bat', '.env')):
                    full_path = os.path.join(root, f)
                    rel_path = os.path.relpath(full_path, self.app.workspace_dir)
                    try:
                        with open(full_path, 'r', encoding='utf-8') as file_obj:
                            contents.append(f"--- ФАЙЛ: {rel_path} ---\n{file_obj.read()}\n--- КОНЕЦ ФАЙЛА ---\n")
                    except Exception: pass
        file_data = "\n".join(contents)
        if not file_data.strip(): file_data = "(Файлов пока нет)"
        return f"СТРУКТУРА ПРОЕКТА:\n{tree}\n\nАКТУАЛЬНОЕ СОДЕРЖИМОЕ ФАЙЛОВ:\n{file_data}"

    def ask_ollama(self, prompt):
        url = self.app.OLLAMA_URL
        payload = {
            "model": self.app.model_var.get(),
            "prompt": prompt,
            "stream": True,
            "options": {"temperature": float(self.app.temp_var.get()), "num_ctx": int(self.app.ctx_var.get())}
        }
        try:
            res = requests.post(url, json=payload, stream=True, timeout=300)
            if res.status_code == 200:
                full_response = ""
                for line in res.iter_lines():
                    if self.app.cancel_flag:
                        return full_response + "\n\n[🛑 ГЕНЕРАЦИЯ ПРЕРВАНА]"
                    if line:
                        full_response += json.loads(line.decode('utf-8')).get("response", "")
                return full_response
            return f"Ошибка Ollama: Статус {res.status_code}"
        except Exception as e:
            return f"Ошибка подключения: {e}"

    def rollback_changes(self):
        return self.app.backup_manager.restore_latest_backup()

    def _extract_and_run_commands(self, response, chat_id, allow_file_creation=True, allow_cmd_execution=True):
        if self.app.cancel_flag or getattr(self.app, 'pause_flag', False): return

        if allow_file_creation:
            file_blocks = re.findall(r"```file:\s*([^\n]+)\n(.*?)```", response, re.DOTALL)
            if file_blocks:
                success, msg = self.app.backup_manager.create_backup()
                if success: self.app.log(f"[Система] 📦 Создан бекап.\n", target_chat_id=chat_id)

            for filepath, content in file_blocks:
                clean_filepath = filepath.strip().lstrip('\\/')
                parts = clean_filepath.replace('\\', '/').split('/')
                root_name = os.path.basename(self.app.workspace_dir)
                if len(parts) > 1 and parts[0] == root_name:
                    clean_filepath = '/'.join(parts[1:])

                full_path = os.path.join(self.app.workspace_dir, clean_filepath)
                os.makedirs(os.path.dirname(full_path), exist_ok=True)

                # УМНАЯ ПРОВЕРКА - не меняем файл если он такой же
                if os.path.exists(full_path):
                    try:
                        with open(full_path, "r", encoding="utf-8") as f:
                            old_content = f.read()
                        if old_content.strip() == content.strip():
                            self.app.log(f"⚡ [Пропуск] Файл {clean_filepath} уже идентичен. Не изменяем.\n", target_chat_id=chat_id)
                            continue
                        else:
                            self.app.log(f"🔄 [Обновлен] Изменен файл: {clean_filepath}\n", target_chat_id=chat_id)
                    except Exception:
                        pass
                else:
                    self.app.log(f"📝 [Создан] Файл: {clean_filepath}\n", target_chat_id=chat_id)

                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(content.strip())
                self.app.after(0, self.app.refresh_file_tree)

        if not allow_cmd_execution: return

        code_blocks = re.findall(r"```(?:bash|sh|cmd|bat|powershell)?\s*\n(.*?)```", response, re.DOTALL)
        code_blocks = [b for b in code_blocks if not b.startswith("file:")]
        all_commands = []
        for block in code_blocks:
            all_commands.extend([line.strip() for line in block.split("\n") if line.strip() and not line.strip().startswith("#")])

        if all_commands:
            if hasattr(self.app, 'allow_cmd_var') and not self.app.allow_cmd_var.get():
                self.app.log("🛑 [Терминал] Выполнение команд заблокировано.\n", target_chat_id=chat_id)
            else:
                self.app.log(f"🚀 [Терминал]: Выполнение {len(all_commands)} команд...\n", target_chat_id=chat_id)
                self.execute_commands_via_script(all_commands, chat_id)
                self.app.after(0, self.app.refresh_file_tree)

    def execute_commands_via_script(self, commands, chat_id):
        target_os = self.app.os_var.get()
        cwd = self.app.workspace_dir
        script_name = "ai_run.bat" if target_os == "Windows" else "ai_run.sh"
        script_path = os.path.join(cwd, script_name)

        if target_os == "Windows":
            with open(script_path, "w", encoding="utf-8") as f:
                f.write("@echo off\necho === ИИ-КОМАНДЫ ===\n@echo on\n")
                for cmd in commands: f.write(f"{cmd}\n")
            run_cmd = ["cmd.exe", "/c", script_name]
        else:
            with open(script_path, "w", encoding="utf-8", newline='\n') as f:
                f.write("#!/bin/bash\necho \"=== ИИ-КОМАНДЫ ===\"\nset -x\n")
                for cmd in commands: f.write(f"{cmd}\n")
            os.chmod(script_path, 0o755)
            run_cmd = ["bash", script_path]

        try:
            self.app.after(0, lambda: self.app.cmd_output.delete("1.0", "end"))
            process = subprocess.Popen(run_cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
            def read_output():
                try:
                    for line in process.stdout:
                        self.app.after(0, lambda l=line: self.app.cmd_output.insert("end", l))
                        self.app.after(0, lambda: self.app.cmd_output.see("end"))
                except: pass
            threading.Thread(target=read_output, daemon=True).start()

            for _ in range(1200):
                if self.app.cancel_flag:
                    process.kill()
                    self.app.log(f"🛑 [Терминал] Выполнение скрипта прервано!\n", target_chat_id=chat_id)
                    return False
                if process.poll() is not None: break
                time.sleep(0.1)

            return process.returncode == 0
        except Exception as e:
            self.app.log(f"❌ [Ошибка терминала]: {e}\n", target_chat_id=chat_id)
            return False

    # --- МАРШРУТИЗАТОРЫ ДЛЯ РЕЖИМОВ ---
    def run_query_mode(self, task, chat_id): ask_mode.run(self, task, chat_id)
    def run_assistant_mode(self, task, chat_id): assistant_mode.run(self, task, chat_id)
    def run_multi_step_pipeline(self, task, chat_id): agent_mode.run(self, task, chat_id)
    def run_dcoder_mode(self, structure, content, chat_id): dcoder_mode.run(self, structure, content, chat_id)
