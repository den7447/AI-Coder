import os
import platform
import subprocess
import threading
import webbrowser
import customtkinter as ctk
import tkinter as tk
from tkinter import messagebox
from i18n import _ # Подключаем ядро переводов

class CodeEditorModule(ctk.CTkFrame):
    def __init__(self, parent, app):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.pack(fill="both", expand=True)

        self.top_bar = ctk.CTkFrame(self, fg_color="transparent")
        self.top_bar.pack(fill="x", pady=(0, 5))

        self.lbl_current_file = ctk.CTkLabel(self.top_bar, text=_("Файл не выбран"), font=("Arial", 13, "bold"), text_color="#888888")
        self.lbl_current_file.pack(side="left", padx=5)

        self.btn_run_project = ctk.CTkButton(self.top_bar, text=_("▶️ Запустить проект"), fg_color="#2b8a3e", hover_color="#2b7032", command=self.run_project)
        self.btn_save_file = ctk.CTkButton(self.top_bar, text=_("💾 Сохранить"), fg_color="#1f538d", command=self.save_file)

        self.app.anim_queue.append((self.btn_run_project, 'pack', {'side': "right", 'padx': 5}))
        self.app.anim_queue.append((self.btn_save_file, 'pack', {'side': "right", 'padx': 5}))

        self.code_editor = ctk.CTkTextbox(self, font=("Consolas", 13))
        self.code_editor.pack(fill="both", expand=True)

        self.ai_panel = ctk.CTkFrame(self, height=80)
        self.ai_panel.pack(fill="x", pady=(5, 0))

        self.ai_mode_var = ctk.StringVar(value="AGENT")
        self.ai_mode_menu = ctk.CTkOptionMenu(self.ai_panel, values=["AGENT", "ASK"], variable=self.ai_mode_var, width=90, fg_color="#4a148c")
        self.ai_mode_menu.pack(side="left", padx=5, pady=5)

        self.mini_prompt = ctk.CTkTextbox(self.ai_panel, height=60, font=("Arial", 12), wrap="word")
        self.mini_prompt.pack(side="left", fill="both", expand=True, padx=5, pady=5)

        self.btn_send_mini = ctk.CTkButton(self.ai_panel, text=_("🚀 Отправить"), width=100, command=self.run_mini_ai)
        self.app.anim_queue.append((self.btn_send_mini, 'pack', {'side': "left", 'padx': 5, 'pady': 5}))

        self.mini_prompt.bind("<Control-Return>", lambda e: self.run_mini_ai())

    def load_file(self, filepath):
        self.app.current_open_file = filepath
        try:
            with open(filepath, 'r', encoding='utf-8') as f: content = f.read()
            self.code_editor.delete("1.0", "end")
            self.code_editor.insert("1.0", content)
            self.lbl_current_file.configure(text=f"Editing: {os.path.basename(filepath)}", text_color="#4CAF50")
        except Exception:
            messagebox.showwarning(_("Внимание"), "Binary file cannot be opened.")

    def save_file(self):
        if self.app.current_open_file:
            try:
                content = self.code_editor.get("1.0", "end")
                with open(self.app.current_open_file, 'w', encoding='utf-8') as f: f.write(content.strip("\n"))
                messagebox.showinfo(_("Успех"), _("Файл сохранен!"))
            except Exception as e:
                messagebox.showerror(_("Ошибка"), f"Error: {e}")

    def run_project(self):
        wd = self.app.workspace_dir
        candidates = ["main.py", "app.py", "index.py", "index.js", "main.js", "server.js", "run.bat", "run.sh"]
        target = None

        for c in candidates:
            if os.path.exists(os.path.join(wd, c)):
                target = os.path.join(wd, c)
                break

        if not target and self.app.current_open_file:
            target = self.app.current_open_file

        if target:
            self.run_file_in_terminal(target)
        else:
            messagebox.showinfo("Info", "No main executable found.")

    def run_file_in_terminal(self, filepath):
        ext = os.path.splitext(filepath)[1].lower()
        wd = os.path.dirname(filepath)
        filename = os.path.basename(filepath)
        cmd = ""

        if ext == ".py":
            cmd = f"python3 \"{filename}\"" if platform.system() != "Windows" else f"python \"{filename}\""
        elif ext == ".js": cmd = f"node \"{filename}\""
        elif ext in [".html", ".htm"]:
            webbrowser.open(f"file://{filepath}")
            return
        elif ext in [".bat", ".cmd"]: cmd = f"\"{filename}\""
        elif ext == ".sh": cmd = f"bash \"{filename}\""
        else:
            messagebox.showinfo("Info", f"Unknown run format: {ext}")
            return

        try:
            if platform.system() == "Windows":
                subprocess.Popen(f'start cmd.exe /k "{cmd}"', shell=True, cwd=wd)
            else:
                terminals = ["gnome-terminal", "x-terminal-emulator", "konsole", "xterm", "lxterminal"]
                for term in terminals:
                    import shutil
                    if shutil.which(term):
                        subprocess.Popen([term, "--", "bash", "-c", f"{cmd}; echo '\n[Finished]'; exec bash"], cwd=wd)
                        return
                messagebox.showerror(_("Ошибка"), _("Не найден эмулятор терминала Linux."))
        except Exception as e:
            messagebox.showerror(_("Ошибка"), f"Error: {e}")

    def run_mini_ai(self):
        if not self.app.current_open_file:
            messagebox.showwarning(_("Внимание"), _("Файл не выбран"))
            return

        task = self.mini_prompt.get("1.0", "end").strip()
        if not task: return

        mode = self.ai_mode_var.get()
        self.mini_prompt.delete("1.0", "end")
        self.btn_send_mini.configure(state="disabled", text="⏳...")

        threading.Thread(target=self._mini_ai_thread, args=(task, mode), daemon=True).start()

    def _mini_ai_thread(self, task, mode):
        filepath = self.app.current_open_file
        rel_path = os.path.relpath(filepath, self.app.workspace_dir)

        current_code = self.code_editor.get("1.0", "end").strip("\n")
        with open(filepath, 'w', encoding='utf-8') as f: f.write(current_code)

        if mode == "ASK":
            self.app.log(f"\n[❓ ASK ({rel_path})]: {task}\n")
            prompt = f"Ты ИИ-помощник. Вопрос ТОЛЬКО по этому файлу: {rel_path}.\nКод:\n```\n{current_code}\n```\nВопрос: {task}"
            resp = self.app.agent.ask_ollama(prompt)
            self.app.log(f"🤖 [Ответ]:\n{resp}\n")
            self.app.after(0, lambda: self.app.tabview.set(_("💬 Терминал ИИ")))

        elif mode == "AGENT":
            self.app.log(f"\n[⚙️ AGENT ({rel_path})]: {task}\n")

            prompt = (
                f"Контекст:\n{self.app.agent.get_workspace_context()}\n\n"
                f"Измени СТРОГО текущий файл: {rel_path}\n"
                f"ЗАДАЧА: {task}\n\n"
                f"ВЫВЕДИ ВЕСЬ НОВЫЙ КОД ФАЙЛА ЦЕЛИКОМ:\n"
                f"```file: {rel_path}\n<ВЕСЬ КОД>\n```"
            )
            resp = self.app.agent.ask_ollama(prompt)

            self.app.log(f"🤖 [Сохраняю...]\n")
            self.app.agent._extract_and_run_commands(resp, self.app.current_chat_id, allow_file_creation=True, allow_cmd_execution=False)
            self.app.after(100, lambda: self.load_file(filepath))

        self.app.after(0, lambda: self.btn_send_mini.configure(state="normal", text=_("🚀 Отправить")))
