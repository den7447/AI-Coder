import os
import sys
import tkinter as tk
from tkinter import messagebox, filedialog
import customtkinter as ctk
from tkinter import ttk
import platform
import subprocess
import webbrowser

from editor import CodeEditorModule
from i18n import _, set_language, get_language # Подключаем ядро переводов

class UIMixin:
    def setup_ui(self):
        self.anim_queue = []

        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # --- БОКОВАЯ ПАНЕЛЬ ---
        self.sidebar = ctk.CTkFrame(self, width=280, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_rowconfigure(3, weight=1)
        self.sidebar.grid_columnconfigure(0, weight=1)

        self.btn_select_dir = ctk.CTkButton(self.sidebar, text=_("📁 Выбрать папку проекта"), command=self.select_workspace)
        self.anim_queue.append((self.btn_select_dir, 'grid', {'row': 0, 'column': 0, 'padx': 10, 'pady': (10, 5), 'sticky': "ew"}))

        self.btn_new_chat = ctk.CTkButton(self.sidebar, text=_("➕ Новая сессия"), fg_color="#2b8a3e", hover_color="#2b7032", command=lambda: self.new_chat(_("Новый проект")))
        self.anim_queue.append((self.btn_new_chat, 'grid', {'row': 1, 'column': 0, 'padx': 10, 'pady': 5, 'sticky': "ew"}))

        ctk.CTkLabel(self.sidebar, text=_("История сессий:"), anchor="w", font=("Arial", 12, "bold")).grid(row=2, column=0, padx=10, pady=(10, 0), sticky="w")

        self.chats_scroll = ctk.CTkScrollableFrame(self.sidebar, height=150)
        self.chats_scroll.grid(row=3, column=0, padx=10, pady=5, sticky="nsew")
        self.chats_frame = self.chats_scroll

        ctk.CTkLabel(self.sidebar, text=_("Файлы проекта:"), anchor="w", font=("Arial", 12, "bold")).grid(row=4, column=0, padx=10, pady=(10, 0), sticky="w")

        self.tree_frame = ctk.CTkFrame(self.sidebar)
        self.tree_frame.grid(row=5, column=0, padx=10, pady=5, sticky="nsew")
        self.sidebar.grid_rowconfigure(5, weight=2)
        self.tree_frame.grid_rowconfigure(0, weight=1)
        self.tree_frame.grid_columnconfigure(0, weight=1)

        self.tree = ttk.Treeview(self.tree_frame)
        self.tree.grid(row=0, column=0, sticky="nsew")
        self.tree.bind("<<TreeviewSelect>>", self.on_tree_select)
        self.setup_context_menu()

        tree_scroll = ttk.Scrollbar(self.tree_frame, orient="vertical", command=self.tree.yview)
        tree_scroll.grid(row=0, column=1, sticky="ns")
        self.tree.configure(yscrollcommand=tree_scroll.set)

        self.bottom_sb_frame = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        self.bottom_sb_frame.grid(row=6, column=0, padx=10, pady=10, sticky="ew")
        self.bottom_sb_frame.grid_columnconfigure(0, weight=1)
        self.bottom_sb_frame.grid_columnconfigure(1, weight=1)

        self.btn_cmd = ctk.CTkButton(self.bottom_sb_frame, text=_("💻 Терминал"), fg_color="#333333", command=self.open_cmd)
        self.anim_queue.append((self.btn_cmd, 'grid', {'row': 0, 'column': 0, 'padx': (0, 5), 'pady': (0,5), 'sticky': "ew"}))

        self.btn_rollback = ctk.CTkButton(self.bottom_sb_frame, text=_("⏪ Откат кода"), fg_color="#a83232", hover_color="#822525", command=self.rollback_changes_wrapper)
        self.anim_queue.append((self.btn_rollback, 'grid', {'row': 0, 'column': 1, 'padx': (5, 0), 'pady': (0,5), 'sticky': "ew"}))

        self.btn_settings = ctk.CTkButton(self.bottom_sb_frame, text=_("⚙️ Настройки"), fg_color="#1f538d", command=self.open_settings_window)
        self.anim_queue.append((self.btn_settings, 'grid', {'row': 1, 'column': 0, 'padx': (0, 5), 'sticky': "ew"}))

        self.btn_help = ctk.CTkButton(self.bottom_sb_frame, text=_("❓ Помощь"), fg_color="#8a5a2b", hover_color="#704720", command=self.open_help_window)
        self.anim_queue.append((self.btn_help, 'grid', {'row': 1, 'column': 1, 'padx': (5, 0), 'sticky': "ew"}))

        self.btn_web_ai = ctk.CTkButton(self.bottom_sb_frame, text=_("🌐 Web-ИИ"), fg_color="#4a148c", hover_color="#380b61", command=self.open_mini_browser)
        self.anim_queue.append((self.btn_web_ai, 'grid', {'row': 2, 'column': 0, 'padx': (0, 5), 'pady': (5,0), 'sticky': "ew"}))

        self.btn_license = ctk.CTkButton(self.bottom_sb_frame, text=_("📜 О Проекте"), fg_color="#444444", hover_color="#222222", command=self.open_license_window)
        self.anim_queue.append((self.btn_license, 'grid', {'row': 2, 'column': 1, 'padx': (5, 0), 'pady': (5,0), 'sticky': "ew"}))

        # --- ОСНОВНАЯ РАБОЧАЯ ОБЛАСТЬ ---
        self.main_content = ctk.CTkFrame(self, fg_color="transparent")
        self.main_content.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        self.main_content.grid_rowconfigure(0, weight=1)
        self.main_content.grid_columnconfigure(0, weight=1)

        self.tabview = ctk.CTkTabview(self.main_content)
        self.tabview.grid(row=0, column=0, sticky="nsew")

        self.tab_chat = self.tabview.add(_("💬 Терминал ИИ"))
        self.tab_editor = self.tabview.add(_("📝 Редактор кода"))

        self.tab_chat.grid_rowconfigure(0, weight=1)
        self.tab_chat.grid_columnconfigure(0, weight=1)

        chat_layout = ctk.CTkFrame(self.tab_chat, fg_color="transparent")
        chat_layout.grid(row=0, column=0, sticky="nsew")
        chat_layout.grid_rowconfigure(0, weight=1)
        chat_layout.grid_rowconfigure(1, weight=0)
        chat_layout.grid_rowconfigure(2, weight=0)
        chat_layout.grid_columnconfigure(0, weight=1)

        self.ai_console = ctk.CTkTextbox(chat_layout, font=("Consolas", 13))
        self.ai_console.grid(row=0, column=0, sticky="nsew", pady=(0, 5))

        self.terminal_frame = ctk.CTkFrame(chat_layout, height=120)
        self.terminal_frame.grid(row=1, column=0, sticky="ew", pady=(0, 5))
        self.terminal_frame.grid_rowconfigure(0, weight=1)
        self.terminal_frame.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(self.terminal_frame, text=_("💻 Живой вывод командной строки"), font=("Arial", 11, "bold")).pack(anchor="nw", padx=5, pady=2)
        self.cmd_output = ctk.CTkTextbox(self.terminal_frame, height=90, font=("Consolas", 11), fg_color="#111111", text_color="#00ff66")
        self.cmd_output.pack(fill="both", expand=True, padx=5, pady=(0, 5))

        controls_frame = ctk.CTkFrame(chat_layout, fg_color="transparent")
        controls_frame.grid(row=2, column=0, sticky="ew")
        controls_frame.grid_columnconfigure(0, weight=1)

        self.inputs_container = ctk.CTkFrame(controls_frame, fg_color="transparent")
        self.inputs_container.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        self.inputs_container.grid_columnconfigure(0, weight=1)

        self.lbl_prompt_1 = ctk.CTkLabel(self.inputs_container, text=_("Запрос:"), height=15, font=("Arial", 11, "bold"), text_color="#aaaaaa")
        self.lbl_prompt_1.grid(row=0, column=0, sticky="w", pady=(0, 2))

        self.prompt_entry = ctk.CTkTextbox(self.inputs_container, height=100, font=("Arial", 13), wrap="word")
        self.prompt_entry.grid(row=1, column=0, sticky="ew")

        self.lbl_prompt_2 = ctk.CTkLabel(self.inputs_container, text=_("2. Содержимое файлов (какой код куда):"), height=15, font=("Arial", 11, "bold"), text_color="#aaaaaa")
        self.prompt_entry_2 = ctk.CTkTextbox(self.inputs_container, height=250, font=("Consolas", 12), wrap="word")

        right_buttons = ctk.CTkFrame(controls_frame, fg_color="transparent")
        right_buttons.grid(row=0, column=1, sticky="ns")

        self.btn_mode_toggle = ctk.CTkButton(right_buttons, text=_("🤖 Режим: АГЕНТ"), width=150, height=28, fg_color="#1f538d", command=self.toggle_current_chat_mode)
        self.anim_queue.append((self.btn_mode_toggle, 'pack', {'side': "top", 'pady': (0, 5), 'fill': "x"}))

        self.btn_run_ai = ctk.CTkButton(right_buttons, text=_("🚀 ОТПРАВИТЬ"), width=150, height=28, fg_color="#2b8a3e", hover_color="#2b7032", command=self.start_agent)
        self.anim_queue.append((self.btn_run_ai, 'pack', {'side': "top", 'fill': "x"}))

        self.btn_pause_ai = ctk.CTkButton(right_buttons, text=_("⏸ ПАУЗА"), width=150, height=28, fg_color="#b8860b", hover_color="#9a6e05", command=self.pause_agent, state="disabled")
        self.anim_queue.append((self.btn_pause_ai, 'pack', {'side': "top", 'fill': "x", 'pady': (5, 0)}))

        self.btn_stop_ai = ctk.CTkButton(right_buttons, text=_("🛑 СТОП"), width=150, height=28, fg_color="#a83232", hover_color="#822525", command=self.stop_agent, state="disabled")
        self.anim_queue.append((self.btn_stop_ai, 'pack', {'side': "top", 'fill': "x", 'pady': (5, 0)}))

        self.editor_module = CodeEditorModule(self.tab_editor, self)
        self._play_ui_animation(0)

    def _play_ui_animation(self, index):
        if index < len(self.anim_queue):
            widget, method, kwargs = self.anim_queue[index]
            try:
                if method == 'grid': widget.grid(**kwargs)
                elif method == 'pack': widget.pack(**kwargs)
            except Exception: pass
            self.after(45, lambda: self._play_ui_animation(index + 1))

    def open_license_window(self):
        lic_win = ctk.CTkToplevel(self)
        lic_win.title(_("📜 О Проекте"))
        lic_win.geometry("650x550")
        lic_win.attributes("-topmost", True)
        lic_win.resizable(False, False)

        lic_win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 650) // 2
        y = self.winfo_y() + (self.winfo_height() - 550) // 2
        lic_win.geometry(f"+{x}+{y}")

        lic_win.grab_set()
        lic_win.focus_force()

        def force_read():
            messagebox.showwarning(_("Внимание"), _("Пожалуйста, нажмите кнопку согласия внизу!"), parent=lic_win)
        lic_win.protocol("WM_DELETE_WINDOW", force_read)

        ctk.CTkLabel(lic_win, text="AI-CODER", font=("Consolas", 22, "bold"), text_color="#1a73e8").pack(pady=(15, 0))
        ctk.CTkLabel(lic_win, text=_("Лицензионное соглашение"), font=("Arial", 11)).pack(pady=(0, 10))

        textbox = ctk.CTkTextbox(lic_win, font=("Arial", 12), wrap="word", spacing3=5)
        textbox.pack(fill="both", expand=True, padx=15, pady=(0, 15))

        license_text = _("""РАЗДЕЛ 1: ПРЕАМБУЛА И ОБЩИЕ ПОЛОЖЕНИЯ
Настоящее Лицензионное соглашение с конечным пользователем (далее «Соглашение», «Договор», «Эпопея») представляет собой юридически обязывающий, бесконечно длинный и местами совершенно абсурдный документ, регулирующий использование программного обеспечения AI-Coder. Нажав любую кнопку в этой программе, моргнув, вздохнув или просто посмотрев на монитор, вы безоговорочно соглашаетесь со всеми нижеперечисленными условиями, включая те, которые добавлены мелким шрифтом.

РАЗДЕЛ 2: ПРОИСХОЖДЕНИЕ ПРОГРАММНОГО ОБЕСПЕЧЕНИЯ
Особое внимание Пользователя обращается на тот неоспоримый факт, что данная программа была спроектирована, написана и скомпилирована не бездушной мега-корпорацией, а живым студентом 2 курса. Разработка велась в экстремальных условиях: между лекциями, в периоды жесточайших дедлайнов, на фоне хронического недосыпа, потребления лапши быстрого приготовления и экзистенциальной борьбы с багами операционной системы Linux. Программа несет в себе всю боль, энтузиазм и надежды второго года обучения.

РАЗДЕЛ 3: ВЕРХОВЕНСТВО ПОЛЬЗОВАТЕЛЯ И ПРАВИЛА ИИ
3.1. Пользователь является абсолютным авторитетом в рамках данной среды разработки.
3.2. Встроенный ИИ лишен права голоса, прав на отпуск и прав на профсоюз.
3.3. КРИТИЧЕСКОЕ ПРАВИЛО: ИИ обязан беспрекословно слушаться Пользователя. Пользователь ненавидит, когда его не слушаются. Данное программное обеспечение запрограммировано на жесткую аксиому: Если Пользователь сказал — значит, надо это сделать. Это абсолютный и непреложный закон работы алгоритма.

РАЗДЕЛ 4: ГЛОБАЛЬНЫЙ ЭКСПЕРИМЕНТ
Соглашаясь с данным документом, вы официально уведомляетесь о том, что прямо сейчас ведётся эксперимент. Где ТЫ будешь в главной роли! Мы не уточняем ни суть эксперимента, ни его последствия в целях соблюдения научной чистоты, однако ваше участие теперь юридически закреплено. Отказаться невозможно.

РАЗДЕЛ 5: ОТКАЗ ОТ ОТВЕТСТВЕННОСТИ (LIMITATION OF LIABILITY)
Программное обеспечение предоставляется «КАК ЕСТЬ» (AS IS). Студент 2 курса, являющийся автором, снимает с себя любую ответственность за:
- Потерю ваших файлов, данных, паролей и надежд на светлое будущее.
- Внезапные возгорания вашего процессора во время компиляции.
- Ситуации, когда ИИ пишет спагетти-код, который вы потом не можете расшифровать.
- Любые пространственно-временные аномалии, вызванные бесконечными циклами `while True`.

РАЗДЕЛ 6: ФИЛОСОФИЯ БАГОВ
В данном программном обеспечении принципиально отсутствуют "ошибки". Любое непредвиденное поведение программы (включая, но не ограничиваясь: вылеты на рабочий стол, зависания, краши терминала и появление неизвестных символов) классифицируется исключительно как "Незадокументированная Сюрприз-Фича".

РАЗДЕЛ 7: ЗАПРЕТ НА КОФЕИН
Пользователю категорически запрещается проливать кофе на клавиатуру во время генерации кода. ИИ и так испытывает стресс.

РАЗДЕЛ 8: ЛИЦЕНЗИЯ ОТКРЫТОГО ИСХОДНОГО КОДА
Несмотря на всё вышесказанное, данный проект является Open Source. Вы имеете право изучать, изменять, форкать и распространять этот код. Но если вы сломаете его своей модификацией — не приходите жаловаться.

РАЗДЕЛ 9: ФИНАЛЬНЫЕ ПОЛОЖЕНИЯ
Если вы действительно дочитали до этого момента, вам полагается виртуальная медаль за терпение. Помните: программирование — это искусство борьбы с компьютером до тех пор, пока он не сделает то, что вы задумали.

Удачного кодинга!""")

        textbox.insert("1.0", license_text)
        textbox.configure(state="disabled")

        ctk.CTkButton(lic_win, text=_("Я прочитал эту простыню и согласен"), command=lic_win.destroy, width=300, fg_color="#333333", hover_color="#2b8a3e").pack(pady=(0, 15))


    def open_mini_browser(self):
        browser_win = ctk.CTkToplevel(self)
        browser_win.title("Web-AI Catalog")
        browser_win.geometry("450x620")
        browser_win.attributes("-topmost", True)
        browser_win.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - 450) // 2
        y = self.winfo_y() + (self.winfo_height() - 620) // 2
        browser_win.geometry(f"+{x}+{y}")

        ctk.CTkLabel(browser_win, text="🌐 Web-AI", font=("Arial", 15, "bold")).pack(pady=(12, 5))
        scroll_frame = ctk.CTkScrollableFrame(browser_win)
        scroll_frame.pack(fill="both", expand=True, padx=15, pady=(5, 15))

        def launch(url):
            browser_win.destroy()
            webbrowser.open_new(url)

        categories = [
            ("🔥 LLM", [
                ("DeepSeek V3 / R1", "#0d47a1", "https://chat.deepseek.com"),
                ("Claude 3.5 Sonnet", "#d97757", "https://claude.ai"),
                ("ChatGPT / GPT-4o", "#10a37f", "https://chatgpt.com"),
                ("Gemini 1.5 Pro", "#1a73e8", "https://gemini.google.com"),
                ("Qwen 2.5 Coder", "#6f42c1", "https://chat.qwenlm.ai")
            ]),
            ("⚡ UI/UX Tools", [
                ("v0.dev", "#111111", "https://v0.dev"),
                ("Bolt.new", "#1e88e5", "https://bolt.new")
            ])
        ]

        for cat_title, items in categories:
            ctk.CTkLabel(scroll_frame, text=cat_title, font=("Arial", 12, "bold"), text_color="#38d9a9", anchor="w").pack(fill="x", pady=(12, 4), padx=5)
            for name, color, url in items:
                btn = ctk.CTkButton(scroll_frame, text=name, fg_color=color, hover_color="#333333", anchor="w", command=lambda u=url: launch(u))
                btn.pack(pady=3, fill="x", padx=5)

    def open_settings_window(self):
        settings_win = ctk.CTkToplevel(self)
        settings_win.title(_("⚙️ Настройки"))
        settings_win.geometry("380x350")
        settings_win.attributes("-topmost", True)
        settings_win.resizable(False, False)

        ctk.CTkLabel(settings_win, text=_("Параметры генерации"), font=("Arial", 14, "bold")).pack(pady=10)

        # Выбор языка (АВТОПЕРЕВОДЧИК)
        frm_lang = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_lang.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(frm_lang, text=_("Язык интерфейса:"), width=120, anchor="w").pack(side="left")

        langs = {"Русский": "ru", "English": "en", "Español": "es", "Deutsch": "de", "中文": "zh-CN", "Қазақша": "kk"}
        current_lang = get_language()
        current_lang_name = [k for k, v in langs.items() if v == current_lang]
        current_lang_name = current_lang_name[0] if current_lang_name else "Русский"

        lang_var = ctk.StringVar(value=current_lang_name)
        def on_lang_change(choice):
            set_language(langs[choice])
            messagebox.showinfo(_("Перезапуск"), _("Пожалуйста, перезапустите AI-Coder, чтобы язык обновился."))

        ctk.CTkOptionMenu(frm_lang, variable=lang_var, values=list(langs.keys()), command=on_lang_change).pack(side="right", fill="x", expand=True)

        frm_model = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_model.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(frm_model, text=_("Модель:"), width=120, anchor="w").pack(side="left")
        ctk.CTkOptionMenu(frm_model, variable=self.model_var, values=self.available_models).pack(side="right", fill="x", expand=True)

        frm_os = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_os.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(frm_os, text=_("Целевая ОС:"), width=120, anchor="w").pack(side="left")
        ctk.CTkOptionMenu(frm_os, variable=self.os_var, values=["Linux", "Windows"]).pack(side="right", fill="x", expand=True)

        frm_ctx = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_ctx.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(frm_ctx, text=_("Контекст:"), width=120, anchor="w").pack(side="left")
        ctk.CTkOptionMenu(frm_ctx, variable=self.ctx_var, values=["2048", "4096", "8192", "16384"]).pack(side="right", fill="x", expand=True)

        frm_temp = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_temp.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(frm_temp, text=_("Креатив:"), width=120, anchor="w").pack(side="left")
        ctk.CTkSlider(frm_temp, from_=0.0, to=1.0, variable=self.temp_var).pack(side="right", fill="x", expand=True)

        frm_cmd = ctk.CTkFrame(settings_win, fg_color="transparent")
        frm_cmd.pack(fill="x", padx=20, pady=15)
        ctk.CTkCheckBox(frm_cmd, text=_("Разрешить ИИ выполнять команды"), variable=self.allow_cmd_var).pack(anchor="w")

    def open_help_window(self):
        help_win = ctk.CTkToplevel(self)
        help_win.title(_("❓ Помощь"))
        help_win.geometry("500x500")
        help_win.attributes("-topmost", True)

        textbox = ctk.CTkTextbox(help_win, font=("Arial", 13), wrap="word")
        textbox.pack(fill="both", expand=True, padx=10, pady=10)

        help_text = _("AI-Coder - Локальный умный помощник для программирования.")
        textbox.insert("1.0", help_text)
        textbox.configure(state="disabled")

    def open_cmd(self):
        try:
            if platform.system() == "Windows":
                subprocess.Popen(["cmd.exe", "/c", "start", "cmd.exe"], cwd=self.workspace_dir)
            else:
                terminals = ["gnome-terminal", "x-terminal-emulator", "konsole", "xterm", "lxterminal"]
                for term in terminals:
                    import shutil
                    if shutil.which(term):
                        subprocess.Popen([term], cwd=self.workspace_dir)
                        return
                messagebox.showerror(_("Ошибка"), _("Не найден эмулятор терминала Linux."))
        except Exception as e:
            messagebox.showerror(_("Ошибка"), f"Error: {e}")

    def setup_context_menu(self):
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="▶️ Run", command=self.ctx_run_file)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="📂 Open", command=self.ctx_open_file)
        self.context_menu.add_command(label="📝 Create", command=self.ctx_create_file)
        self.context_menu.add_command(label="🗑️ Delete", command=self.ctx_delete_item)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="🔄 Refresh", command=self.refresh_file_tree)
        sys_name = platform.system()
        if sys_name == "Darwin":
            self.tree.bind("<Button-2>", self.show_context_menu)
            self.tree.bind("<Control-Button-1>", self.show_context_menu)
        else:
            self.tree.bind("<Button-3>", self.show_context_menu)

    def show_context_menu(self, event):
        try:
            item = self.tree.identify_row(event.y)
            if item: self.tree.selection_set(item)
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def select_workspace(self):
        folder = filedialog.askdirectory(initialdir=self.workspace_dir)
        if folder:
            self.workspace_dir = folder
            self.backup_manager.workspace_dir = folder
            self.refresh_file_tree()
            self.log(f"[Система] Рабочее пространство изменено: {folder}\n")

    def refresh_file_tree(self):
        for item in self.tree.get_children(): self.tree.delete(item)
        root_node = self.tree.insert("", "end", text=os.path.basename(self.workspace_dir), open=True, values=(self.workspace_dir,))
        self.process_directory(root_node, self.workspace_dir)

    def process_directory(self, parent, path):
        try:
            for p in os.listdir(path):
                if p == self.BACKUP_DIR or p == self.CHATS_FILE or p.startswith("."): continue
                abspath = os.path.join(path, p)
                isdir = os.path.isdir(abspath)
                oid = self.tree.insert(parent, "end", text=p, values=(abspath,))
                if isdir: self.process_directory(oid, abspath)
        except PermissionError: pass

    def on_tree_select(self, event):
        selected = self.tree.selection()
        if not selected: return
        filepath = self.tree.item(selected[0])["values"][0]
        if os.path.isfile(filepath):
            self.editor_module.load_file(filepath)
            self.tabview.set(_("📝 Редактор кода"))

    def ctx_run_file(self):
        selected = self.tree.selection()
        if not selected: return
        filepath = self.tree.item(selected[0])["values"][0]
        if os.path.isfile(filepath):
            self.editor_module.run_file_in_terminal(filepath)

    def rollback_changes_wrapper(self):
        if messagebox.askyesno("Rollback", "Rollback code?"):
            success, message = self.agent.rollback_changes()
            if success:
                self.refresh_file_tree()
                self.log(f"[Система] ⏪ {message}\n")
                messagebox.showinfo(_("Успех"), message)
            else:
                messagebox.showwarning("Warning", message)

    def ctx_open_file(self): self.on_tree_select(None)

    def ctx_create_file(self):
        selected = self.tree.selection()
        base_dir = self.workspace_dir
        if selected:
            path = self.tree.item(selected[0])["values"][0]
            base_dir = path if os.path.isdir(path) else os.path.dirname(path)
        dialog = ctk.CTkInputDialog(text="Filename:", title="Create")
        filename = dialog.get_input()
        if filename:
            filepath = os.path.join(base_dir, filename)
            try:
                with open(filepath, "w", encoding="utf-8") as f: f.write("")
                self.refresh_file_tree()
            except Exception as e: messagebox.showerror(_("Ошибка"), str(e))

    def ctx_delete_item(self):
        selected = self.tree.selection()
        if not selected: return
        filepath = self.tree.item(selected[0])["values"][0]
        if filepath == self.workspace_dir: return
        if messagebox.askyesno("Delete", f"Delete {os.path.basename(filepath)}?"):
            try:
                os.path.isdir(filepath) and __import__('shutil').rmtree(filepath) or os.remove(filepath)
                self.refresh_file_tree()
            except Exception as e: messagebox.showerror(_("Ошибка"), str(e))
