import os
import sys
import subprocess
import json
import uuid
import threading
import platform
import time
import requests
import tkinter as tk
from tkinter import filedialog, messagebox
import customtkinter as ctk

# --- БЕЗОПАСНАЯ СИСТЕМА УСТАНОВКИ ЗАВИСИМОСТЕЙ ---
def check_and_install_dependencies():
    if os.environ.get('AI_CODER_INSTALL_LOOP_PREVENT') == '1':
        return

    required_packages = {
        'customtkinter': 'customtkinter',
        'requests': 'requests'
    }
    missing = []

    for module_name, pip_name in required_packages.items():
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        missing = list(set(missing))
        print(f"\n⚙️ [СИСТЕМА] Отсутствуют библиотеки: {', '.join(missing)}")
        print("🚀 Начинаю автоматическую установку (pip install). Пожалуйста, подождите...\n")
        try:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', *missing, '--break-system-packages'])
            print("\n✅ [УСПЕХ] Зависимости установлены! Перезапускаю...\n")
            os.environ['AI_CODER_INSTALL_LOOP_PREVENT'] = '1'
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:
            print(f"\n❌ [КРИТИЧЕСКАЯ ОШИБКА] Не удалось установить пакеты.\nДетали: {e}")
            sys.exit(1)

check_and_install_dependencies()

from agent import AIAgent
from gui import UIMixin
from backup_manager import BackupManager

OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "qwen2.5-coder:7b"
CHATS_FILE = "chats.json"
BACKUP_DIR = ".ai_backup"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# --- АНИМИРОВАННЫЙ ЭКРАН ЗАГРУЗКИ ---
class LoadingSplash(ctk.CTkToplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Запуск AI-Coder")
        self.geometry("480x280")
        self.resizable(False, False)
        self.attributes("-topmost", True)
        self.overrideredirect(True)
        self.configure(fg_color="#0a0a0a")

        self.update_idletasks()
        x = (self.winfo_screenwidth() - 480) // 2
        y = (self.winfo_screenheight() - 280) // 2
        self.geometry(f"+{x}+{y}")

        self.border = ctk.CTkFrame(self, fg_color="transparent", border_width=2, border_color="#1f538d")
        self.border.pack(fill="both", expand=True, padx=5, pady=5)

        ctk.CTkLabel(self.border, text="AI-CODER", font=("Consolas", 28, "bold"), text_color="#00ff66").pack(pady=(40, 5))
        ctk.CTkLabel(self.border, text="Автономная среда разработки", font=("Arial", 12), text_color="#888888").pack(pady=(0, 20))

        self.label_status = ctk.CTkLabel(self.border, text="Инициализация ядра...", font=("Consolas", 12), text_color="#1a73e8")
        self.label_status.pack(pady=5)

        self.progress_bar = ctk.CTkProgressBar(self.border, width=350, mode="indeterminate", progress_color="#1a73e8")
        self.progress_bar.pack(pady=15)

        self.anim_texts = [
            "Подключение к локальному ИИ...",
            "Синтез нейронных связей...",
            "Проверка файловой системы...",
            "Инициализация графики...",
            "Подготовка рабочего пространства..."
        ]
        self.anim_index = 0
        self.animate_loading()

    def animate_loading(self):
        if self.winfo_exists():
            self.label_status.configure(text=self.anim_texts[self.anim_index])
            self.anim_index = (self.anim_index + 1) % len(self.anim_texts)
            self.after(600, self.animate_loading)

    def update_status(self, text):
        if self.winfo_exists():
            self.label_status.configure(text=text)

class AdvancedAICoder(ctk.CTk, UIMixin):
    def __init__(self):
        super().__init__()
        self.withdraw()
        self.title("AI-Coder")
        self.geometry("1400x880")

        try:
            icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
            if os.path.exists(icon_path):
                img = tk.PhotoImage(file=icon_path)
                self.iconphoto(True, img)
        except Exception:
            pass

        self.OLLAMA_URL = OLLAMA_URL
        self.DEFAULT_MODEL = DEFAULT_MODEL
        self.CHATS_FILE = CHATS_FILE
        self.BACKUP_DIR = BACKUP_DIR

        default_project_dir = os.path.join(os.getcwd(), "Project-AI")
        os.makedirs(default_project_dir, exist_ok=True)
        self.workspace_dir = default_project_dir

        self.current_open_file = None
        self.show_terminal_log = True
        self.thinking_anim_active = False
        self.thinking_dot_count = 1

        self.cancel_flag = False
        self.pause_flag = False

        self.chats = {}
        self.current_chat_id = None
        self.available_models = ["Загрузка..."]

        self.model_var = ctk.StringVar(value=self.DEFAULT_MODEL)
        self.os_var = ctk.StringVar(value="Linux" if platform.system() != "Windows" else "Windows")
        self.ctx_var = ctk.StringVar(value="4096")
        self.temp_var = ctk.DoubleVar(value=0.2)
        self.allow_cmd_var = ctk.BooleanVar(value=True)

        self.backup_manager = BackupManager(self.workspace_dir, self.BACKUP_DIR)

        # Детектор первого запуска
        self.load_chats()

        self.agent = AIAgent(self)
        self.setup_ui()
        self.refresh_file_tree()
        self.load_chat_list_ui()

        self.prompt_entry.bind("<Control-Return>", lambda e: self.start_agent())
        self.prompt_entry_2.bind("<Control-Return>", lambda e: self.start_agent())

        if not self.chats: self.new_chat("Новый проект")
        else: self.switch_chat(list(self.chats.keys())[0])

        self.splash = LoadingSplash(self)
        self.splash.progress_bar.start()
        threading.Thread(target=self._startup_workflow, daemon=True).start()

    def _startup_workflow(self):
        time.sleep(0.5)
        self.after(0, lambda: self.splash.update_status("🔍 Поиск моделей Ollama..."))
        self._load_local_models()
        time.sleep(0.5)
        self.after(0, lambda: self.splash.update_status("Почти готово..."))
        time.sleep(0.5)
        self.after(0, self._finish_startup)

    def _load_local_models(self):
        try:
            res = requests.get("http://localhost:11434/api/tags", timeout=3)
            if res.status_code == 200:
                models = [m["name"] for m in res.json().get("models", [])]
                if models:
                    self.available_models = models
                    if self.DEFAULT_MODEL in models: self.model_var.set(self.DEFAULT_MODEL)
                    else: self.model_var.set(models[0])
                else:
                    self.available_models = ["Нет загруженных моделей"]
                    self.model_var.set("Нет загруженных моделей")
        except Exception:
            self.available_models = [self.DEFAULT_MODEL]
            self.model_var.set(self.DEFAULT_MODEL)

    def _finish_startup(self):
        try: self.splash.destroy()
        except Exception: pass
        self.deiconify()
        self.log(f"[Система] ✨ AI-Coder запущен!\nОС: {self.os_var.get()}\nДиректория: {self.workspace_dir}\n")

        # Если это самый первый запуск (файла чатов не было), вызываем окно лицензии
        if getattr(self, 'is_first_run', False):
            self.after(700, self.open_license_window) # Небольшая задержка, чтобы интерфейс успел прорисоваться
            self.is_first_run = False

    def load_chats(self):
        # Проверяем, существует ли файл. Если нет - это первый запуск
        self.is_first_run = not os.path.exists(self.CHATS_FILE)

        if not self.is_first_run:
            try:
                with open(self.CHATS_FILE, "r", encoding="utf-8") as f: self.chats = json.load(f)
            except Exception: self.chats = {}
        else:
            self.chats = {}

    def save_chats(self):
        try:
            with open(self.CHATS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.chats, f, ensure_ascii=False, indent=4)
        except Exception as e: print(f"Ошибка сохранения чатов: {e}")

    def load_chat_list_ui(self):
        for widget in self.chats_frame.winfo_children(): widget.destroy()
        for cid, chat_data in list(self.chats.items()):
            row_frame = ctk.CTkFrame(self.chats_frame, fg_color="transparent")
            row_frame.pack(fill="x", pady=2)
            row_frame.grid_columnconfigure(0, weight=1)
            btn_color = "#1f538d" if cid == self.current_chat_id else "#2d2d2d"
            title_btn = ctk.CTkButton(row_frame, text=chat_data["title"], fg_color=btn_color, anchor="w", command=lambda id=cid: self.switch_chat(id))
            title_btn.grid(row=0, column=0, sticky="ew")
            del_btn = ctk.CTkButton(row_frame, text="✖", width=30, fg_color="#a83232", hover_color="#822525", command=lambda id=cid: self.delete_chat(id))
            del_btn.grid(row=0, column=1, padx=(5, 0))

    def delete_chat(self, cid):
        if cid not in self.chats: return
        chat_title = self.chats[cid].get("title", "Неизвестный чат")
        if messagebox.askyesno("Удаление сессии", f"Вы уверены, что хотите безвозвратно удалить чат '{chat_title}'?"):
            del self.chats[cid]
            self.save_chats()
            log_path = os.path.join(self.workspace_dir, self.BACKUP_DIR, "chat_logs", f"{cid}.log")
            if os.path.exists(log_path):
                try: os.remove(log_path)
                except Exception: pass
            if self.current_chat_id == cid:
                if self.chats: self.switch_chat(list(self.chats.keys())[0])
                else:
                    self.current_chat_id = None
                    self.ai_console.delete("1.0", "end")
                    self.new_chat("Новый проект")
            else:
                self.load_chat_list_ui()

    def toggle_current_chat_mode(self):
        if not self.current_chat_id or self.current_chat_id not in self.chats: return
        current_mode = self.chats[self.current_chat_id].get("mode", "agent")
        if current_mode == "agent": new_mode = "query"
        elif current_mode == "query": new_mode = "assistant"
        elif current_mode == "assistant": new_mode = "dcoder"
        else: new_mode = "agent"
        self.chats[self.current_chat_id]["mode"] = new_mode
        self.save_chats()
        self.update_mode_button_ui()

    def update_mode_button_ui(self):
        if hasattr(self, "btn_mode_toggle") and self.current_chat_id in self.chats:
            mode = self.chats[self.current_chat_id].get("mode", "agent")
            if hasattr(self, "prompt_entry_2"):
                self.lbl_prompt_2.grid_remove()
                self.prompt_entry_2.grid_remove()
                self.lbl_prompt_1.configure(text="Запрос:")
            if mode == "agent":
                self.btn_mode_toggle.configure(text="🤖 Режим: АГЕНТ", fg_color="#1f538d", hover_color="#163d6b")
                self.terminal_frame.grid_remove()
            elif mode == "query":
                self.btn_mode_toggle.configure(text="💬 Режим: ASK", fg_color="#b8860b", hover_color="#9a6e05")
                self.terminal_frame.grid_remove()
            elif mode == "assistant":
                self.btn_mode_toggle.configure(text="🛠️ Режим: АССИСТЕНТ", fg_color="#6a0dad", hover_color="#4b0082")
                if self.show_terminal_log: self.terminal_frame.grid()
            elif mode == "dcoder":
                self.btn_mode_toggle.configure(text="🎯 Режим: D-CODER", fg_color="#006400", hover_color="#004d00")
                self.terminal_frame.grid_remove()
                if hasattr(self, "prompt_entry_2"):
                    self.lbl_prompt_1.configure(text="1. Структура проекта (папки/файлы):")
                    self.lbl_prompt_2.grid(row=2, column=0, sticky="w", pady=(5, 2))
                    self.prompt_entry_2.grid(row=3, column=0, sticky="ew")

    def new_chat(self, title):
        cid = str(uuid.uuid4())[:8]
        self.chats[cid] = {"title": title, "mode": "agent", "messages": [], "history": [], "state": {}}
        self.save_chats()
        self.switch_chat(cid)
        self.load_chat_list_ui()

    def switch_chat(self, cid):
        self.current_chat_id = cid
        self.load_chat_list_ui()
        self.update_mode_button_ui()
        self.ai_console.delete("1.0", "end")
        if cid in self.chats:
            for msg in self.chats[cid]["messages"]:
                self.ai_console.insert("end", msg)
        self.ai_console.see("end")

    def append_to_chat(self, cid, text):
        if cid in self.chats:
            self.chats[cid]["messages"].append(text)
            self.save_chats()

    def log(self, message, target_chat_id=None):
        def _update_ui():
            cid = target_chat_id or self.current_chat_id
            if cid:
                self.append_to_chat(cid, message)
                if cid == self.current_chat_id:
                    self.ai_console.insert("end", message)
                    self.ai_console.see("end")
        self.after(0, _update_ui)

    def stop_agent(self):
        self.cancel_flag = True
        self.pause_flag = False
        self.log("\n🛑 [Система] АКТИВИРОВАН ЭКСТРЕННЫЙ ТОРМОЗ! Остановка процессов и сброс состояния...\n")
        if self.current_chat_id in self.chats:
            self.chats[self.current_chat_id]["state"] = {}
            self.save_chats()
        if hasattr(self, 'btn_stop_ai'):
            self.btn_stop_ai.configure(state="disabled")
            if hasattr(self, 'btn_pause_ai'):
                self.btn_pause_ai.configure(state="disabled")
            self.btn_run_ai.configure(state="normal", text="🚀 ОТПРАВИТЬ / ПРОДОЛЖ.")

    def pause_agent(self):
        self.pause_flag = True
        self.log("\n⏸ [Система] Пауза активирована. Ожидайте завершения текущего шага...\n")
        if hasattr(self, 'btn_pause_ai'):
            self.btn_pause_ai.configure(state="disabled")

    def start_agent(self):
        task = self.prompt_entry.get("1.0", "end").strip()
        chat_mode = self.chats.get(self.current_chat_id, {}).get("mode", "agent")
        task2 = None
        if chat_mode == "dcoder":
            task2 = self.prompt_entry_2.get("1.0", "end").strip()
            if not task and not task2: return
        else:
            if not task and not self.chats.get(self.current_chat_id, {}).get("state"): return

        self.cancel_flag = False
        self.pause_flag = False
        cid = self.current_chat_id

        if cid in self.chats and self.chats[cid]["title"] in ["Новый чат", "Новый проект"] and (task or task2):
            title_text = task if task else task2
            self.chats[cid]["title"] = (title_text[:22] + '..') if len(title_text) > 22 else title_text
            self.load_chat_list_ui()
            self.save_chats()

        self.prompt_entry.delete("1.0", "end")
        if hasattr(self, "prompt_entry_2"):
            self.prompt_entry_2.delete("1.0", "end")

        self.btn_run_ai.configure(state="disabled")
        if hasattr(self, 'btn_stop_ai'):
            self.btn_stop_ai.configure(state="normal")
            if hasattr(self, 'btn_pause_ai'):
                self.btn_pause_ai.configure(state="normal")

        self.start_thinking_animation()

        if task or task2:
            if chat_mode == "dcoder":
                msg = f"\n{'='*50}\n[Структура проекта]:\n{task}\n[Содержимое файлов передано]\n"
            else:
                msg = f"\n{'='*50}\n[Задача]: {task}\n"
            self.log(msg, target_chat_id=cid)

        threading.Thread(target=self._run_task_directly, args=(task, task2, cid), daemon=True).start()

    def _run_task_directly(self, task, task2, chat_id):
        try:
            chat_mode = self.chats.get(chat_id, {}).get("mode", "agent")
            if chat_mode == "query":
                self.agent.run_query_mode(task, chat_id)
            elif chat_mode == "assistant":
                self.agent.run_assistant_mode(task, chat_id)
            elif chat_mode == "dcoder":
                self.agent.run_dcoder_mode(task, task2, chat_id)
            else:
                self.agent.run_multi_step_pipeline(task, chat_id)
        except Exception as e:
            self.log(f"[Ошибка выполнения]: {e}\n", target_chat_id=chat_id)
        finally:
            self.after(0, self.stop_thinking_animation)

    def start_thinking_animation(self):
        self.thinking_anim_active = True
        self.thinking_dot_count = 1
        self._animate_thinking_loop()

    def _animate_thinking_loop(self):
        if not self.thinking_anim_active: return
        dots = "." * self.thinking_dot_count
        self.btn_run_ai.configure(text=f"🧠 Обработка{dots}")
        self.thinking_dot_count = (self.thinking_dot_count % 3) + 1
        self.after(400, self._animate_thinking_loop)

    def stop_thinking_animation(self):
        self.thinking_anim_active = False
        self.btn_run_ai.configure(state="normal", text="🚀 ОТПРАВИТЬ / ПРОДОЛЖ.")
        if hasattr(self, 'btn_stop_ai'):
            self.btn_stop_ai.configure(state="disabled")
            if hasattr(self, 'btn_pause_ai'):
                self.btn_pause_ai.configure(state="disabled")

if __name__ == "__main__":
    app = AdvancedAICoder()
    app.mainloop()
