import webview
import sys

def main():
    # Получаем ссылку из аргументов или открываем Google по умолчанию
    url = sys.argv[1] if len(sys.argv) > 1 else "https://google.com"

    # Создаем чистое окно без рамок браузера
    webview.create_window("AI Mini Browser", url, width=1024, height=768)
    webview.start()

if __name__ == '__main__':
    main()
