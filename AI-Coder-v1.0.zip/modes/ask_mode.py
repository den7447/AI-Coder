def run(agent, task, chat_id):
    agent.app.log("[💬 ASK] Ищу ответ на ваш запрос...\n", target_chat_id=chat_id)
    agent._append_history(chat_id, "user", task)
    prompt = f"{agent._get_history_context(chat_id)}Ты ИИ-консультант. Ответь прямо и понятно.\nЗапрос: {task}"
    response = agent.ask_ollama(prompt)
    if not agent.app.cancel_flag:
        agent._append_history(chat_id, "assistant", response)
        agent.app.log(f"🤖 [Ответ]:\n{response}\n", target_chat_id=chat_id)
