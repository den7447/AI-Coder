import os
import re

def run(agent, structure, content, chat_id):
    agent.app.log("[🎯 D-CODER] ЭТАП 1: Анализ архитектуры (Сбор списка файлов)...\n", target_chat_id=chat_id)

    struct_prompt = (
        f"Ты строгий парсер архитектуры.\n"
        f"Твоя задача — прочитать структуру проекта и выписать ВСЕ конечные файлы, которые нужно создать.\n"
        f"Игнорируй папки, выписывай только файлы!\n\n"
        f"--- СТРУКТУРА ---\n{structure}\n\n"
        f"Ответь СТРОГО списком в формате:\n"
        f"FILE: путь/к/файлу.py\n"
        f"Никакого кода файлов и никаких других слов!"
    )

    struct_resp = agent.ask_ollama(struct_prompt)
    if agent.app.cancel_flag or getattr(agent.app, 'pause_flag', False): return
    agent.app.log(f"📋 [РАСПОЗНАННЫЕ ФАЙЛЫ]:\n{struct_resp}\n\n", target_chat_id=chat_id)

    files = re.findall(r"FILE:\s*([^\n]+)", struct_resp, re.IGNORECASE)
    clean_files = []
    root_name = os.path.basename(agent.app.workspace_dir)

    for f in files:
        f = f.strip().lstrip('\\/')
        parts = f.replace('\\', '/').split('/')
        if not parts or not parts[0]: continue
        if parts[0] == root_name and len(parts) > 1:
            f = '/'.join(parts[1:])
        if f.endswith('/'): continue
        clean_files.append(f)

    if not clean_files:
        agent.app.log("⚠️ [Ошибка] Не удалось распознать файлы. Убедитесь, что передана правильная структура.\n", target_chat_id=chat_id)
        return

    for filepath in clean_files:
        full_path = os.path.join(agent.app.workspace_dir, filepath)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        if not os.path.exists(full_path):
            with open(full_path, "w", encoding="utf-8") as f:
                f.write("")

    agent.app.log("✅ [ЭТАП 1 ЗАВЕРШЕН] Пустые файлы и папки созданы.\n\n", target_chat_id=chat_id)
    agent.app.after(0, agent.app.refresh_file_tree)

    agent.app.log("[🎯 D-CODER] ЭТАП 2: Точечное встраивание кода в файлы...\n", target_chat_id=chat_id)
    for i, filepath in enumerate(clean_files, 1):
        if agent.app.cancel_flag or getattr(agent.app, 'pause_flag', False): break
        agent.app.log(f"⚙️ [ПОИСК И ЗАПИСЬ {i}/{len(clean_files)}]: {filepath}\n", target_chat_id=chat_id)

        code_prompt = (
            f"Ты строгий парсер кода.\n"
            f"Найди в исходных кодах фрагмент, который относится к файлу '{filepath}'.\n"
            f"--- ИСХОДНЫЕ КОДЫ ---\n{content}\n\n"
            f"ВНИМАНИЕ! ТЫ ОБЯЗАН ВЫВЕСТИ КОД ПОЛНОСТЬЮ! Строго запрещено использовать заглушки, обрезать код или писать комментарии в стиле '// остальной код'.\n"
            f"Выведи ТОЛЬКО код для этого файла, обернутый в блок:\n"
            f"```file: {filepath}\nВЕСЬ КОД\n```\n"
            f"Если кода для этого файла в исходниках нет, просто выведи пустой блок. Не пиши пояснений и извинений!"
        )

        code_resp = agent.ask_ollama(code_prompt)
        if agent.app.cancel_flag or getattr(agent.app, 'pause_flag', False): break

        agent.app.log(f"🤖 [Вставка кода]:\n{code_resp[:200]}... (часть скрыта)\n\n", target_chat_id=chat_id)
        agent._extract_and_run_commands(code_resp, chat_id, allow_file_creation=True, allow_cmd_execution=False)

    if not agent.app.cancel_flag and not getattr(agent.app, 'pause_flag', False):
        agent._append_history(chat_id, "user", "[D-CODER: Процесс сборки запрошен]")
        agent._append_history(chat_id, "assistant", "Все файлы успешно распакованы и собраны.")
        agent.app.log("✅ [D-CODER] Проект успешно собран по строгому стандарту!\n", target_chat_id=chat_id)
