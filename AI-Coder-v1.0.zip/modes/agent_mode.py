import re

def run(agent, task, chat_id):
    chat_state = agent.app.chats.get(chat_id, {})
    saved_state = chat_state.get("state", {})

    if saved_state and "steps" in saved_state:
        agent.app.log("[▶️ ПРОДОЛЖЕНИЕ] Восстановление прерванной задачи...\n", target_chat_id=chat_id)
        steps = saved_state["steps"]
        start_index = saved_state["current_index"]
        plan = saved_state["plan"]
    else:
        agent.app.log("[🤖 АГЕНТ] Запуск автономного программирования...\n", target_chat_id=chat_id)
        agent._append_history(chat_id, "user", task)

        plan_prompt = (
            f"{agent._get_history_context(chat_id)}"
            f"Задача: {task}\n"
            f"Создай ОЧЕНЬ подробный пошаговый план выполнения этой задачи (строго от 20 до 250 шагов) в виде нумерованного списка."
        )
        plan = agent.ask_ollama(plan_prompt)
        if agent.app.cancel_flag: return
        agent.app.log(f"📋 [ПЛАН ПРОЕКТА]:\n{plan}\n\n", target_chat_id=chat_id)

        steps = [line.strip() for line in plan.split('\n') if re.match(r'^\d+\.', line.strip())]
        if not steps: steps = ["1. Реализовать задачу."]
        start_index = 0

    context = f"Задача: {task}\nОбщий план:\n{plan}\n"

    for i in range(start_index, len(steps)):
        step = steps[i]

        if agent.app.cancel_flag:
            agent.app.log("🛑 Задача полностью отменена.\n", target_chat_id=chat_id)
            agent.app.chats[chat_id]["state"] = {}
            break
        if agent.app.pause_flag:
            agent.app.log(f"⏸ Пауза. Остановлено перед шагом {i+1}. Нажмите 'ОТПРАВИТЬ / ПРОДОЛЖ.', чтобы продолжить.\n", target_chat_id=chat_id)
            agent.app.chats[chat_id]["state"] = {"steps": steps, "current_index": i, "plan": plan}
            agent.app.save_chats()
            return

        agent.app.log(f"⚙️ [ШАГ {i+1}/{len(steps)}]: {step}\n", target_chat_id=chat_id)

        step_prompt = (
            f"{context}\nТекущие файлы:\n{agent.get_workspace_context()}\n\n"
            f"Выполни шаг {i+1}: {step}\n"
            f"КРИТИЧЕСКИ ВАЖНО: Если ты создаешь или меняешь код, ты ОБЯЗАН обернуть весь исходный код в такой блок:\n"
            f"```file: путь/к/файлу.py\n<здесь весь код от начала до конца>\n```\n"
            f"Иначе программа не сохранится!"
        )

        step_response = agent.ask_ollama(step_prompt)
        if agent.app.cancel_flag or agent.app.pause_flag: continue

        agent.app.log(f"🤖 [Отчет ИИ]:\n{step_response}\n\n", target_chat_id=chat_id)
        agent._extract_and_run_commands(step_response, chat_id, allow_file_creation=True)

    if not agent.app.cancel_flag and not getattr(agent.app, 'pause_flag', False):
        final_response = agent.ask_ollama("Дай краткое резюме проделанной работы.")
        agent._append_history(chat_id, "assistant", f"Выполнен план:\n{plan}\nИтог:\n{final_response}")
        agent.app.chats[chat_id]["state"] = {}
        agent.app.save_chats()
