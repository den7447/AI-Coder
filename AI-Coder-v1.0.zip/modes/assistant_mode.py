def run(agent, task, chat_id):
    agent.app.log("[🛠️ АССИСТЕНТ] Генерация команд терминала...\n", target_chat_id=chat_id)
    agent._append_history(chat_id, "user", task)
    target_os = agent.app.os_var.get()
    prompt = f"{agent._get_history_context(chat_id)}Ты системный инженер. Задача: {task}\nОС: {target_os}.\nВыдай только терминальные команды в блоке ```bash ... ```."
    response = agent.ask_ollama(prompt)

    if agent.app.cancel_flag or getattr(agent.app, 'pause_flag', False): return

    agent._append_history(chat_id, "assistant", response)
    agent.app.log(f"🤖 [План команд]:\n{response}\n", target_chat_id=chat_id)
    agent._extract_and_run_commands(response, chat_id, allow_file_creation=False)
